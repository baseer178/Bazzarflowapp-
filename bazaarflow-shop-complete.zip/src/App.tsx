const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"];/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { StoreProvider, useStore } from "/src/context/StoreContext.tsx";
import { Header } from "/src/components/common/Header.tsx";
import { OrderNotificationToast } from "/src/components/common/OrderNotificationToast.tsx";
import { BuyerStorefront } from "/src/components/buyer/BuyerStorefront.tsx";
import { SellerDashboard } from "/src/components/seller/SellerDashboard.tsx";
import { ArchitectureView } from "/src/components/architecture/ArchitectureView.tsx";
import { CartDrawer } from "/src/components/buyer/CartDrawer.tsx";
import { ExportModal } from "/src/components/common/ExportModal.tsx";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
const AppContent = () => {
	const { currentView, setCurrentView, isExportOpen, setIsExportOpen } = useStore();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-slate-900 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV(Header, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1",
				children: [
					currentView === "buyer" && /* @__PURE__ */ _jsxDEV(BuyerStorefront, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 37
					}, this),
					currentView === "seller" && /* @__PURE__ */ _jsxDEV(SellerDashboard, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 38
					}, this),
					currentView === "architecture" && /* @__PURE__ */ _jsxDEV(ArchitectureView, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 44
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(CartDrawer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(ExportModal, {
				isOpen: isExportOpen,
				onClose: () => setIsExportOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(OrderNotificationToast, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "border-t border-slate-200 bg-white py-8 text-xs text-slate-500",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-semibold text-slate-800",
								children: "BazaarFlow"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 44,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Production E-Commerce & Store Management System" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-6",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setCurrentView("buyer"),
								className: "hover:text-slate-900 transition-colors cursor-pointer",
								children: "Storefront"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setCurrentView("seller"),
								className: "hover:text-slate-900 transition-colors cursor-pointer",
								children: "Seller Admin"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setCurrentView("architecture"),
								className: "hover:text-slate-900 transition-colors cursor-pointer",
								children: "Architecture & Specs"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
};
export default function App() {
	return /* @__PURE__ */ _jsxDEV(StoreProvider, { children: /* @__PURE__ */ _jsxDEV(AppContent, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 78,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 77,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sV0FBVztBQUNsQixTQUFTLGVBQWUsZ0JBQWdCO0FBQ3hDLFNBQVMsY0FBYztBQUN2QixTQUFTLDhCQUE4QjtBQUN2QyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjs7O0FBRTVCLE1BQU0sbUJBQTZCO0NBQ2pDLE1BQU0sRUFBRSxhQUFhLGdCQUFnQixjQUFjLG9CQUFvQixTQUFTO0NBRWhGLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7R0FHVCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUNHLGdCQUFnQixXQUFXLHdCQUFDLGlCQUFELENBQWtCOzs7OztLQUM3QyxnQkFBZ0IsWUFBWSx3QkFBQyxpQkFBRCxDQUFrQjs7Ozs7S0FDOUMsZ0JBQWdCLGtCQUFrQix3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7SUFDbEQ7Ozs7OztHQUdOLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7R0FHYix3QkFBQyxhQUFEO0lBQWEsUUFBUTtJQUFjLGVBQWUsZ0JBQWdCLEtBQUs7R0FBSTs7Ozs7R0FHM0Usd0JBQUMsd0JBQUQsQ0FBeUI7Ozs7O0dBR3pCLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQ2hCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUErQjtPQUFnQjs7Ozs7T0FDL0Qsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O09BQ2Isd0JBQUMsUUFBRCxZQUFNLGtEQUFxRDs7Ozs7TUFDeEQ7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxlQUFlLE9BQU87UUFDckMsV0FBVTtrQkFDWDtPQUVPOzs7OztPQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGVBQWUsUUFBUTtRQUN0QyxXQUFVO2tCQUNYO09BRU87Ozs7O09BQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsZUFBZSxjQUFjO1FBQzVDLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7YUFDRjs7Ozs7O0dBQ0M7Ozs7O0VBQ0w7Ozs7OztBQUVUO0FBRUEsZUFBZSxTQUFTLE1BQU07Q0FDNUIsT0FDRSx3QkFBQyxlQUFELFlBQ0Usd0JBQUMsWUFBRCxDQUFhOzs7O1VBQ0E7Ozs7O0FBRW5CIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogU1BEWC1MaWNlbnNlLUlkZW50aWZpZXI6IEFwYWNoZS0yLjBcbiAqL1xuXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgU3RvcmVQcm92aWRlciwgdXNlU3RvcmUgfSBmcm9tICcuL2NvbnRleHQvU3RvcmVDb250ZXh0JztcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4vY29tcG9uZW50cy9jb21tb24vSGVhZGVyJztcbmltcG9ydCB7IE9yZGVyTm90aWZpY2F0aW9uVG9hc3QgfSBmcm9tICcuL2NvbXBvbmVudHMvY29tbW9uL09yZGVyTm90aWZpY2F0aW9uVG9hc3QnO1xuaW1wb3J0IHsgQnV5ZXJTdG9yZWZyb250IH0gZnJvbSAnLi9jb21wb25lbnRzL2J1eWVyL0J1eWVyU3RvcmVmcm9udCc7XG5pbXBvcnQgeyBTZWxsZXJEYXNoYm9hcmQgfSBmcm9tICcuL2NvbXBvbmVudHMvc2VsbGVyL1NlbGxlckRhc2hib2FyZCc7XG5pbXBvcnQgeyBBcmNoaXRlY3R1cmVWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL2FyY2hpdGVjdHVyZS9BcmNoaXRlY3R1cmVWaWV3JztcbmltcG9ydCB7IENhcnREcmF3ZXIgfSBmcm9tICcuL2NvbXBvbmVudHMvYnV5ZXIvQ2FydERyYXdlcic7XG5pbXBvcnQgeyBFeHBvcnRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9jb21tb24vRXhwb3J0TW9kYWwnO1xuXG5jb25zdCBBcHBDb250ZW50OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjdXJyZW50Vmlldywgc2V0Q3VycmVudFZpZXcsIGlzRXhwb3J0T3Blbiwgc2V0SXNFeHBvcnRPcGVuIH0gPSB1c2VTdG9yZSgpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gZmxleCBmbGV4LWNvbCBiZy1zbGF0ZS01MCB0ZXh0LXNsYXRlLTkwMCBzZWxlY3Rpb246Ymctc2xhdGUtOTAwIHNlbGVjdGlvbjp0ZXh0LXdoaXRlXCI+XG4gICAgICB7LyogVW5pdmVyc2FsIFRvcCBOYXZpZ2F0aW9uIEhlYWRlciAqL31cbiAgICAgIDxIZWFkZXIgLz5cblxuICAgICAgey8qIE1haW4gVmlldyBSb3V0ZXIgKi99XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTFcIj5cbiAgICAgICAge2N1cnJlbnRWaWV3ID09PSAnYnV5ZXInICYmIDxCdXllclN0b3JlZnJvbnQgLz59XG4gICAgICAgIHtjdXJyZW50VmlldyA9PT0gJ3NlbGxlcicgJiYgPFNlbGxlckRhc2hib2FyZCAvPn1cbiAgICAgICAge2N1cnJlbnRWaWV3ID09PSAnYXJjaGl0ZWN0dXJlJyAmJiA8QXJjaGl0ZWN0dXJlVmlldyAvPn1cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIFVuaXZlcnNhbCBDYXJ0IFNsaWRlLW92ZXIgRHJhd2VyICovfVxuICAgICAgPENhcnREcmF3ZXIgLz5cblxuICAgICAgey8qIDEtQ2xpY2sgQ29kZSBEb3dubG9hZCAmIEdpdEh1YiBFeHBvcnQgTW9kYWwgKi99XG4gICAgICA8RXhwb3J0TW9kYWwgaXNPcGVuPXtpc0V4cG9ydE9wZW59IG9uQ2xvc2U9eygpID0+IHNldElzRXhwb3J0T3BlbihmYWxzZSl9IC8+XG5cbiAgICAgIHsvKiBSZWFsLXRpbWUgSW5jb21pbmcgT3JkZXIgTm90aWZpY2F0aW9uIFRvYXN0ICovfVxuICAgICAgPE9yZGVyTm90aWZpY2F0aW9uVG9hc3QgLz5cblxuICAgICAgey8qIFF1aWV0IEZvb3RlciAqL31cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSBweS04IHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwXCI+QmF6YWFyRmxvdzwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+UHJvZHVjdGlvbiBFLUNvbW1lcmNlICYgU3RvcmUgTWFuYWdlbWVudCBTeXN0ZW08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC02XCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEN1cnJlbnRWaWV3KCdidXllcicpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXNsYXRlLTkwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFN0b3JlZnJvbnRcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50Vmlldygnc2VsbGVyJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtc2xhdGUtOTAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgU2VsbGVyIEFkbWluXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ2FyY2hpdGVjdHVyZScpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXNsYXRlLTkwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEFyY2hpdGVjdHVyZSAmIFNwZWNzXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Zvb3Rlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8U3RvcmVQcm92aWRlcj5cbiAgICAgIDxBcHBDb250ZW50IC8+XG4gICAgPC9TdG9yZVByb3ZpZGVyPlxuICApO1xufVxuIl19