const React = __vite__cjsImport0_react; const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { ProductCard } from "/src/components/buyer/ProductCard.tsx";
import { QuickOrderModal } from "/src/components/buyer/QuickOrderModal.tsx";
import { Search, Sparkles, Shield, Truck, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/buyer/BuyerStorefront.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const BuyerStorefront = () => {
	const { products, selectedCategory, setSelectedCategory, searchQuery, setSearchQuery, quickOrderProduct, setQuickOrderProduct, setCurrentView } = useStore();
	// Extract unique categories
	const categories = useMemo(() => {
		const set = new Set();
		set.add("All");
		products.forEach((p) => set.add(p.category));
		return Array.from(set);
	}, [products]);
	// Filter products by category and search
	const filteredProducts = useMemo(() => {
		return products.filter((product) => {
			const matchesCategory = selectedCategory === "All" || product.category === selectedCategory;
			const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || product.description.toLowerCase().includes(searchQuery.toLowerCase()) || product.sku.toLowerCase().includes(searchQuery.toLowerCase());
			return matchesCategory && matchesSearch;
		});
	}, [
		products,
		selectedCategory,
		searchQuery
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-16",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 text-slate-200 text-xs py-2 px-4 border-b border-slate-800",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "font-semibold text-white",
							children: "Nationwide Cash on Delivery (COD)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline text-slate-400",
							children: "· Express 2-4 business days dispatch"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setCurrentView("seller"),
						className: "text-amber-400 hover:text-amber-300 text-xs underline font-medium cursor-pointer",
						children: "Are you a seller? Open Seller Dashboard →"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "bg-white border-b border-slate-200",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-14",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "max-w-3xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "Direct Vendor Commerce" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 64,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Single & Multi-Vendor Hub" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 65,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 font-display text-balance",
								children: "Modern Essentials with Instant 1-Click Ordering"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "mt-3 text-base text-slate-600 leading-relaxed max-w-2xl",
								children: [
									"Select any product, tap ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-800",
										children: "\"Order Now\""
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 73,
										columnNumber: 39
									}, this),
									", enter your delivery address, and pay via Cash on Delivery when it reaches your doorstep."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-8 pt-6 border-t border-slate-100 grid grid-cols-3 gap-6 max-w-xl text-left",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 text-xs font-semibold text-slate-900",
										children: [/* @__PURE__ */ _jsxDEV(Shield, { className: "w-4 h-4 text-slate-700" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 80,
											columnNumber: 19
										}, this), "Verified Orders"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 79,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs text-slate-500 mt-0.5",
										children: "Pay upon inspection"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 83,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 78,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 text-xs font-semibold text-slate-900",
										children: [/* @__PURE__ */ _jsxDEV(Truck, { className: "w-4 h-4 text-slate-700" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 87,
											columnNumber: 19
										}, this), "Free Shipping"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 86,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs text-slate-500 mt-0.5",
										children: "Orders across Pakistan"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 85,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 text-xs font-semibold text-slate-900",
										children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4 text-slate-700" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 94,
											columnNumber: 19
										}, this), "7-Day Returns"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs text-slate-500 mt-0.5",
										children: "Hassle-free replacement"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 92,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none",
							children: categories.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedCategory(cat),
								className: `px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${selectedCategory === cat ? "bg-slate-900 text-white shadow-xs" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-100 hover:text-slate-900"}`,
								children: cat
							}, cat, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative min-w-[260px] max-w-sm",
							children: [
								/* @__PURE__ */ _jsxDEV(Search, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Search products or SKU...",
									value: searchQuery,
									onChange: (e) => setSearchQuery(e.target.value),
									className: "w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 130,
									columnNumber: 13
								}, this),
								searchQuery && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setSearchQuery(""),
									className: "absolute right-2.5 top-2 text-xs text-slate-400 hover:text-slate-600",
									children: "Clear"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "py-4 flex items-center justify-between text-xs text-slate-500",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [
							"Showing ",
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-900 font-mono tabular-nums",
								children: filteredProducts.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 21
							}, this),
							" ",
							filteredProducts.length === 1 ? "item" : "items",
							selectedCategory !== "All" && /* @__PURE__ */ _jsxDEV("span", { children: [" in ", /* @__PURE__ */ _jsxDEV("strong", { children: selectedCategory }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 54
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 44
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400",
							children: "All prices in PKR (Cash on Delivery Available)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 9
					}, this),
					filteredProducts.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white rounded-lg border border-slate-200 p-12 text-center my-6",
						children: [
							/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-10 h-10 text-slate-300 mx-auto mb-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-base font-semibold text-slate-800",
								children: "No matching products found"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 mt-1 max-w-sm mx-auto",
								children: "Try adjusting your search query or selecting a different category from above."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 163,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setSelectedCategory("All");
									setSearchQuery("");
								},
								className: "mt-4 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors cursor-pointer",
								children: "Reset Filters"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 166,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6",
						children: filteredProducts.map((product) => /* @__PURE__ */ _jsxDEV(ProductCard, { product }, product.id, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 7
			}, this),
			quickOrderProduct && /* @__PURE__ */ _jsxDEV(QuickOrderModal, {
				product: quickOrderProduct,
				onClose: () => setQuickOrderProduct(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 188,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWU7QUFDL0IsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxRQUFRLFVBQVUsUUFBUSxPQUFPLGlCQUFpQjs7O0FBRTNELE9BQU8sTUFBTSx3QkFBa0M7Q0FDN0MsTUFBTSxFQUNKLFVBQ0Esa0JBQ0EscUJBQ0EsYUFDQSxnQkFDQSxtQkFDQSxzQkFDQSxtQkFDRSxTQUFTOztDQUdiLE1BQU0sYUFBYSxjQUFjO0VBQy9CLE1BQU0sTUFBTSxJQUFJLElBQVk7RUFDNUIsSUFBSSxJQUFJLEtBQUs7RUFDYixTQUFTLFNBQVEsTUFBSyxJQUFJLElBQUksRUFBRSxRQUFRLENBQUM7RUFDekMsT0FBTyxNQUFNLEtBQUssR0FBRztDQUN2QixHQUFHLENBQUMsUUFBUSxDQUFDOztDQUdiLE1BQU0sbUJBQW1CLGNBQWM7RUFDckMsT0FBTyxTQUFTLFFBQU8sWUFBVztHQUNoQyxNQUFNLGtCQUFrQixxQkFBcUIsU0FBUyxRQUFRLGFBQWE7R0FDM0UsTUFBTSxnQkFDSixRQUFRLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUM3RCxRQUFRLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUNwRSxRQUFRLElBQUksWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQztHQUM5RCxPQUFPLG1CQUFtQjtFQUM1QixDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQVU7RUFBa0I7Q0FBVyxDQUFDO0NBRTVDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTJCO01BQXVDOzs7O2dCQUNsRix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBa0M7TUFBMEM7Ozs7Y0FDekY7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZUFBZSxRQUFRO01BQ3RDLFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7OztTQUNsQyx3QkFBQyxRQUFEO1VBQU0sZUFBWTtvQkFBTztTQUFPOzs7OztTQUNoQyx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7OztRQUNsQzs7Ozs7O09BRUwsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQXFHO09BRS9HOzs7OztPQUVKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQXVFO1NBQzdDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUErQjtTQUFpQjs7Ozs7U0FBQztRQUN4Rjs7Ozs7O09BR0gsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx5QkFBMEI7Ozs7b0JBQUMsaUJBRTFDOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZ0M7U0FBd0I7Ozs7aUJBQ3BFOzs7OztTQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHlCQUEwQjs7OztvQkFBQyxlQUV6Qzs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWdDO1NBQTJCOzs7O2lCQUN2RTs7Ozs7U0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxXQUFELEVBQVcsV0FBVSx5QkFBMEI7Ozs7b0JBQUMsZUFFN0M7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFnQztTQUE0Qjs7OztpQkFDeEU7Ozs7O1FBQ0Y7Ozs7OztNQUNGOzs7Ozs7SUFDRjs7Ozs7R0FDRTs7Ozs7R0FHVCx3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUFuQjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osV0FBVyxLQUFJLFFBQ2Qsd0JBQUMsVUFBRDtRQUVFLGVBQWUsb0JBQW9CLEdBQUc7UUFDdEMsV0FBVyxnR0FDVCxxQkFBcUIsTUFDakIsc0NBQ0E7a0JBR0w7T0FDSyxHQVREOzs7O2NBU0MsQ0FDVDtNQUNFOzs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUscUVBQXNFOzs7OztRQUN4Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVSxNQUFLLGVBQWUsRUFBRSxPQUFPLEtBQUs7U0FDNUMsV0FBVTtRQUNYOzs7OztRQUNBLGVBQ0Msd0JBQUMsVUFBRDtTQUNFLGVBQWUsZUFBZSxFQUFFO1NBQ2hDLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FFUDs7Ozs7Y0FFRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU07T0FDSSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBeUMsaUJBQWlCO09BQWU7Ozs7O09BQUM7T0FBRSxpQkFBaUIsV0FBVyxJQUFJLFNBQVM7T0FDOUkscUJBQXFCLFNBQVMsd0JBQUMsUUFBRCxhQUFNLFFBQUksd0JBQUMsVUFBRCxZQUFTLGlCQUF5Qjs7OztlQUFPOzs7OztNQUM5RTs7OztnQkFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaUI7TUFBb0Q7Ozs7Y0FDbEY7Ozs7OztLQUdKLGlCQUFpQixXQUFXLElBQzNCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsd0NBQXlDOzs7OztPQUM3RCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBeUM7T0FBOEI7Ozs7O09BQ3JGLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUErQztPQUV6RDs7Ozs7T0FDSCx3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLG9CQUFvQixLQUFLO1NBQ3pCLGVBQWUsRUFBRTtRQUNuQjtRQUNBLFdBQVU7a0JBQ1g7T0FFTzs7Ozs7TUFDTDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osaUJBQWlCLEtBQUksWUFDcEIsd0JBQUMsYUFBRCxFQUF1QyxRQUFVLEdBQS9CLFFBQVE7Ozs7YUFBdUIsQ0FDbEQ7S0FDRTs7Ozs7SUFHQTs7Ozs7O0dBR1IscUJBQ0Msd0JBQUMsaUJBQUQ7SUFDRSxTQUFTO0lBQ1QsZUFBZSxxQkFBcUIsSUFBSTtHQUN6Qzs7Ozs7RUFHQTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQnV5ZXJTdG9yZWZyb250LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSAnLi4vLi4vY29udGV4dC9TdG9yZUNvbnRleHQnO1xuaW1wb3J0IHsgUHJvZHVjdENhcmQgfSBmcm9tICcuL1Byb2R1Y3RDYXJkJztcbmltcG9ydCB7IFF1aWNrT3JkZXJNb2RhbCB9IGZyb20gJy4vUXVpY2tPcmRlck1vZGFsJztcbmltcG9ydCB7IFNlYXJjaCwgU3BhcmtsZXMsIFNoaWVsZCwgVHJ1Y2ssIFJvdGF0ZUNjdyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBCdXllclN0b3JlZnJvbnQ6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7XG4gICAgcHJvZHVjdHMsXG4gICAgc2VsZWN0ZWRDYXRlZ29yeSxcbiAgICBzZXRTZWxlY3RlZENhdGVnb3J5LFxuICAgIHNlYXJjaFF1ZXJ5LFxuICAgIHNldFNlYXJjaFF1ZXJ5LFxuICAgIHF1aWNrT3JkZXJQcm9kdWN0LFxuICAgIHNldFF1aWNrT3JkZXJQcm9kdWN0LFxuICAgIHNldEN1cnJlbnRWaWV3XG4gIH0gPSB1c2VTdG9yZSgpO1xuXG4gIC8vIEV4dHJhY3QgdW5pcXVlIGNhdGVnb3JpZXNcbiAgY29uc3QgY2F0ZWdvcmllcyA9IHVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IHNldCA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuICAgIHNldC5hZGQoJ0FsbCcpO1xuICAgIHByb2R1Y3RzLmZvckVhY2gocCA9PiBzZXQuYWRkKHAuY2F0ZWdvcnkpKTtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShzZXQpO1xuICB9LCBbcHJvZHVjdHNdKTtcblxuICAvLyBGaWx0ZXIgcHJvZHVjdHMgYnkgY2F0ZWdvcnkgYW5kIHNlYXJjaFxuICBjb25zdCBmaWx0ZXJlZFByb2R1Y3RzID0gdXNlTWVtbygoKSA9PiB7XG4gICAgcmV0dXJuIHByb2R1Y3RzLmZpbHRlcihwcm9kdWN0ID0+IHtcbiAgICAgIGNvbnN0IG1hdGNoZXNDYXRlZ29yeSA9IHNlbGVjdGVkQ2F0ZWdvcnkgPT09ICdBbGwnIHx8IHByb2R1Y3QuY2F0ZWdvcnkgPT09IHNlbGVjdGVkQ2F0ZWdvcnk7XG4gICAgICBjb25zdCBtYXRjaGVzU2VhcmNoID1cbiAgICAgICAgcHJvZHVjdC5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgICAgcHJvZHVjdC5kZXNjcmlwdGlvbi50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFF1ZXJ5LnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICAgIHByb2R1Y3Quc2t1LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoUXVlcnkudG9Mb3dlckNhc2UoKSk7XG4gICAgICByZXR1cm4gbWF0Y2hlc0NhdGVnb3J5ICYmIG1hdGNoZXNTZWFyY2g7XG4gICAgfSk7XG4gIH0sIFtwcm9kdWN0cywgc2VsZWN0ZWRDYXRlZ29yeSwgc2VhcmNoUXVlcnldKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTUwIHBiLTE2XCI+XG4gICAgICBcbiAgICAgIHsvKiBUb3AgVmFsdWUgUHJvcG9zaXRpb24gU3RyaXAgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIHB5LTIgcHgtNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlXCI+TmF0aW9ud2lkZSBDYXNoIG9uIERlbGl2ZXJ5IChDT0QpPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZSB0ZXh0LXNsYXRlLTQwMFwiPsK3IEV4cHJlc3MgMi00IGJ1c2luZXNzIGRheXMgZGlzcGF0Y2g8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ3NlbGxlcicpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgaG92ZXI6dGV4dC1hbWJlci0zMDAgdGV4dC14cyB1bmRlcmxpbmUgZm9udC1tZWRpdW0gY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIEFyZSB5b3UgYSBzZWxsZXI/IE9wZW4gU2VsbGVyIERhc2hib2FyZCAmcmFycjtcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEhlcm8gU2VjdGlvbiAqL31cbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBweS0xMCBsZzpweS0xNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctM3hsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMlwiPlxuICAgICAgICAgICAgICA8c3Bhbj5EaXJlY3QgVmVuZG9yIENvbW1lcmNlPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+U2luZ2xlICYgTXVsdGktVmVuZG9yIEh1Yjwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgbGc6dGV4dC01eGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheSB0ZXh0LWJhbGFuY2VcIj5cbiAgICAgICAgICAgICAgTW9kZXJuIEVzc2VudGlhbHMgd2l0aCBJbnN0YW50IDEtQ2xpY2sgT3JkZXJpbmdcbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm10LTMgdGV4dC1iYXNlIHRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZCBtYXgtdy0yeGxcIj5cbiAgICAgICAgICAgICAgU2VsZWN0IGFueSBwcm9kdWN0LCB0YXAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlwiT3JkZXIgTm93XCI8L3NwYW4+LCBlbnRlciB5b3VyIGRlbGl2ZXJ5IGFkZHJlc3MsIGFuZCBwYXkgdmlhIENhc2ggb24gRGVsaXZlcnkgd2hlbiBpdCByZWFjaGVzIHlvdXIgZG9vcnN0ZXAuXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIHsvKiBRdWljayBQcm9vZiBNZXRyaWNzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBncmlkIGdyaWQtY29scy0zIGdhcC02IG1heC13LXhsIHRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxTaGllbGQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTcwMFwiIC8+XG4gICAgICAgICAgICAgICAgICBWZXJpZmllZCBPcmRlcnNcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+UGF5IHVwb24gaW5zcGVjdGlvbjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICA8VHJ1Y2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTcwMFwiIC8+XG4gICAgICAgICAgICAgICAgICBGcmVlIFNoaXBwaW5nXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIG10LTAuNVwiPk9yZGVycyBhY3Jvc3MgUGFraXN0YW48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNzAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDctRGF5IFJldHVybnNcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+SGFzc2xlLWZyZWUgcmVwbGFjZW1lbnQ8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG5cbiAgICAgIHsvKiBDYXRhbG9nICYgRmlsdGVyIFNlY3Rpb24gKi99XG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBwdC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogRmlsdGVyIEJhciAmIFNlYXJjaCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcGItNiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFNlZ21lbnRlZCBDYXRlZ29yeSBCdXR0b25zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBvdmVyZmxvdy14LWF1dG8gcGItMSBtZDpwYi0wIHNjcm9sbGJhci1ub25lXCI+XG4gICAgICAgICAgICB7Y2F0ZWdvcmllcy5tYXAoY2F0ID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17Y2F0fVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ2F0ZWdvcnkoY2F0KX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zLjUgcHktMS41IHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRDYXRlZ29yeSA9PT0gY2F0XG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIHNoYWRvdy14cydcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgdGV4dC1zbGF0ZS02MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge2NhdH1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBTZWFyY2ggSW5wdXQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtaW4tdy1bMjYwcHhdIG1heC13LXNtXCI+XG4gICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDAgYWJzb2x1dGUgbGVmdC0zIHRvcC0yLjUgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBwcm9kdWN0cyBvciBTS1UuLi5cIlxuICAgICAgICAgICAgICB2YWx1ZT17c2VhcmNoUXVlcnl9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFNlYXJjaFF1ZXJ5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0xLjUgdGV4dC14cyBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7c2VhcmNoUXVlcnkgJiYgKFxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VhcmNoUXVlcnkoJycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHJpZ2h0LTIuNSB0b3AtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNjAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENsZWFyXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ291bnQgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgIFNob3dpbmcgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LW1vbm8gdGFidWxhci1udW1zXCI+e2ZpbHRlcmVkUHJvZHVjdHMubGVuZ3RofTwvc3Ryb25nPiB7ZmlsdGVyZWRQcm9kdWN0cy5sZW5ndGggPT09IDEgPyAnaXRlbScgOiAnaXRlbXMnfVxuICAgICAgICAgICAge3NlbGVjdGVkQ2F0ZWdvcnkgIT09ICdBbGwnICYmIDxzcGFuPiBpbiA8c3Ryb25nPntzZWxlY3RlZENhdGVnb3J5fTwvc3Ryb25nPjwvc3Bhbj59XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwXCI+QWxsIHByaWNlcyBpbiBQS1IgKENhc2ggb24gRGVsaXZlcnkgQXZhaWxhYmxlKTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByb2R1Y3QgR3JpZCAqL31cbiAgICAgICAge2ZpbHRlcmVkUHJvZHVjdHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBwLTEyIHRleHQtY2VudGVyIG15LTZcIj5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1zbGF0ZS0zMDAgbXgtYXV0byBtYi0zXCIgLz5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPk5vIG1hdGNoaW5nIHByb2R1Y3RzIGZvdW5kPC9oMz5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMSBtYXgtdy1zbSBteC1hdXRvXCI+XG4gICAgICAgICAgICAgIFRyeSBhZGp1c3RpbmcgeW91ciBzZWFyY2ggcXVlcnkgb3Igc2VsZWN0aW5nIGEgZGlmZmVyZW50IGNhdGVnb3J5IGZyb20gYWJvdmUuXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZENhdGVnb3J5KCdBbGwnKTtcbiAgICAgICAgICAgICAgICBzZXRTZWFyY2hRdWVyeSgnJyk7XG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTQgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLXNsYXRlLTkwMCByb3VuZGVkIGhvdmVyOmJnLXNsYXRlLTgwMCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFJlc2V0IEZpbHRlcnNcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICAgICAge2ZpbHRlcmVkUHJvZHVjdHMubWFwKHByb2R1Y3QgPT4gKFxuICAgICAgICAgICAgICA8UHJvZHVjdENhcmQga2V5PXtwcm9kdWN0LmlkfSBwcm9kdWN0PXtwcm9kdWN0fSAvPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgIDwvc2VjdGlvbj5cblxuICAgICAgey8qIFF1aWNrIE9yZGVyIE1vZGFsICovfVxuICAgICAge3F1aWNrT3JkZXJQcm9kdWN0ICYmIChcbiAgICAgICAgPFF1aWNrT3JkZXJNb2RhbFxuICAgICAgICAgIHByb2R1Y3Q9e3F1aWNrT3JkZXJQcm9kdWN0fVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFF1aWNrT3JkZXJQcm9kdWN0KG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==