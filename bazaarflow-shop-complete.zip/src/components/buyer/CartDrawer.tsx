const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { X, Trash2, Plus, Minus, ArrowRight, ShoppingBag, ShieldCheck, MapPin, Phone, User } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/buyer/CartDrawer.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const CartDrawer = () => {
	const { cart, isCartOpen, setIsCartOpen, removeFromCart, updateCartQuantity, clearCart, placeOrder, setCurrentView } = useStore();
	const [checkoutStep, setCheckoutStep] = useState("cart");
	const [fullName, setFullName] = useState("");
	const [phone, setPhone] = useState("");
	const [city, setCity] = useState("Lahore");
	const [deliveryAddress, setDeliveryAddress] = useState("");
	const [paymentMethod, setPaymentMethod] = useState("cod");
	const [placedOrderId, setPlacedOrderId] = useState("");
	const [errorMsg, setErrorMsg] = useState("");
	if (!isCartOpen) return null;
	const totalAmount = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
	const handleCheckoutSubmit = (e) => {
		e.preventDefault();
		if (!fullName.trim() || !phone.trim() || !deliveryAddress.trim()) {
			setErrorMsg("Please complete all required fields");
			return;
		}
		const orderItems = cart.map((i) => ({
			productId: i.product.id,
			productName: i.product.name,
			price: i.product.price,
			quantity: i.quantity,
			imageUrl: i.product.imageUrl
		}));
		const order = placeOrder({
			fullName: fullName.trim(),
			phone: phone.trim(),
			city: city.trim(),
			deliveryAddress: deliveryAddress.trim()
		}, orderItems, paymentMethod);
		setPlacedOrderId(order.orderNumber);
		clearCart();
		setCheckoutStep("success");
	};
	const handleClose = () => {
		setIsCartOpen(false);
		setTimeout(() => {
			setCheckoutStep("cart");
			setErrorMsg("");
		}, 300);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 overflow-hidden",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			onClick: handleClose,
			className: "absolute inset-0 bg-slate-950/50 backdrop-blur-xs transition-opacity"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-y-0 right-0 max-w-full flex pl-10",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 sm:p-6 border-b border-slate-200 flex items-center justify-between bg-slate-50",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "w-5 h-5 text-slate-800" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("h2", {
								className: "text-base font-bold text-slate-900 font-display",
								children: [
									checkoutStep === "cart" && "Your Shopping Bag",
									checkoutStep === "checkout" && "Checkout & Delivery",
									checkoutStep === "success" && "Order Placed!"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 84,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleClose,
							className: "p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors cursor-pointer",
							children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 81,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1 overflow-y-auto p-4 sm:p-6",
						children: [
							checkoutStep === "cart" && (cart.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
								className: "h-full flex flex-col items-center justify-center text-center text-slate-400 p-8 space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "w-12 h-12 text-slate-300 stroke-1" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 103,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sm font-medium text-slate-600",
										children: "Your bag is empty"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400",
										children: "Add products from the storefront to start shopping."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 105,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleClose,
										className: "mt-2 px-4 py-2 text-xs font-semibold text-slate-800 bg-slate-100 rounded hover:bg-slate-200 cursor-pointer",
										children: "Browse Products"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 106,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: cart.map((item) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200",
									children: [/* @__PURE__ */ _jsxDEV("img", {
										src: item.product.imageUrl,
										alt: item.product.name,
										className: "w-16 h-16 object-cover rounded bg-white border border-slate-200 shrink-0"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 min-w-0 flex flex-col justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] text-slate-400 uppercase tracking-wider",
												children: item.product.category
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 127,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-xs font-semibold text-slate-900 truncate",
												children: item.product.name
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 27
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-mono font-bold text-slate-800 mt-0.5",
												children: ["PKR ", item.product.price.toLocaleString()]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 129,
												columnNumber: 27
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 126,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center border border-slate-200 rounded bg-white",
												children: [
													/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => updateCartQuantity(item.product.id, item.quantity - 1),
														className: "p-1 text-slate-600 hover:bg-slate-100 cursor-pointer",
														children: /* @__PURE__ */ _jsxDEV(Minus, { className: "w-3 h-3" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 140,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 136,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 text-xs font-bold font-mono text-slate-800",
														children: item.quantity
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 142,
														columnNumber: 29
													}, this),
													/* @__PURE__ */ _jsxDEV("button", {
														onClick: () => updateCartQuantity(item.product.id, item.quantity + 1),
														className: "p-1 text-slate-600 hover:bg-slate-100 cursor-pointer",
														children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-3 h-3" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 147,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 143,
														columnNumber: 29
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 135,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => removeFromCart(item.product.id),
												className: "text-slate-400 hover:text-rose-600 p-1 cursor-pointer transition-colors",
												"aria-label": "Remove item",
												children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 156,
													columnNumber: 29
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 151,
												columnNumber: 27
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 134,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 23
									}, this)]
								}, item.product.id, true, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 17
							}, this)),
							checkoutStep === "checkout" && /* @__PURE__ */ _jsxDEV("form", {
								id: "cart-checkout-form",
								onSubmit: handleCheckoutSubmit,
								className: "space-y-4",
								children: [
									errorMsg && /* @__PURE__ */ _jsxDEV("div", {
										className: "p-2.5 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded",
										children: errorMsg
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 mb-1",
										children: "Full Name *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 177,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											placeholder: "Receiver's Name",
											value: fullName,
											onChange: (e) => setFullName(e.target.value),
											className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 mb-1",
										children: "Phone Number *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "tel",
											required: true,
											placeholder: "0300 1234567",
											value: phone,
											onChange: (e) => setPhone(e.target.value),
											className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 mb-1",
											children: "City *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: city,
											onChange: (e) => setCity(e.target.value),
											className: "w-full px-2.5 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none bg-white",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Karachi",
													children: "Karachi"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 212,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Lahore",
													children: "Lahore"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 213,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Islamabad",
													children: "Islamabad"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Rawalpindi",
													children: "Rawalpindi"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 215,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Faisalabad",
													children: "Faisalabad"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 216,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Other",
													children: "Other City"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 217,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 207,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-semibold text-slate-700 mb-1",
											children: "Payment"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: paymentMethod,
											onChange: (e) => setPaymentMethod(e.target.value),
											className: "w-full px-2.5 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none bg-white font-medium",
											children: [/* @__PURE__ */ _jsxDEV("option", {
												value: "cod",
												children: "Cash on Delivery"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 227,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("option", {
												value: "bank_transfer",
												children: "Bank / Online"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 228,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 222,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 220,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 mb-1",
										children: "Delivery Address *"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("textarea", {
											rows: 2,
											required: true,
											placeholder: "Complete House / Street / Flat Address",
											value: deliveryAddress,
											onChange: (e) => setDeliveryAddress(e.target.value),
											className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 237,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 233,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 15
							}, this),
							checkoutStep === "success" && /* @__PURE__ */ _jsxDEV("div", {
								className: "text-center py-8 space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-12 h-12 mx-auto rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center",
										children: /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-7 h-7" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 253,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 252,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs uppercase tracking-wider text-slate-400 font-mono",
											children: "Order Number"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-2xl font-bold font-mono text-slate-900",
											children: placedOrderId
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 257,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600 mt-2",
											children: "Seller dashboard has received this order and delivery preparation has started!"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 258,
											columnNumber: 19
										}, this)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 255,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-4 flex flex-col gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												handleClose();
												setCurrentView("seller");
											},
											className: "w-full py-2.5 bg-slate-900 text-white rounded text-xs font-semibold hover:bg-slate-800 cursor-pointer",
											children: "View in Seller Dashboard"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 263,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: handleClose,
											className: "w-full py-2 bg-slate-100 text-slate-700 rounded text-xs font-semibold hover:bg-slate-200 cursor-pointer",
											children: "Close"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 272,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					checkoutStep !== "success" && cart.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 sm:p-6 border-t border-slate-200 bg-slate-50 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between items-center text-sm",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-500 font-medium",
								children: "Subtotal"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono tabular-nums font-bold text-slate-900 text-base",
								children: ["PKR ", totalAmount.toLocaleString()]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 15
						}, this), checkoutStep === "cart" ? /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setCheckoutStep("checkout"),
							className: "w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Proceed to Checkout" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 298,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 299,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 17
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setCheckoutStep("cart"),
								className: "px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded cursor-pointer",
								children: "Back"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								form: "cart-checkout-form",
								type: "submit",
								className: "flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Confirm Order (COD)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 315,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 316,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 285,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 71,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLEdBQUcsUUFBUSxNQUFNLE9BQU8sWUFBWSxhQUFhLGFBQWEsUUFBUSxPQUFPLFlBQVk7OztBQUdsRyxPQUFPLE1BQU0sbUJBQTZCO0NBQ3hDLE1BQU0sRUFDSixNQUNBLFlBQ0EsZUFDQSxnQkFDQSxvQkFDQSxXQUNBLFlBQ0EsbUJBQ0UsU0FBUztDQUViLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUEwQyxNQUFNO0NBQ3hGLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxRQUFRO0NBQ3pDLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsRUFBRTtDQUN6RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0MsS0FBSztDQUNqRixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsRUFBRTtDQUM3RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMsRUFBRTtDQUUzQyxJQUFJLENBQUMsWUFBWSxPQUFPO0NBRXhCLE1BQU0sY0FBYyxLQUFLLFFBQVEsS0FBSyxTQUFTLE1BQU0sS0FBSyxRQUFRLFFBQVEsS0FBSyxVQUFVLENBQUM7Q0FFMUYsTUFBTSx3QkFBd0IsTUFBdUI7RUFDbkQsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxTQUFTLEtBQUssS0FBSyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsZ0JBQWdCLEtBQUssR0FBRztHQUNoRSxZQUFZLHFDQUFxQztHQUNqRDtFQUNGO0VBRUEsTUFBTSxhQUEwQixLQUFLLEtBQUksT0FBTTtHQUM3QyxXQUFXLEVBQUUsUUFBUTtHQUNyQixhQUFhLEVBQUUsUUFBUTtHQUN2QixPQUFPLEVBQUUsUUFBUTtHQUNqQixVQUFVLEVBQUU7R0FDWixVQUFVLEVBQUUsUUFBUTtFQUN0QixFQUFFO0VBRUYsTUFBTSxRQUFRLFdBQ1o7R0FDRSxVQUFVLFNBQVMsS0FBSztHQUN4QixPQUFPLE1BQU0sS0FBSztHQUNsQixNQUFNLEtBQUssS0FBSztHQUNoQixpQkFBaUIsZ0JBQWdCLEtBQUs7RUFDeEMsR0FDQSxZQUNBLGFBQ0Y7RUFFQSxpQkFBaUIsTUFBTSxXQUFXO0VBQ2xDLFVBQVU7RUFDVixnQkFBZ0IsU0FBUztDQUMzQjtDQUVBLE1BQU0sb0JBQW9CO0VBQ3hCLGNBQWMsS0FBSztFQUNuQixpQkFBaUI7R0FDZixnQkFBZ0IsTUFBTTtHQUN0QixZQUFZLEVBQUU7RUFDaEIsR0FBRyxHQUFHO0NBQ1I7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxPQUFEO0dBQ0UsU0FBUztHQUNULFdBQVU7RUFDWDs7OztZQUVELHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx5QkFBMEI7Ozs7aUJBQ2pELHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0csaUJBQWlCLFVBQVU7U0FDM0IsaUJBQWlCLGNBQWM7U0FDL0IsaUJBQWlCLGFBQWE7UUFDN0I7Ozs7O2VBQ0Q7Ozs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztNQUNsQjs7OztjQUNMOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNHLGlCQUFpQixXQUNoQixLQUFLLFdBQVcsSUFDZCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLG9DQUFxQzs7Ozs7U0FDNUQsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQXFDO1NBQW9COzs7OztTQUN0RSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBeUI7U0FBc0Q7Ozs7O1NBQzVGLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFDWDtTQUVPOzs7OztRQUNMOzs7OztrQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixLQUFLLEtBQUksU0FDUix3QkFBQyxPQUFEO1NBRUUsV0FBVTttQkFGWixDQUlFLHdCQUFDLE9BQUQ7VUFDRSxLQUFLLEtBQUssUUFBUTtVQUNsQixLQUFLLEtBQUssUUFBUTtVQUNsQixXQUFVO1NBQ1g7Ozs7bUJBQ0Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXVELEtBQUssUUFBUTtXQUFjOzs7OztXQUNqRyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBaUQsS0FBSyxRQUFRO1dBQVM7Ozs7O1dBQ3JGLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQW1FLFFBQzVELEtBQUssUUFBUSxNQUFNLGVBQWUsQ0FDcEM7Ozs7OztVQUNGOzs7O29CQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxVQUFEO2NBQ0UsZUFBZSxtQkFBbUIsS0FBSyxRQUFRLElBQUksS0FBSyxXQUFXLENBQUM7Y0FDcEUsV0FBVTt3QkFFVix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OzthQUN0Qjs7Ozs7YUFDUix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBbUQsS0FBSzthQUFlOzs7OzthQUN2Rix3QkFBQyxVQUFEO2NBQ0UsZUFBZSxtQkFBbUIsS0FBSyxRQUFRLElBQUksS0FBSyxXQUFXLENBQUM7Y0FDcEUsV0FBVTt3QkFFVix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OzthQUNyQjs7Ozs7WUFDTDs7Ozs7cUJBRUwsd0JBQUMsVUFBRDtZQUNFLGVBQWUsZUFBZSxLQUFLLFFBQVEsRUFBRTtZQUM3QyxXQUFVO1lBQ1YsY0FBVztzQkFFWCx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztXQUN2Qjs7OzttQkFDTDs7Ozs7a0JBQ0Y7Ozs7O2lCQUNGO1dBM0NFLEtBQUssUUFBUTs7OztlQTJDZixDQUNOO09BQ0U7Ozs7O09BSVIsaUJBQWlCLGNBQ2hCLHdCQUFDLFFBQUQ7UUFBTSxJQUFHO1FBQXFCLFVBQVU7UUFBc0IsV0FBVTtrQkFBeEU7U0FDRyxZQUNDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaO1NBQ0U7Ozs7O1NBR1Asd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFrRDtTQUFrQjs7OzttQkFDckYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxpREFBa0Q7Ozs7b0JBQ2xFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0w7V0FDQSxhQUFZO1dBQ1osT0FBTztXQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxLQUFLO1dBQ3pDLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7aUJBQ0Y7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFrRDtTQUFxQjs7OzttQkFDeEYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxpREFBa0Q7Ozs7b0JBQ25FLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0w7V0FDQSxhQUFZO1dBQ1osT0FBTztXQUNQLFdBQVUsTUFBSyxTQUFTLEVBQUUsT0FBTyxLQUFLO1dBQ3RDLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7aUJBQ0Y7Ozs7O1NBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWtEO1VBQWE7Ozs7b0JBQ2hGLHdCQUFDLFVBQUQ7V0FDRSxPQUFPO1dBQ1AsV0FBVSxNQUFLLFFBQVEsRUFBRSxPQUFPLEtBQUs7V0FDckMsV0FBVTtxQkFIWjtZQUtFLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFVO1lBQWU7Ozs7O1lBQ3ZDLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFTO1lBQWM7Ozs7O1lBQ3JDLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFZO1lBQWlCOzs7OztZQUMzQyx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBYTtZQUFrQjs7Ozs7WUFDN0Msd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQWE7WUFBa0I7Ozs7O1lBQzdDLHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFRO1lBQWtCOzs7OztXQUNsQzs7Ozs7a0JBQ0w7Ozs7b0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFrRDtVQUFjOzs7O29CQUNqRix3QkFBQyxVQUFEO1dBQ0UsT0FBTztXQUNQLFdBQVUsTUFBSyxpQkFBaUIsRUFBRSxPQUFPLEtBQVk7V0FDckQsV0FBVTtxQkFIWixDQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFNO1dBQXdCOzs7O3FCQUM1Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBZ0I7V0FBcUI7Ozs7bUJBQzdDOzs7OztrQkFDTDs7OztrQkFDRjs7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFrRDtTQUF5Qjs7OzttQkFDNUYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxpREFBa0Q7Ozs7b0JBQ3BFLHdCQUFDLFlBQUQ7V0FDRSxNQUFNO1dBQ047V0FDQSxhQUFZO1dBQ1osT0FBTztXQUNQLFdBQVUsTUFBSyxtQkFBbUIsRUFBRSxPQUFPLEtBQUs7V0FDaEQsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztpQkFDRjs7Ozs7UUFDRDs7Ozs7O09BR1AsaUJBQWlCLGFBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7Ozs7U0FDL0I7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE0RDtVQUFpQjs7Ozs7VUFDNUYsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQStDO1VBQW1COzs7OztVQUNqRix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBOEI7VUFFeEM7Ozs7O1NBQ0E7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZTtZQUNiLFlBQVk7WUFDWixlQUFlLFFBQVE7V0FDekI7V0FDQSxXQUFVO3FCQUNYO1VBRU87Ozs7b0JBQ1Isd0JBQUMsVUFBRDtXQUNFLFNBQVM7V0FDVCxXQUFVO3FCQUNYO1VBRU87Ozs7a0JBQ0w7Ozs7OztRQUNGOzs7Ozs7TUFFSjs7Ozs7O0tBR0osaUJBQWlCLGFBQWEsS0FBSyxTQUFTLEtBQzNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBYzs7OztpQkFDM0Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQTRFLFFBQ3JFLFlBQVksZUFBZSxDQUM1Qjs7Ozs7ZUFDSDs7Ozs7Z0JBRUosaUJBQWlCLFNBQ2hCLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGdCQUFnQixVQUFVO09BQ3pDLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2lCQUMvQix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7O2VBQzNCOzs7OztpQkFFUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsZUFBZSxnQkFBZ0IsTUFBTTtRQUNyQyxXQUFVO2tCQUNYO09BRU87Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxNQUFLO1FBQ0wsV0FBVTtrQkFIWixDQUtFLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7a0JBQy9CLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7Z0JBQzNCOzs7OztlQUNMOzs7OztjQUVKOzs7Ozs7SUFHSjs7Ozs7O0VBQ0Y7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2FydERyYXdlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RvcmUgfSBmcm9tICcuLi8uLi9jb250ZXh0L1N0b3JlQ29udGV4dCc7XG5pbXBvcnQgeyBYLCBUcmFzaDIsIFBsdXMsIE1pbnVzLCBBcnJvd1JpZ2h0LCBTaG9wcGluZ0JhZywgU2hpZWxkQ2hlY2ssIE1hcFBpbiwgUGhvbmUsIFVzZXIgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgT3JkZXJJdGVtIH0gZnJvbSAnLi4vLi4vdHlwZXMvc3RvcmUnO1xuXG5leHBvcnQgY29uc3QgQ2FydERyYXdlcjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBjYXJ0LFxuICAgIGlzQ2FydE9wZW4sXG4gICAgc2V0SXNDYXJ0T3BlbixcbiAgICByZW1vdmVGcm9tQ2FydCxcbiAgICB1cGRhdGVDYXJ0UXVhbnRpdHksXG4gICAgY2xlYXJDYXJ0LFxuICAgIHBsYWNlT3JkZXIsXG4gICAgc2V0Q3VycmVudFZpZXdcbiAgfSA9IHVzZVN0b3JlKCk7XG5cbiAgY29uc3QgW2NoZWNrb3V0U3RlcCwgc2V0Q2hlY2tvdXRTdGVwXSA9IHVzZVN0YXRlPCdjYXJ0JyB8ICdjaGVja291dCcgfCAnc3VjY2Vzcyc+KCdjYXJ0Jyk7XG4gIGNvbnN0IFtmdWxsTmFtZSwgc2V0RnVsbE5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NpdHksIHNldENpdHldID0gdXNlU3RhdGUoJ0xhaG9yZScpO1xuICBjb25zdCBbZGVsaXZlcnlBZGRyZXNzLCBzZXREZWxpdmVyeUFkZHJlc3NdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbcGF5bWVudE1ldGhvZCwgc2V0UGF5bWVudE1ldGhvZF0gPSB1c2VTdGF0ZTwnY29kJyB8ICdiYW5rX3RyYW5zZmVyJz4oJ2NvZCcpO1xuICBjb25zdCBbcGxhY2VkT3JkZXJJZCwgc2V0UGxhY2VkT3JkZXJJZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgaWYgKCFpc0NhcnRPcGVuKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCB0b3RhbEFtb3VudCA9IGNhcnQucmVkdWNlKChzdW0sIGl0ZW0pID0+IHN1bSArIGl0ZW0ucHJvZHVjdC5wcmljZSAqIGl0ZW0ucXVhbnRpdHksIDApO1xuXG4gIGNvbnN0IGhhbmRsZUNoZWNrb3V0U3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWZ1bGxOYW1lLnRyaW0oKSB8fCAhcGhvbmUudHJpbSgpIHx8ICFkZWxpdmVyeUFkZHJlc3MudHJpbSgpKSB7XG4gICAgICBzZXRFcnJvck1zZygnUGxlYXNlIGNvbXBsZXRlIGFsbCByZXF1aXJlZCBmaWVsZHMnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBvcmRlckl0ZW1zOiBPcmRlckl0ZW1bXSA9IGNhcnQubWFwKGkgPT4gKHtcbiAgICAgIHByb2R1Y3RJZDogaS5wcm9kdWN0LmlkLFxuICAgICAgcHJvZHVjdE5hbWU6IGkucHJvZHVjdC5uYW1lLFxuICAgICAgcHJpY2U6IGkucHJvZHVjdC5wcmljZSxcbiAgICAgIHF1YW50aXR5OiBpLnF1YW50aXR5LFxuICAgICAgaW1hZ2VVcmw6IGkucHJvZHVjdC5pbWFnZVVybFxuICAgIH0pKTtcblxuICAgIGNvbnN0IG9yZGVyID0gcGxhY2VPcmRlcihcbiAgICAgIHtcbiAgICAgICAgZnVsbE5hbWU6IGZ1bGxOYW1lLnRyaW0oKSxcbiAgICAgICAgcGhvbmU6IHBob25lLnRyaW0oKSxcbiAgICAgICAgY2l0eTogY2l0eS50cmltKCksXG4gICAgICAgIGRlbGl2ZXJ5QWRkcmVzczogZGVsaXZlcnlBZGRyZXNzLnRyaW0oKVxuICAgICAgfSxcbiAgICAgIG9yZGVySXRlbXMsXG4gICAgICBwYXltZW50TWV0aG9kXG4gICAgKTtcblxuICAgIHNldFBsYWNlZE9yZGVySWQob3JkZXIub3JkZXJOdW1iZXIpO1xuICAgIGNsZWFyQ2FydCgpO1xuICAgIHNldENoZWNrb3V0U3RlcCgnc3VjY2VzcycpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsb3NlID0gKCkgPT4ge1xuICAgIHNldElzQ2FydE9wZW4oZmFsc2UpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Q2hlY2tvdXRTdGVwKCdjYXJ0Jyk7XG4gICAgICBzZXRFcnJvck1zZygnJyk7XG4gICAgfSwgMzAwKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgPGRpdiBcbiAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9IFxuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXNsYXRlLTk1MC81MCBiYWNrZHJvcC1ibHVyLXhzIHRyYW5zaXRpb24tb3BhY2l0eVwiIFxuICAgICAgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC15LTAgcmlnaHQtMCBtYXgtdy1mdWxsIGZsZXggcGwtMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LXNjcmVlbiBtYXgtdy1tZCBiZy13aGl0ZSBzaGFkb3ctMnhsIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBzbTpwLTYgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc2xhdGUtNTBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInctNSBoLTUgdGV4dC1zbGF0ZS04MDBcIiAvPlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBmb250LWRpc3BsYXlcIj5cbiAgICAgICAgICAgICAgICB7Y2hlY2tvdXRTdGVwID09PSAnY2FydCcgJiYgJ1lvdXIgU2hvcHBpbmcgQmFnJ31cbiAgICAgICAgICAgICAgICB7Y2hlY2tvdXRTdGVwID09PSAnY2hlY2tvdXQnICYmICdDaGVja291dCAmIERlbGl2ZXJ5J31cbiAgICAgICAgICAgICAgICB7Y2hlY2tvdXRTdGVwID09PSAnc3VjY2VzcycgJiYgJ09yZGVyIFBsYWNlZCEnfVxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXNsYXRlLTcwMCByb3VuZGVkLWxnIGhvdmVyOmJnLXNsYXRlLTIwMC81MCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRHJhd2VyIEJvZHkgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNCBzbTpwLTZcIj5cbiAgICAgICAgICAgIHtjaGVja291dFN0ZXAgPT09ICdjYXJ0JyAmJiAoXG4gICAgICAgICAgICAgIGNhcnQubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtY2VudGVyIHRleHQtc2xhdGUtNDAwIHAtOCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgdGV4dC1zbGF0ZS0zMDAgc3Ryb2tlLTFcIiAvPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMFwiPllvdXIgYmFnIGlzIGVtcHR5PC9wPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkFkZCBwcm9kdWN0cyBmcm9tIHRoZSBzdG9yZWZyb250IHRvIHN0YXJ0IHNob3BwaW5nLjwvcD5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm10LTIgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBiZy1zbGF0ZS0xMDAgcm91bmRlZCBob3ZlcjpiZy1zbGF0ZS0yMDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBCcm93c2UgUHJvZHVjdHNcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICB7Y2FydC5tYXAoaXRlbSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucHJvZHVjdC5pZH1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGdhcC0zIHAtMyBiZy1zbGF0ZS01MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgIHNyYz17aXRlbS5wcm9kdWN0LmltYWdlVXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLnByb2R1Y3QubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTYgaC0xNiBvYmplY3QtY292ZXIgcm91bmRlZCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaHJpbmstMFwiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPntpdGVtLnByb2R1Y3QuY2F0ZWdvcnl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgdHJ1bmNhdGVcIj57aXRlbS5wcm9kdWN0Lm5hbWV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgUEtSIHtpdGVtLnByb2R1Y3QucHJpY2UudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbXQtMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAvNjBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGJnLXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBkYXRlQ2FydFF1YW50aXR5KGl0ZW0ucHJvZHVjdC5pZCwgaXRlbS5xdWFudGl0eSAtIDEpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1pbnVzIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vIHRleHQtc2xhdGUtODAwXCI+e2l0ZW0ucXVhbnRpdHl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZUNhcnRRdWFudGl0eShpdGVtLnByb2R1Y3QuaWQsIGl0ZW0ucXVhbnRpdHkgKyAxKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMSB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlRnJvbUNhcnQoaXRlbS5wcm9kdWN0LmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXJvc2UtNjAwIHAtMSBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZSBpdGVtXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtjaGVja291dFN0ZXAgPT09ICdjaGVja291dCcgJiYgKFxuICAgICAgICAgICAgICA8Zm9ybSBpZD1cImNhcnQtY2hlY2tvdXQtZm9ybVwiIG9uU3VibWl0PXtoYW5kbGVDaGVja291dFN1Ym1pdH0gY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAge2Vycm9yTXNnICYmIChcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgdGV4dC14cyB0ZXh0LXJvc2UtNzAwIGJnLXJvc2UtNTAgYm9yZGVyIGJvcmRlci1yb3NlLTIwMCByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIHtlcnJvck1zZ31cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+RnVsbCBOYW1lICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICA8VXNlciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZWNlaXZlcidzIE5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWxsTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGdWxsTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5QaG9uZSBOdW1iZXIgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxQaG9uZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRlbFwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjAzMDAgMTIzNDU2N1wiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bob25lfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBob25lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+Q2l0eSAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjaXR5fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldENpdHkoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0yLjUgcHktMiB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9jdXM6Ym9yZGVyLXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmUgYmctd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkthcmFjaGlcIj5LYXJhY2hpPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhaG9yZVwiPkxhaG9yZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJc2xhbWFiYWRcIj5Jc2xhbWFiYWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUmF3YWxwaW5kaVwiPlJhd2FscGluZGk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRmFpc2FsYWJhZFwiPkZhaXNhbGFiYWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlciBDaXR5PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5QYXltZW50PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXltZW50TWV0aG9kfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldFBheW1lbnRNZXRob2QoZS50YXJnZXQudmFsdWUgYXMgYW55KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMi41IHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIGJnLXdoaXRlIGZvbnQtbWVkaXVtXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJjb2RcIj5DYXNoIG9uIERlbGl2ZXJ5PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImJhbmtfdHJhbnNmZXJcIj5CYW5rIC8gT25saW5lPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+RGVsaXZlcnkgQWRkcmVzcyAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgcm93cz17Mn1cbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ29tcGxldGUgSG91c2UgLyBTdHJlZXQgLyBGbGF0IEFkZHJlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkZWxpdmVyeUFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RGVsaXZlcnlBZGRyZXNzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Y2hlY2tvdXRTdGVwID09PSAnc3VjY2VzcycgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTggc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgbXgtYXV0byByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy03IGgtN1wiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+T3JkZXIgTnVtYmVyPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCBmb250LW1vbm8gdGV4dC1zbGF0ZS05MDBcIj57cGxhY2VkT3JkZXJJZH08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICBTZWxsZXIgZGFzaGJvYXJkIGhhcyByZWNlaXZlZCB0aGlzIG9yZGVyIGFuZCBkZWxpdmVyeSBwcmVwYXJhdGlvbiBoYXMgc3RhcnRlZCFcbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTQgZmxleCBmbGV4LWNvbCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRDdXJyZW50Vmlldygnc2VsbGVyJyk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctc2xhdGUtOTAwIHRleHQtd2hpdGUgcm91bmRlZCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgaG92ZXI6Ymctc2xhdGUtODAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgVmlldyBpbiBTZWxsZXIgRGFzaGJvYXJkXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xvc2V9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIGJnLXNsYXRlLTEwMCB0ZXh0LXNsYXRlLTcwMCByb3VuZGVkIHRleHQteHMgZm9udC1zZW1pYm9sZCBob3ZlcjpiZy1zbGF0ZS0yMDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBDbG9zZVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBEcmF3ZXIgRm9vdGVyICovfVxuICAgICAgICAgIHtjaGVja291dFN0ZXAgIT09ICdzdWNjZXNzJyAmJiBjYXJ0Lmxlbmd0aCA+IDAgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgc206cC02IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bVwiPlN1YnRvdGFsPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICAgICAgUEtSIHt0b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2NoZWNrb3V0U3RlcCA9PT0gJ2NhcnQnID8gKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENoZWNrb3V0U3RlcCgnY2hlY2tvdXQnKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdGV4dC14cyByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Qcm9jZWVkIHRvIENoZWNrb3V0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDaGVja291dFN0ZXAoJ2NhcnQnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yLjUgYmctc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTcwMCBmb250LXNlbWlib2xkIHRleHQteHMgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIEJhY2tcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBmb3JtPVwiY2FydC1jaGVja291dC1mb3JtXCJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yLjUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXdoaXRlIGZvbnQtc2VtaWJvbGQgdGV4dC14cyByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29uZmlybSBPcmRlciAoQ09EKTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=