const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { X, CheckCircle2, ShieldCheck, Truck, Plus, Minus, ArrowRight, Phone, MapPin, User, FileText } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/buyer/QuickOrderModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const QuickOrderModal = ({ product, onClose }) => {
	const { placeOrder, setCurrentView } = useStore();
	const [quantity, setQuantity] = useState(1);
	const [fullName, setFullName] = useState("");
	const [phone, setPhone] = useState("");
	const [city, setCity] = useState("Karachi");
	const [deliveryAddress, setDeliveryAddress] = useState("");
	const [deliveryNote, setDeliveryNote] = useState("");
	const [paymentMethod, setPaymentMethod] = useState("cod");
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [placedOrder, setPlacedOrder] = useState(null);
	const [errorMsg, setErrorMsg] = useState("");
	if (!product) return null;
	const subtotal = product.price * quantity;
	const shippingFee = 0;
	const grandTotal = subtotal + shippingFee;
	const handleSubmitOrder = (e) => {
		e.preventDefault();
		setErrorMsg("");
		if (!fullName.trim()) {
			setErrorMsg("Please enter your full name");
			return;
		}
		if (!phone.trim() || phone.trim().length < 8) {
			setErrorMsg("Please enter a valid phone number (e.g. 0300-1234567)");
			return;
		}
		if (!deliveryAddress.trim() || deliveryAddress.trim().length < 10) {
			setErrorMsg("Please provide a complete street / house delivery address");
			return;
		}
		setIsSubmitting(true);
		try {
			const order = placeOrder({
				fullName: fullName.trim(),
				phone: phone.trim(),
				city: city.trim(),
				deliveryAddress: deliveryAddress.trim(),
				deliveryNote: deliveryNote.trim() || undefined
			}, [{
				productId: product.id,
				productName: product.name,
				price: product.price,
				quantity,
				imageUrl: product.imageUrl
			}], paymentMethod);
			setPlacedOrder(order);
		} catch (err) {
			setErrorMsg(err?.message || "Could not place order. Please try again.");
		} finally {
			setIsSubmitting(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-lg font-bold text-slate-900 font-display",
					children: placedOrder ? "Order Confirmed!" : "Express Checkout / Quick Order"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: placedOrder ? "Your order has been forwarded to the seller dashboard" : "Complete the simple form below to place your order"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors cursor-pointer",
					"aria-label": "Close modal",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 101,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 96,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 9
			}, this), placedOrder ? /* @__PURE__ */ _jsxDEV(
				"div",
				/* Success Screen */
				{
					className: "p-6 text-center space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "w-16 h-16 mx-auto rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100",
							children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs uppercase tracking-wider text-slate-400 font-mono",
									children: "Order Tracking ID"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-2xl font-bold font-mono tabular-nums text-slate-900",
									children: placedOrder.orderNumber
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-sm text-slate-600 max-w-md mx-auto",
									children: [
										"Thank you, ",
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-slate-900",
											children: placedOrder.customer.fullName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 121,
											columnNumber: 28
										}, this),
										"! Your order has been placed successfully via ",
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold uppercase",
											children: placedOrder.paymentMethod
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 121,
											columnNumber: 159
										}, this),
										"."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 120,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-50 border border-slate-200 rounded-lg p-4 text-left text-xs space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center pb-2 border-b border-slate-200",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-700",
										children: "Item Summary"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 128,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono tabular-nums text-slate-900",
										children: [
											quantity,
											"x ",
											product.name
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center text-slate-600",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Delivery Location:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-medium text-slate-800 text-right max-w-xs truncate",
										children: [
											placedOrder.customer.city,
											", ",
											placedOrder.customer.deliveryAddress
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center text-slate-600",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Contact Phone:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-800",
										children: placedOrder.customer.phone
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between items-center pt-2 border-t border-slate-200 text-sm font-bold text-slate-900",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total Amount Payable (COD):" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 144,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono tabular-nums",
										children: ["PKR ", placedOrder.totalAmount.toLocaleString()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 145,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row items-center justify-center gap-3 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: onClose,
								className: "w-full sm:w-auto px-5 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer",
								children: "Continue Shopping"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									onClose();
									setCurrentView("seller");
								},
								className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "View in Seller Hub" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 157,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 149,
							columnNumber: 13
						}, this)
					]
				},
				void 0,
				true,
				{
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 11
				},
				this
			) : 
			/* Order Form */
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmitOrder,
				className: "p-6 space-y-5",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4 p-3 bg-slate-50 rounded-lg border border-slate-200",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: product.imageUrl,
								alt: product.name,
								referrerPolicy: "no-referrer",
								className: "w-16 h-16 object-cover rounded bg-white border border-slate-200 shrink-0"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-400 uppercase tracking-wider block",
										children: product.category
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 181,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-sm font-semibold text-slate-900 truncate",
										children: product.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs font-mono font-bold text-slate-800 mt-0.5",
										children: [
											"PKR ",
											product.price.toLocaleString(),
											" each"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center border border-slate-200 rounded bg-white",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setQuantity((q) => Math.max(1, q - 1)),
										disabled: quantity <= 1,
										className: "p-1.5 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer",
										children: /* @__PURE__ */ _jsxDEV(Minus, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "px-2.5 text-xs font-bold font-mono text-slate-800",
										children: quantity
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 198,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setQuantity((q) => Math.min(product.stockCount || 10, q + 1)),
										disabled: quantity >= product.stockCount,
										className: "p-1.5 text-slate-600 hover:bg-slate-100 disabled:opacity-30 cursor-pointer",
										children: /* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 13
					}, this),
					errorMsg && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded",
						children: errorMsg
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 mb-1",
									children: ["Full Name ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 31
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 221,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative",
									children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										required: true,
										placeholder: "e.g. Tariq Mehmood",
										value: fullName,
										onChange: (e) => setFullName(e.target.value),
										className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 226,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-semibold text-slate-700 mb-1",
									children: ["Phone / WhatsApp Number ", /* @__PURE__ */ _jsxDEV("span", {
										className: "text-rose-500",
										children: "*"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 240,
										columnNumber: 45
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "relative",
									children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 243,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "tel",
										required: true,
										placeholder: "e.g. 0300 1234567",
										value: phone,
										onChange: (e) => setPhone(e.target.value),
										className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors font-mono"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 244,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 238,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-1",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 mb-1",
										children: ["City ", /* @__PURE__ */ _jsxDEV("span", {
											className: "text-rose-500",
											children: "*"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 260,
											columnNumber: 26
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 259,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("select", {
										value: city,
										onChange: (e) => setCity(e.target.value),
										className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none bg-white transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Karachi",
												children: "Karachi"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 267,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Lahore",
												children: "Lahore"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 268,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Islamabad",
												children: "Islamabad"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 269,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Rawalpindi",
												children: "Rawalpindi"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 270,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Faisalabad",
												children: "Faisalabad"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 271,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Multan",
												children: "Multan"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 272,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Peshawar",
												children: "Peshawar"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 273,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Quetta",
												children: "Quetta"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 274,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Sialkot",
												children: "Sialkot"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 275,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("option", {
												value: "Other",
												children: "Other City"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 276,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 262,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 258,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-semibold text-slate-700 mb-1",
										children: ["Complete Delivery Address / Location ", /* @__PURE__ */ _jsxDEV("span", {
											className: "text-rose-500",
											children: "*"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 283,
											columnNumber: 58
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 282,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "relative",
										children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 286,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											placeholder: "House/Flat #, Street #, Sector / Colony",
											value: deliveryAddress,
											onChange: (e) => setDeliveryAddress(e.target.value),
											className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 287,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 285,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 257,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 mb-1",
								children: "Delivery Instruction / Nearest Landmark (Optional)"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative",
								children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "e.g. Near PSO Pump, Call before arriving",
									value: deliveryNote,
									onChange: (e) => setDeliveryNote(e.target.value),
									className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 300,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-semibold text-slate-700 mb-1.5",
								children: "Payment Method"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 318,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setPaymentMethod("cod"),
									className: `p-2.5 rounded border text-left flex items-center justify-between cursor-pointer transition-colors ${paymentMethod === "cod" ? "border-slate-900 bg-slate-900/5 text-slate-900" : "border-slate-200 hover:border-slate-300 text-slate-600"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-semibold block",
										children: "Cash on Delivery (COD)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500",
										children: "Pay cash upon delivery"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 331,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Truck, { className: "w-4 h-4 text-slate-700 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setPaymentMethod("bank_transfer"),
									className: `p-2.5 rounded border text-left flex items-center justify-between cursor-pointer transition-colors ${paymentMethod === "bank_transfer" ? "border-slate-900 bg-slate-900/5 text-slate-900" : "border-slate-200 hover:border-slate-300 text-slate-600"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-semibold block",
										children: "Bank / EasyPaisa / JazzCash"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 348,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500",
										children: "Manual verification"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 347,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-slate-700 shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 351,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 321,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 317,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-3 border-t border-slate-200 space-y-1.5 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: [
									"Subtotal (",
									quantity,
									" ",
									quantity === 1 ? "item" : "items",
									"):"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 360,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono tabular-nums",
									children: ["PKR ", subtotal.toLocaleString()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 359,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between text-slate-500",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Nationwide Shipping:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-emerald-600 font-semibold",
									children: "FREE"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 365,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-100",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total Amount:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono tabular-nums",
									children: ["PKR ", grandTotal.toLocaleString()]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 369,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 358,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isSubmitting,
							className: "w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-semibold text-xs rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm",
							children: isSubmitting ? /* @__PURE__ */ _jsxDEV("span", { children: "Processing Order..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 381,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Place Order · PKR ", grandTotal.toLocaleString()] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 384,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 385,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-center gap-4 text-[11px] text-slate-400 mt-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 19
									}, this), " No advance payment needed"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV(Truck, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 395,
										columnNumber: 19
									}, this), " 2-4 days express delivery"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 394,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 171,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 81,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQjtBQUV6QixTQUFTLEdBQUcsY0FBYyxhQUFhLE9BQU8sTUFBTSxPQUFPLFlBQVksT0FBTyxRQUFRLE1BQU0sZ0JBQWdCOzs7QUFPNUcsT0FBTyxNQUFNLG1CQUFtRCxFQUFFLFNBQVMsY0FBYztDQUN2RixNQUFNLEVBQUUsWUFBWSxtQkFBbUIsU0FBUztDQUVoRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLENBQUM7Q0FDbEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixFQUFFO0NBQ25ELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBaUIsRUFBRTtDQUM3QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQWlCLFNBQVM7Q0FDbEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBaUIsRUFBRTtDQUNqRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsRUFBRTtDQUMzRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0MsS0FBSztDQUVqRixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBdUIsSUFBSTtDQUNqRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEVBQUU7Q0FFbkQsSUFBSSxDQUFDLFNBQVMsT0FBTztDQUVyQixNQUFNLFdBQVcsUUFBUSxRQUFRO0NBQ2pDLE1BQU0sY0FBYztDQUNwQixNQUFNLGFBQWEsV0FBVztDQUU5QixNQUFNLHFCQUFxQixNQUF1QjtFQUNoRCxFQUFFLGVBQWU7RUFDakIsWUFBWSxFQUFFO0VBRWQsSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHO0dBQ3BCLFlBQVksNkJBQTZCO0dBQ3pDO0VBQ0Y7RUFDQSxJQUFJLENBQUMsTUFBTSxLQUFLLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLEdBQUc7R0FDNUMsWUFBWSx1REFBdUQ7R0FDbkU7RUFDRjtFQUNBLElBQUksQ0FBQyxnQkFBZ0IsS0FBSyxLQUFLLGdCQUFnQixLQUFLLENBQUMsQ0FBQyxTQUFTLElBQUk7R0FDakUsWUFBWSwyREFBMkQ7R0FDdkU7RUFDRjtFQUVBLGdCQUFnQixJQUFJO0VBRXBCLElBQUk7R0FDRixNQUFNLFFBQVEsV0FDWjtJQUNFLFVBQVUsU0FBUyxLQUFLO0lBQ3hCLE9BQU8sTUFBTSxLQUFLO0lBQ2xCLE1BQU0sS0FBSyxLQUFLO0lBQ2hCLGlCQUFpQixnQkFBZ0IsS0FBSztJQUN0QyxjQUFjLGFBQWEsS0FBSyxLQUFLO0dBQ3ZDLEdBQ0EsQ0FDRTtJQUNFLFdBQVcsUUFBUTtJQUNuQixhQUFhLFFBQVE7SUFDckIsT0FBTyxRQUFRO0lBQ2Y7SUFDQSxVQUFVLFFBQVE7R0FDcEIsQ0FDRixHQUNBLGFBQ0Y7R0FFQSxlQUFlLEtBQUs7RUFDdEIsU0FBUyxLQUFVO0dBQ2pCLFlBQVksS0FBSyxXQUFXLDBDQUEwQztFQUN4RSxVQUFVO0dBQ1IsZ0JBQWdCLEtBQUs7RUFDdkI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLGNBQWMscUJBQXFCO0lBQ2xDOzs7O2NBQ0osd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixjQUNHLDBEQUNBO0lBQ0g7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtLQUNWLGNBQVc7ZUFFWCx3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztJQUNsQjs7OztZQUNMOzs7OzthQUdKLGNBRUM7SUFBQzs7SUFBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFlBQWE7Ozs7O01BQ2xDOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQTREO1FBRXRFOzs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFlBQVk7UUFDVjs7Ozs7UUFDTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUF1RDtVQUMxQyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0MsWUFBWSxTQUFTO1VBQWU7Ozs7O1VBQUM7VUFBOEMsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTJCLFlBQVk7VUFBb0I7Ozs7O1VBQUM7U0FDek47Ozs7OztPQUNBOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQStCO1NBQWtCOzs7O21CQUNqRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEI7V0FDRztXQUFTO1dBQUcsUUFBUTtVQUNqQjs7Ozs7aUJBQ0g7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OzttQkFDOUIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCO1dBQ0csWUFBWSxTQUFTO1dBQUs7V0FBRyxZQUFZLFNBQVM7VUFDL0M7Ozs7O2lCQUNIOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7bUJBQzFCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0QixZQUFZLFNBQVM7U0FBWTs7OztpQkFDMUU7Ozs7OztRQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7OzttQkFDdkMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQXlDLFFBQUssWUFBWSxZQUFZLGVBQWUsQ0FBUTs7Ozs7aUJBQzFGOzs7Ozs7T0FDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFFUix3QkFBQyxVQUFEO1FBQ0UsZUFBZTtTQUNiLFFBQVE7U0FDUixlQUFlLFFBQVE7UUFDekI7UUFDQSxXQUFVO2tCQUxaLENBT0Usd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztrQkFDOUIsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztnQkFDM0I7Ozs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7Ozs7Ozs7R0FHTCx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFtQixXQUFVO2NBQTdDO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQ0UsS0FBSyxRQUFRO1FBQ2IsS0FBSyxRQUFRO1FBQ2IsZ0JBQWU7UUFDZixXQUFVO09BQ1g7Ozs7O09BQ0Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkQsUUFBUTtTQUFlOzs7OztTQUNwRyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBaUQsUUFBUTtTQUFTOzs7OztTQUNoRix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUFtRTtXQUM1RCxRQUFRLE1BQU0sZUFBZTtXQUFFO1VBQ2pDOzs7Ozs7UUFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsYUFBWSxNQUFLLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO1VBQ2xELFVBQVUsWUFBWTtVQUN0QixXQUFVO29CQUVWLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7O1NBQzFCOzs7OztTQUNSLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFxRDtTQUFlOzs7OztTQUNwRix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsYUFBWSxNQUFLLEtBQUssSUFBSSxRQUFRLGNBQWMsSUFBSSxJQUFJLENBQUMsQ0FBQztVQUN6RSxVQUFVLFlBQVksUUFBUTtVQUM5QixXQUFVO29CQUVWLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7O1NBQ3pCOzs7OztRQUNMOzs7Ozs7TUFDRjs7Ozs7O0tBRUosWUFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWjtLQUNFOzs7OztLQUlQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FFRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQWpCLENBQW1FLGNBQ3ZELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFPOzs7O2lCQUM1Qzs7Ozs7a0JBQ1Asd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxxRUFBc0U7Ozs7bUJBQ3RGLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0w7VUFDQSxhQUFZO1VBQ1osT0FBTztVQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxLQUFLO1VBQ3pDLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7Z0JBQ0Y7Ozs7a0JBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUFtRSw0QkFDekMsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWdCO1NBQU87Ozs7aUJBQzFEOzs7OztrQkFDUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHFFQUFzRTs7OzttQkFDdkYsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTDtVQUNBLGFBQVk7VUFDWixPQUFPO1VBQ1AsV0FBVSxNQUFLLFNBQVMsRUFBRSxPQUFPLEtBQUs7VUFDdEMsV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztnQkFDRjs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUFtRSxTQUM1RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0I7VUFBTzs7OztrQkFDdkM7Ozs7O21CQUNQLHdCQUFDLFVBQUQ7VUFDRSxPQUFPO1VBQ1AsV0FBVSxNQUFLLFFBQVEsRUFBRSxPQUFPLEtBQUs7VUFDckMsV0FBVTtvQkFIWjtXQUtFLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFVO1dBQWU7Ozs7O1dBQ3ZDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFTO1dBQWM7Ozs7O1dBQ3JDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFZO1dBQWlCOzs7OztXQUMzQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBYTtXQUFrQjs7Ozs7V0FDN0Msd0JBQUMsVUFBRDtZQUFRLE9BQU07c0JBQWE7V0FBa0I7Ozs7O1dBQzdDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFTO1dBQWM7Ozs7O1dBQ3JDLHdCQUFDLFVBQUQ7WUFBUSxPQUFNO3NCQUFXO1dBQWdCOzs7OztXQUN6Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUztXQUFjOzs7OztXQUNyQyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBVTtXQUFlOzs7OztXQUN2Qyx3QkFBQyxVQUFEO1lBQVEsT0FBTTtzQkFBUTtXQUFrQjs7Ozs7VUFDbEM7Ozs7O2lCQUNMOzs7OztrQkFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUFqQixDQUFtRSx5Q0FDNUIsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQU87Ozs7a0JBQ3ZFOzs7OzttQkFDUCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHFFQUFzRTs7OztvQkFDeEYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTDtXQUNBLGFBQVk7V0FDWixPQUFPO1dBQ1AsV0FBVSxNQUFLLG1CQUFtQixFQUFFLE9BQU8sS0FBSztXQUNoRCxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O2lCQUNGOzs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUFrRDtPQUU1RDs7OztpQkFDUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHFFQUFzRTs7OztrQkFDMUYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVUsTUFBSyxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7U0FDN0MsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztlQUNGOzs7OztPQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFBb0Q7T0FFOUQ7Ozs7aUJBQ1Asd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsaUJBQWlCLEtBQUs7U0FDckMsV0FBVyxxR0FDVCxrQkFBa0IsUUFDZCxtREFDQTttQkFOUixDQVNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBOEI7U0FBNEI7Ozs7bUJBQzFFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QjtTQUE0Qjs7OztpQkFDdEU7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxFQUFPLFdBQVUsa0NBQW1DOzs7O2lCQUM5Qzs7Ozs7a0JBRVIsd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLGlCQUFpQixlQUFlO1NBQy9DLFdBQVcscUdBQ1Qsa0JBQWtCLGtCQUNkLG1EQUNBO21CQU5SLENBU0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE4QjtTQUFpQzs7OzttQkFDL0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZCO1NBQXlCOzs7O2lCQUNuRTs7OzttQkFDTCx3QkFBQyxhQUFELEVBQWEsV0FBVSxrQ0FBbUM7Ozs7aUJBQ3BEOzs7OztnQkFDTDs7Ozs7ZUFDRjs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTTtTQUFXO1NBQVM7U0FBRSxhQUFhLElBQUksU0FBUztTQUFRO1FBQVE7Ozs7a0JBQ3RFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUF5QyxRQUFLLFNBQVMsZUFBZSxDQUFROzs7OztnQkFDM0U7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OztrQkFDaEMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJDO1FBQVU7Ozs7Z0JBQ2xFOzs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7a0JBQ3pCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUF5QyxRQUFLLFdBQVcsZUFBZSxDQUFROzs7OztnQkFDN0U7Ozs7OztNQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFBVTtPQUNWLFdBQVU7aUJBRVQsZUFDQyx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2tCQUUvQixnREFDRSx3QkFBQyxRQUFELGFBQU0sc0JBQW1CLFdBQVcsZUFBZSxDQUFROzs7O2lCQUMzRCx3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7O2VBQ2pDOzs7OztNQUVFOzs7O2dCQUNSLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsY0FBZTs7OzttQkFBQyw0QkFDbkM7Ozs7OztRQUNOLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztRQUNiLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7bUJBQUMsNEJBQzdCOzs7Ozs7T0FDSDs7Ozs7Y0FDRjs7Ozs7O0lBQ0Q7Ozs7O1dBR0w7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlF1aWNrT3JkZXJNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RvcmUgfSBmcm9tICcuLi8uLi9jb250ZXh0L1N0b3JlQ29udGV4dCc7XG5pbXBvcnQgeyBQcm9kdWN0LCBPcmRlciB9IGZyb20gJy4uLy4uL3R5cGVzL3N0b3JlJztcbmltcG9ydCB7IFgsIENoZWNrQ2lyY2xlMiwgU2hpZWxkQ2hlY2ssIFRydWNrLCBQbHVzLCBNaW51cywgQXJyb3dSaWdodCwgUGhvbmUsIE1hcFBpbiwgVXNlciwgRmlsZVRleHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgUXVpY2tPcmRlck1vZGFsUHJvcHMge1xuICBwcm9kdWN0OiBQcm9kdWN0IHwgbnVsbDtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFF1aWNrT3JkZXJNb2RhbDogUmVhY3QuRkM8UXVpY2tPcmRlck1vZGFsUHJvcHM+ID0gKHsgcHJvZHVjdCwgb25DbG9zZSB9KSA9PiB7XG4gIGNvbnN0IHsgcGxhY2VPcmRlciwgc2V0Q3VycmVudFZpZXcgfSA9IHVzZVN0b3JlKCk7XG5cbiAgY29uc3QgW3F1YW50aXR5LCBzZXRRdWFudGl0eV0gPSB1c2VTdGF0ZTxudW1iZXI+KDEpO1xuICBjb25zdCBbZnVsbE5hbWUsIHNldEZ1bGxOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbY2l0eSwgc2V0Q2l0eV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdLYXJhY2hpJyk7XG4gIGNvbnN0IFtkZWxpdmVyeUFkZHJlc3MsIHNldERlbGl2ZXJ5QWRkcmVzc10gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2RlbGl2ZXJ5Tm90ZSwgc2V0RGVsaXZlcnlOb3RlXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbcGF5bWVudE1ldGhvZCwgc2V0UGF5bWVudE1ldGhvZF0gPSB1c2VTdGF0ZTwnY29kJyB8ICdiYW5rX3RyYW5zZmVyJz4oJ2NvZCcpO1xuXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtwbGFjZWRPcmRlciwgc2V0UGxhY2VkT3JkZXJdID0gdXNlU3RhdGU8T3JkZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Vycm9yTXNnLCBzZXRFcnJvck1zZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcblxuICBpZiAoIXByb2R1Y3QpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHN1YnRvdGFsID0gcHJvZHVjdC5wcmljZSAqIHF1YW50aXR5O1xuICBjb25zdCBzaGlwcGluZ0ZlZSA9IDA7IC8vIEZyZWUgZGVsaXZlcnkgb2ZmZXJcbiAgY29uc3QgZ3JhbmRUb3RhbCA9IHN1YnRvdGFsICsgc2hpcHBpbmdGZWU7XG5cbiAgY29uc3QgaGFuZGxlU3VibWl0T3JkZXIgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEVycm9yTXNnKCcnKTtcblxuICAgIGlmICghZnVsbE5hbWUudHJpbSgpKSB7XG4gICAgICBzZXRFcnJvck1zZygnUGxlYXNlIGVudGVyIHlvdXIgZnVsbCBuYW1lJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghcGhvbmUudHJpbSgpIHx8IHBob25lLnRyaW0oKS5sZW5ndGggPCA4KSB7XG4gICAgICBzZXRFcnJvck1zZygnUGxlYXNlIGVudGVyIGEgdmFsaWQgcGhvbmUgbnVtYmVyIChlLmcuIDAzMDAtMTIzNDU2NyknKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFkZWxpdmVyeUFkZHJlc3MudHJpbSgpIHx8IGRlbGl2ZXJ5QWRkcmVzcy50cmltKCkubGVuZ3RoIDwgMTApIHtcbiAgICAgIHNldEVycm9yTXNnKCdQbGVhc2UgcHJvdmlkZSBhIGNvbXBsZXRlIHN0cmVldCAvIGhvdXNlIGRlbGl2ZXJ5IGFkZHJlc3MnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBzZXRJc1N1Ym1pdHRpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgb3JkZXIgPSBwbGFjZU9yZGVyKFxuICAgICAgICB7XG4gICAgICAgICAgZnVsbE5hbWU6IGZ1bGxOYW1lLnRyaW0oKSxcbiAgICAgICAgICBwaG9uZTogcGhvbmUudHJpbSgpLFxuICAgICAgICAgIGNpdHk6IGNpdHkudHJpbSgpLFxuICAgICAgICAgIGRlbGl2ZXJ5QWRkcmVzczogZGVsaXZlcnlBZGRyZXNzLnRyaW0oKSxcbiAgICAgICAgICBkZWxpdmVyeU5vdGU6IGRlbGl2ZXJ5Tm90ZS50cmltKCkgfHwgdW5kZWZpbmVkXG4gICAgICAgIH0sXG4gICAgICAgIFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBwcm9kdWN0SWQ6IHByb2R1Y3QuaWQsXG4gICAgICAgICAgICBwcm9kdWN0TmFtZTogcHJvZHVjdC5uYW1lLFxuICAgICAgICAgICAgcHJpY2U6IHByb2R1Y3QucHJpY2UsXG4gICAgICAgICAgICBxdWFudGl0eSxcbiAgICAgICAgICAgIGltYWdlVXJsOiBwcm9kdWN0LmltYWdlVXJsXG4gICAgICAgICAgfVxuICAgICAgICBdLFxuICAgICAgICBwYXltZW50TWV0aG9kXG4gICAgICApO1xuXG4gICAgICBzZXRQbGFjZWRPcmRlcihvcmRlcik7XG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgIHNldEVycm9yTXNnKGVycj8ubWVzc2FnZSB8fCAnQ291bGQgbm90IHBsYWNlIG9yZGVyLiBQbGVhc2UgdHJ5IGFnYWluLicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1zbGF0ZS05NTAvNjAgYmFja2Ryb3AtYmx1ci14cyBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LXhsIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBvdmVyZmxvdy1oaWRkZW4gbXktOCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLXNsYXRlLTUwXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBmb250LWRpc3BsYXlcIj5cbiAgICAgICAgICAgICAge3BsYWNlZE9yZGVyID8gJ09yZGVyIENvbmZpcm1lZCEnIDogJ0V4cHJlc3MgQ2hlY2tvdXQgLyBRdWljayBPcmRlcid9XG4gICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICB7cGxhY2VkT3JkZXIgXG4gICAgICAgICAgICAgICAgPyAnWW91ciBvcmRlciBoYXMgYmVlbiBmb3J3YXJkZWQgdG8gdGhlIHNlbGxlciBkYXNoYm9hcmQnIFxuICAgICAgICAgICAgICAgIDogJ0NvbXBsZXRlIHRoZSBzaW1wbGUgZm9ybSBiZWxvdyB0byBwbGFjZSB5b3VyIG9yZGVyJ31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkNsb3NlIG1vZGFsXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1vZGFsIENvbnRlbnQgKi99XG4gICAgICAgIHtwbGFjZWRPcmRlciA/IChcbiAgICAgICAgICAvKiBTdWNjZXNzIFNjcmVlbiAqL1xuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHRleHQtY2VudGVyIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE2IGgtMTYgbXgtYXV0byByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlciBib3JkZXItZW1lcmFsZC0xMDBcIj5cbiAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTEwIGgtMTBcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgT3JkZXIgVHJhY2tpbmcgSURcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICB7cGxhY2VkT3JkZXIub3JkZXJOdW1iZXJ9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIG1heC13LW1kIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICBUaGFuayB5b3UsIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57cGxhY2VkT3JkZXIuY3VzdG9tZXIuZnVsbE5hbWV9PC9zcGFuPiEgWW91ciBvcmRlciBoYXMgYmVlbiBwbGFjZWQgc3VjY2Vzc2Z1bGx5IHZpYSA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHVwcGVyY2FzZVwiPntwbGFjZWRPcmRlci5wYXltZW50TWV0aG9kfTwvc3Bhbj4uXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUmVjZWlwdCBDYXJkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHAtNCB0ZXh0LWxlZnQgdGV4dC14cyBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMFwiPkl0ZW0gU3VtbWFyeTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICB7cXVhbnRpdHl9eCB7cHJvZHVjdC5uYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+RGVsaXZlcnkgTG9jYXRpb246PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtc2xhdGUtODAwIHRleHQtcmlnaHQgbWF4LXcteHMgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgIHtwbGFjZWRPcmRlci5jdXN0b21lci5jaXR5fSwge3BsYWNlZE9yZGVyLmN1c3RvbWVyLmRlbGl2ZXJ5QWRkcmVzc31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNvbnRhY3QgUGhvbmU6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNsYXRlLTgwMFwiPntwbGFjZWRPcmRlci5jdXN0b21lci5waG9uZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Ub3RhbCBBbW91bnQgUGF5YWJsZSAoQ09EKTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtc1wiPlBLUiB7cGxhY2VkT3JkZXIudG90YWxBbW91bnQudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgc206dy1hdXRvIHB4LTUgcHktMi41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ29udGludWUgU2hvcHBpbmdcbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIG9uQ2xvc2UoKTtcbiAgICAgICAgICAgICAgICAgIHNldEN1cnJlbnRWaWV3KCdzZWxsZXInKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTUgcHktMi41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj5WaWV3IGluIFNlbGxlciBIdWI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgLyogT3JkZXIgRm9ybSAqL1xuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXRPcmRlcn0gY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNVwiPlxuICAgICAgICAgICAgey8qIFByb2R1Y3QgU3VtbWFyeSBSb3cgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHAtMyBiZy1zbGF0ZS01MCByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICBzcmM9e3Byb2R1Y3QuaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgYWx0PXtwcm9kdWN0Lm5hbWV9XG4gICAgICAgICAgICAgICAgcmVmZXJyZXJQb2xpY3k9XCJuby1yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xNiBoLTE2IG9iamVjdC1jb3ZlciByb3VuZGVkIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNocmluay0wXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPntwcm9kdWN0LmNhdGVnb3J5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIHRydW5jYXRlXCI+e3Byb2R1Y3QubmFtZX08L2g0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgUEtSIHtwcm9kdWN0LnByaWNlLnRvTG9jYWxlU3RyaW5nKCl9IGVhY2hcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFF1YW50aXR5IFN0ZXBwZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBiZy13aGl0ZVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UXVhbnRpdHkocSA9PiBNYXRoLm1heCgxLCBxIC0gMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3F1YW50aXR5IDw9IDF9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTYwMCBob3ZlcjpiZy1zbGF0ZS0xMDAgZGlzYWJsZWQ6b3BhY2l0eS0zMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPE1pbnVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgdGV4dC14cyBmb250LWJvbGQgZm9udC1tb25vIHRleHQtc2xhdGUtODAwXCI+e3F1YW50aXR5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFF1YW50aXR5KHEgPT4gTWF0aC5taW4ocHJvZHVjdC5zdG9ja0NvdW50IHx8IDEwLCBxICsgMSkpfVxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3F1YW50aXR5ID49IHByb2R1Y3Quc3RvY2tDb3VudH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkaXNhYmxlZDpvcGFjaXR5LTMwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtlcnJvck1zZyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHRleHQteHMgdGV4dC1yb3NlLTcwMCBiZy1yb3NlLTUwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgIHtlcnJvck1zZ31cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogQnV5ZXIgQ29udGFjdCAmIERlbGl2ZXJ5IEluZm8gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICB7LyogRnVsbCBOYW1lICovfVxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgRnVsbCBOYW1lIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFRhcmlxIE1laG1vb2RcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmdWxsTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGdWxsTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBQaG9uZSBOdW1iZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBQaG9uZSAvIFdoYXRzQXBwIE51bWJlciA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxQaG9uZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41IHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiAwMzAwIDEyMzQ1NjdcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRQaG9uZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9ycyBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDaXR5IFNlbGVjdGlvbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0xXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgQ2l0eSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtjaXR5fVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRDaXR5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9jdXM6Ym9yZGVyLXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmUgYmctd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiS2FyYWNoaVwiPkthcmFjaGk8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkxhaG9yZVwiPkxhaG9yZTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSXNsYW1hYmFkXCI+SXNsYW1hYmFkPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJSYXdhbHBpbmRpXCI+UmF3YWxwaW5kaTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRmFpc2FsYWJhZFwiPkZhaXNhbGFiYWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIk11bHRhblwiPk11bHRhbjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUGVzaGF3YXJcIj5QZXNoYXdhcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiUXVldHRhXCI+UXVldHRhPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTaWFsa290XCI+U2lhbGtvdDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiT3RoZXJcIj5PdGhlciBDaXR5PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDb21wbGV0ZSBEZWxpdmVyeSBBZGRyZXNzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgIENvbXBsZXRlIERlbGl2ZXJ5IEFkZHJlc3MgLyBMb2NhdGlvbiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTQwMCBhYnNvbHV0ZSBsZWZ0LTMgdG9wLTIuNSBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJIb3VzZS9GbGF0ICMsIFN0cmVldCAjLCBTZWN0b3IgLyBDb2xvbnlcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkZWxpdmVyeUFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RGVsaXZlcnlBZGRyZXNzKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOSBwci0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRGVsaXZlcnkgTm90ZSAoT3B0aW9uYWwpICovfVxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgRGVsaXZlcnkgSW5zdHJ1Y3Rpb24gLyBOZWFyZXN0IExhbmRtYXJrIChPcHRpb25hbClcbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgICAgIDxGaWxlVGV4dCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41IHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIE5lYXIgUFNPIFB1bXAsIENhbGwgYmVmb3JlIGFycml2aW5nXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2RlbGl2ZXJ5Tm90ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0RGVsaXZlcnlOb3RlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTkgcHItMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUGF5bWVudCBNZXRob2QgU2VsZWN0b3IgKi99XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIFBheW1lbnQgTWV0aG9kXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBheW1lbnRNZXRob2QoJ2NvZCcpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIuNSByb3VuZGVkIGJvcmRlciB0ZXh0LWxlZnQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgICAgcGF5bWVudE1ldGhvZCA9PT0gJ2NvZCdcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1zbGF0ZS05MDAgYmctc2xhdGUtOTAwLzUgdGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS02MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCBibG9ja1wiPkNhc2ggb24gRGVsaXZlcnkgKENPRCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5QYXkgY2FzaCB1cG9uIGRlbGl2ZXJ5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPFRydWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS03MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBheW1lbnRNZXRob2QoJ2JhbmtfdHJhbnNmZXInKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZCBib3JkZXIgdGV4dC1sZWZ0IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRNZXRob2QgPT09ICdiYW5rX3RyYW5zZmVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXNsYXRlLTkwMCBiZy1zbGF0ZS05MDAvNSB0ZXh0LXNsYXRlLTkwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCB0ZXh0LXNsYXRlLTYwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIGJsb2NrXCI+QmFuayAvIEVhc3lQYWlzYSAvIEphenpDYXNoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+TWFudWFsIHZlcmlmaWNhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNzAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUHJpY2UgQnJlYWtkb3duICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgc3BhY2UteS0xLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+U3VidG90YWwgKHtxdWFudGl0eX0ge3F1YW50aXR5ID09PSAxID8gJ2l0ZW0nIDogJ2l0ZW1zJ30pOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+UEtSIHtzdWJ0b3RhbC50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5OYXRpb253aWRlIFNoaXBwaW5nOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1lbWVyYWxkLTYwMCBmb250LXNlbWlib2xkXCI+RlJFRTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgcHQtMSBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+VG90YWwgQW1vdW50Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+UEtSIHtncmFuZFRvdGFsLnRvTG9jYWxlU3RyaW5nKCl9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU3VibWl0IEJ1dHRvbiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBweC00IGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGlzYWJsZWQ6Ymctc2xhdGUtNDAwIHRleHQtd2hpdGUgZm9udC1zZW1pYm9sZCB0ZXh0LXhzIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpc1N1Ym1pdHRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Qcm9jZXNzaW5nIE9yZGVyLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QbGFjZSBPcmRlciDCtyBQS1Ige2dyYW5kVG90YWwudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTQgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBObyBhZHZhbmNlIHBheW1lbnQgbmVlZGVkXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICA8VHJ1Y2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiAyLTQgZGF5cyBleHByZXNzIGRlbGl2ZXJ5XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgKX1cblxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19