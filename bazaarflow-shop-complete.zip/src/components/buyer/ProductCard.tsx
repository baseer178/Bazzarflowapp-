const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { ShoppingBag, ArrowRight, Package } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/buyer/ProductCard.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const ProductCard = ({ product }) => {
	const { addToCart, setQuickOrderProduct } = useStore();
	const [imageError, setImageError] = useState(false);
	const [isAdded, setIsAdded] = useState(false);
	const handleAddToCart = (e) => {
		e.stopPropagation();
		if (product.stockStatus === "out_of_stock") return;
		addToCart(product, 1);
		setIsAdded(true);
		setTimeout(() => setIsAdded(false), 1200);
	};
	const handleBuyNow = () => {
		if (product.stockStatus === "out_of_stock") return;
		setQuickOrderProduct(product);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "group bg-white rounded-lg border border-slate-200 overflow-hidden flex flex-col justify-between hover:border-slate-300 transition-all duration-200 hover:-translate-y-0.5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			onClick: handleBuyNow,
			className: "relative aspect-4/3 w-full bg-slate-100 overflow-hidden cursor-pointer",
			children: [!imageError ? /* @__PURE__ */ _jsxDEV("img", {
				src: product.imageUrl,
				alt: product.name,
				referrerPolicy: "no-referrer",
				onError: () => setImageError(true),
				className: "w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "w-full h-full flex flex-col items-center justify-center p-6 text-slate-400 bg-slate-50",
				children: [/* @__PURE__ */ _jsxDEV(Package, { className: "w-12 h-12 mb-2 text-slate-300" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-slate-500 font-medium text-center",
					children: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "absolute top-3 left-3",
				children: product.stockStatus === "out_of_stock" ? /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-medium bg-rose-50 text-rose-700 px-2 py-0.5 rounded border border-rose-200",
					children: "Sold Out"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 13
				}, this) : product.stockStatus === "low_stock" ? /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-medium bg-amber-50 text-amber-700 px-2 py-0.5 rounded border border-amber-200",
					children: [
						"Only ",
						product.stockCount,
						" left"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-medium bg-slate-900/80 text-white px-2 py-0.5 rounded backdrop-blur-xs",
					children: "In Stock"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-4 flex-1 flex flex-col justify-between",
			children: [/* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 text-xs text-slate-500 mb-1.5",
					children: [
						/* @__PURE__ */ _jsxDEV("span", { children: product.category }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							"aria-hidden": "true",
							children: "·"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono text-[11px] text-slate-400",
							children: product.sku
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("h3", {
					onClick: handleBuyNow,
					className: "text-base font-semibold text-slate-900 group-hover:text-slate-700 transition-colors cursor-pointer line-clamp-1",
					children: product.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "mt-1 text-xs text-slate-500 line-clamp-2 leading-relaxed",
					children: product.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] text-slate-400 block uppercase tracking-wider",
					children: "Price"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-lg font-bold font-mono tabular-nums text-slate-900",
					children: ["PKR ", product.price.toLocaleString()]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleAddToCart,
						disabled: product.stockStatus === "out_of_stock",
						title: "Add to Bag",
						className: `p-2 rounded border transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${isAdded ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50"}`,
						"aria-label": "Add to cart",
						children: /* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 111,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleBuyNow,
						disabled: product.stockStatus === "out_of_stock",
						className: "px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:bg-slate-300 disabled:cursor-not-allowed rounded transition-colors inline-flex items-center gap-1.5 cursor-pointer whitespace-nowrap",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Order Now" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 69,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLGFBQWEsWUFBWSxlQUFlOzs7QUFNakQsT0FBTyxNQUFNLGVBQTJDLEVBQUUsY0FBYztDQUN0RSxNQUFNLEVBQUUsV0FBVyx5QkFBeUIsU0FBUztDQUNyRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxLQUFLO0NBQ2xELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBRTVDLE1BQU0sbUJBQW1CLE1BQXdCO0VBQy9DLEVBQUUsZ0JBQWdCO0VBQ2xCLElBQUksUUFBUSxnQkFBZ0IsZ0JBQWdCO0VBQzVDLFVBQVUsU0FBUyxDQUFDO0VBQ3BCLFdBQVcsSUFBSTtFQUNmLGlCQUFpQixXQUFXLEtBQUssR0FBRyxJQUFJO0NBQzFDO0NBRUEsTUFBTSxxQkFBcUI7RUFDekIsSUFBSSxRQUFRLGdCQUFnQixnQkFBZ0I7RUFDNUMscUJBQXFCLE9BQU87Q0FDOUI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FFRSx3QkFBQyxPQUFEO0dBQ0UsU0FBUztHQUNULFdBQVU7YUFGWixDQUlHLENBQUMsYUFDQSx3QkFBQyxPQUFEO0lBQ0UsS0FBSyxRQUFRO0lBQ2IsS0FBSyxRQUFRO0lBQ2IsZ0JBQWU7SUFDZixlQUFlLGNBQWMsSUFBSTtJQUNqQyxXQUFVO0dBQ1g7Ozs7Y0FFRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsZ0NBQWlDOzs7O2NBQ3BELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWtELFFBQVE7SUFBVzs7OztZQUNsRjs7Ozs7YUFJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFFBQVEsZ0JBQWdCLGlCQUN2Qix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUE4RjtJQUV4Rzs7OztlQUNKLFFBQVEsZ0JBQWdCLGNBQzFCLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BQWlIO01BQ3pHLFFBQVE7TUFBVztLQUNyQjs7Ozs7ZUFFTix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUEwRjtJQUVwRzs7Ozs7R0FFTDs7OztXQUNGOzs7OztZQUdMLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxPQUFEO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFFBQUQsWUFBTyxRQUFRLFNBQWU7Ozs7O01BQzlCLHdCQUFDLFFBQUQ7T0FBTSxlQUFZO2lCQUFPO01BQU87Ozs7O01BQ2hDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3QyxRQUFRO01BQVU7Ozs7O0tBQ3ZFOzs7Ozs7SUFFTCx3QkFBQyxNQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7ZUFFVCxRQUFRO0lBQ1A7Ozs7O0lBRUosd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFDVixRQUFRO0lBQ1I7Ozs7O0dBQ0E7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQTREO0lBQVc7Ozs7Y0FDdkYsd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBaEIsQ0FBMEUsUUFDbkUsUUFBUSxNQUFNLGVBQWUsQ0FDOUI7Ozs7O1lBQ0g7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVLFFBQVEsZ0JBQWdCO01BQ2xDLE9BQU07TUFDTixXQUFXLHVHQUNULFVBQ0ksc0RBQ0E7TUFFTixjQUFXO2dCQUVYLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O0tBQzVCOzs7O2VBRVIsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVLFFBQVEsZ0JBQWdCO01BQ2xDLFdBQVU7Z0JBSFosQ0FLRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztnQkFDckIsd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7OztjQUMvQjs7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7V0FDRjs7Ozs7VUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZHVjdENhcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFByb2R1Y3QgfSBmcm9tICcuLi8uLi90eXBlcy9zdG9yZSc7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gJy4uLy4uL2NvbnRleHQvU3RvcmVDb250ZXh0JztcbmltcG9ydCB7IFNob3BwaW5nQmFnLCBBcnJvd1JpZ2h0LCBQYWNrYWdlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIFByb2R1Y3RDYXJkUHJvcHMge1xuICBwcm9kdWN0OiBQcm9kdWN0O1xufVxuXG5leHBvcnQgY29uc3QgUHJvZHVjdENhcmQ6IFJlYWN0LkZDPFByb2R1Y3RDYXJkUHJvcHM+ID0gKHsgcHJvZHVjdCB9KSA9PiB7XG4gIGNvbnN0IHsgYWRkVG9DYXJ0LCBzZXRRdWlja09yZGVyUHJvZHVjdCB9ID0gdXNlU3RvcmUoKTtcbiAgY29uc3QgW2ltYWdlRXJyb3IsIHNldEltYWdlRXJyb3JdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbaXNBZGRlZCwgc2V0SXNBZGRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgY29uc3QgaGFuZGxlQWRkVG9DYXJ0ID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQpID0+IHtcbiAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIGlmIChwcm9kdWN0LnN0b2NrU3RhdHVzID09PSAnb3V0X29mX3N0b2NrJykgcmV0dXJuO1xuICAgIGFkZFRvQ2FydChwcm9kdWN0LCAxKTtcbiAgICBzZXRJc0FkZGVkKHRydWUpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0SXNBZGRlZChmYWxzZSksIDEyMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUJ1eU5vdyA9ICgpID0+IHtcbiAgICBpZiAocHJvZHVjdC5zdG9ja1N0YXR1cyA9PT0gJ291dF9vZl9zdG9jaycpIHJldHVybjtcbiAgICBzZXRRdWlja09yZGVyUHJvZHVjdChwcm9kdWN0KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JvdXAgYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNVwiPlxuICAgICAgey8qIFByb2R1Y3QgSW1hZ2UgQXJlYSAqL31cbiAgICAgIDxkaXYgXG4gICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJ1eU5vd31cbiAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LTQvMyB3LWZ1bGwgYmctc2xhdGUtMTAwIG92ZXJmbG93LWhpZGRlbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICA+XG4gICAgICAgIHshaW1hZ2VFcnJvciA/IChcbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBzcmM9e3Byb2R1Y3QuaW1hZ2VVcmx9XG4gICAgICAgICAgICBhbHQ9e3Byb2R1Y3QubmFtZX1cbiAgICAgICAgICAgIHJlZmVycmVyUG9saWN5PVwibm8tcmVmZXJyZXJcIlxuICAgICAgICAgICAgb25FcnJvcj17KCkgPT4gc2V0SW1hZ2VFcnJvcih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIGdyb3VwLWhvdmVyOnNjYWxlLTEwMiB0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNiB0ZXh0LXNsYXRlLTQwMCBiZy1zbGF0ZS01MFwiPlxuICAgICAgICAgICAgPFBhY2thZ2UgY2xhc3NOYW1lPVwidy0xMiBoLTEyIG1iLTIgdGV4dC1zbGF0ZS0zMDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1lZGl1bSB0ZXh0LWNlbnRlclwiPntwcm9kdWN0Lm5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBRdWlldCBTdG9jayBUYWcgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgbGVmdC0zXCI+XG4gICAgICAgICAge3Byb2R1Y3Quc3RvY2tTdGF0dXMgPT09ICdvdXRfb2Zfc3RvY2snID8gKFxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tZWRpdW0gYmctcm9zZS01MCB0ZXh0LXJvc2UtNzAwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1yb3NlLTIwMFwiPlxuICAgICAgICAgICAgICBTb2xkIE91dFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICkgOiBwcm9kdWN0LnN0b2NrU3RhdHVzID09PSAnbG93X3N0b2NrJyA/IChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbWVkaXVtIGJnLWFtYmVyLTUwIHRleHQtYW1iZXItNzAwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1hbWJlci0yMDBcIj5cbiAgICAgICAgICAgICAgT25seSB7cHJvZHVjdC5zdG9ja0NvdW50fSBsZWZ0XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbWVkaXVtIGJnLXNsYXRlLTkwMC84MCB0ZXh0LXdoaXRlIHB4LTIgcHktMC41IHJvdW5kZWQgYmFja2Ryb3AtYmx1ci14c1wiPlxuICAgICAgICAgICAgICBJbiBTdG9ja1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9kdWN0IERldGFpbHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBmbGV4LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB7LyogTWV0YWRhdGE6IENhdGVnb3J5ICYgU0tVICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtYi0xLjVcIj5cbiAgICAgICAgICAgIDxzcGFuPntwcm9kdWN0LmNhdGVnb3J5fTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPsK3PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+e3Byb2R1Y3Quc2t1fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxoMyBcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJ1eU5vd31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGdyb3VwLWhvdmVyOnRleHQtc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyIGxpbmUtY2xhbXAtMVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAge3Byb2R1Y3QubmFtZX1cbiAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGxpbmUtY2xhbXAtMiBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgIHtwcm9kdWN0LmRlc2NyaXB0aW9ufVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByaWNpbmcgJiBBY3Rpb25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5QcmljZTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgUEtSIHtwcm9kdWN0LnByaWNlLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQWRkVG9DYXJ0fVxuICAgICAgICAgICAgICBkaXNhYmxlZD17cHJvZHVjdC5zdG9ja1N0YXR1cyA9PT0gJ291dF9vZl9zdG9jayd9XG4gICAgICAgICAgICAgIHRpdGxlPVwiQWRkIHRvIEJhZ1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkIGJvcmRlciB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciBkaXNhYmxlZDpvcGFjaXR5LTQwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCAke1xuICAgICAgICAgICAgICAgIGlzQWRkZWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAgdGV4dC1lbWVyYWxkLTcwMCBib3JkZXItZW1lcmFsZC0yMDAnXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LXNsYXRlLTcwMCBib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTUwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFkZCB0byBjYXJ0XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQnV5Tm93fVxuICAgICAgICAgICAgICBkaXNhYmxlZD17cHJvZHVjdC5zdG9ja1N0YXR1cyA9PT0gJ291dF9vZl9zdG9jayd9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMuNSBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXdoaXRlIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgZGlzYWJsZWQ6Ymctc2xhdGUtMzAwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyIHdoaXRlc3BhY2Utbm93cmFwXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+T3JkZXIgTm93PC9zcGFuPlxuICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=