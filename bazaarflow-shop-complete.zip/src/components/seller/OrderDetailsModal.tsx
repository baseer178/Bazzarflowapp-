const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { X, MapPin, Phone, MessageCircle, Copy, Check, CreditCard, Package } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/seller/OrderDetailsModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const OrderDetailsModal = ({ order, isOpen, onClose, onUpdateStatus }) => {
	const [copied, setCopied] = React.useState(false);
	if (!isOpen || !order) return null;
	const handleCopyAddress = () => {
		const fullAddress = `${order.customer.fullName}\nPhone: ${order.customer.phone}\nAddress: ${order.customer.deliveryAddress}, ${order.customer.city}`;
		navigator.clipboard.writeText(fullAddress);
		setCopied(true);
		setTimeout(() => setCopied(false), 2e3);
	};
	// WhatsApp formatted link
	const cleanPhone = order.customer.phone.replace(/[^0-9]/g, "");
	const waNumber = cleanPhone.startsWith("0") ? `92${cleanPhone.slice(1)}` : cleanPhone;
	const waMessage = encodeURIComponent(`Hello ${order.customer.fullName}! We received your order ${order.orderNumber} for PKR ${order.totalAmount.toLocaleString()} at BazaarFlow. We are preparing it for delivery to ${order.customer.deliveryAddress}, ${order.customer.city}.`);
	const whatsappUrl = `https://wa.me/${waNumber}?text=${waMessage}`;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-base font-bold text-slate-900 font-display",
								children: ["Order ", order.orderNumber]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400",
								children: "·"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 48,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-500 font-mono",
								children: new Date(order.createdAt).toLocaleString([], {
									dateStyle: "medium",
									timeStyle: "short"
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-500 mt-0.5",
						children: "Customer & Delivery Dispatch Details"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 bg-slate-50 rounded-lg border border-slate-200",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-semibold text-slate-400 uppercase tracking-wider block",
								children: "Fulfillment Status"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-600",
								children: "Update status as courier processes this delivery"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: /* @__PURE__ */ _jsxDEV("select", {
									value: order.status,
									onChange: (e) => onUpdateStatus(order.id, e.target.value),
									className: "px-3 py-1.5 text-xs font-semibold rounded border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-slate-900",
									children: [
										/* @__PURE__ */ _jsxDEV("option", {
											value: "pending",
											children: "Pending"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 86,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "confirmed",
											children: "Confirmed"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 87,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "shipped",
											children: "Shipped (With Courier)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 88,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "delivered",
											children: "Delivered"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 89,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("option", {
											value: "cancelled",
											children: "Cancelled"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 90,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 rounded-lg p-4 space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between border-b border-slate-100 pb-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 text-slate-700" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("h4", {
										className: "text-xs font-bold text-slate-900 uppercase tracking-wider",
										children: "Delivery Destination"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleCopyAddress,
									className: "inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer",
									children: [copied ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 109,
										columnNumber: 27
									}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 109,
										columnNumber: 80
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: copied ? "Copied to Clipboard" : "Copy Dispatch Label" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 110,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block mb-0.5",
										children: "Recipient Full Name:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 116,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-slate-900 text-sm",
										children: order.customer.fullName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 117,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 115,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block mb-0.5",
										children: "Phone Contact:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 121,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono font-semibold text-slate-900",
												children: order.customer.phone
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 123,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("a", {
												href: `tel:${order.customer.phone}`,
												className: "p-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700",
												title: "Call customer",
												children: /* @__PURE__ */ _jsxDEV(Phone, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 129,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 124,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("a", {
												href: whatsappUrl,
												target: "_blank",
												rel: "noopener noreferrer",
												className: "p-1 rounded bg-emerald-100 hover:bg-emerald-200 text-emerald-800",
												title: "Message on WhatsApp",
												children: /* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 138,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 131,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 122,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 120,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "sm:col-span-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 block mb-0.5",
											children: "Full Street / House Address:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 144,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "p-2.5 bg-slate-50 border border-slate-200 rounded font-medium text-slate-800",
											children: [
												order.customer.deliveryAddress,
												", ",
												order.customer.city
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 145,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 143,
										columnNumber: 15
									}, this),
									order.customer.deliveryNote && /* @__PURE__ */ _jsxDEV("div", {
										className: "sm:col-span-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-400 block mb-0.5",
											children: "Customer Delivery Notes:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 152,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "italic text-slate-600 bg-amber-50/60 p-2 rounded border border-amber-100",
											children: [
												"\"",
												order.customer.deliveryNote,
												"\""
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Package, { className: "w-4 h-4 text-slate-700" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Package Items" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "border border-slate-200 rounded-lg overflow-hidden",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "divide-y divide-slate-100",
								children: order.items.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV("img", {
											src: item.imageUrl,
											alt: item.productName,
											className: "w-10 h-10 object-cover rounded border border-slate-200 shrink-0"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 173,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-semibold text-slate-900",
											children: item.productName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 179,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-slate-400 text-[11px]",
											children: [
												"Qty: ",
												item.quantity,
												" · PKR ",
												item.price.toLocaleString(),
												" each"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 25
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 178,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "font-mono font-bold tabular-nums text-slate-900 text-sm",
										children: ["PKR ", (item.price * item.quantity).toLocaleString()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 184,
										columnNumber: 21
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 169,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 text-slate-600",
									children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-4 h-4 text-slate-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										"Payment Method: ",
										/* @__PURE__ */ _jsxDEV("strong", {
											className: "uppercase",
											children: order.paymentMethod
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 195,
											columnNumber: 41
										}, this),
										" (Collect upon delivery)"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 193,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-right",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-500 mr-2",
										children: "Grand Total:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 198,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-base font-bold font-mono text-slate-900",
										children: ["PKR ", order.totalAmount.toLocaleString()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 197,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 192,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 168,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: whatsappUrl,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-600 hover:bg-emerald-700 text-white rounded transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 217,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "WhatsApp Confirmation" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 211,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded transition-colors cursor-pointer",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 221,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 210,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsR0FBRyxRQUFRLE9BQU8sZUFBZSxNQUFNLE9BQWlCLFlBQVksZUFBZTs7O0FBUzVGLE9BQU8sTUFBTSxxQkFBdUQsRUFDbEUsT0FDQSxRQUNBLFNBQ0EscUJBQ0k7Q0FDSixNQUFNLENBQUMsUUFBUSxhQUFhLE1BQU0sU0FBUyxLQUFLO0NBRWhELElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxPQUFPO0NBRTlCLE1BQU0sMEJBQTBCO0VBQzlCLE1BQU0sY0FBYyxHQUFHLE1BQU0sU0FBUyxTQUFTLFdBQVcsTUFBTSxTQUFTLE1BQU0sYUFBYSxNQUFNLFNBQVMsZ0JBQWdCLElBQUksTUFBTSxTQUFTO0VBQzlJLFVBQVUsVUFBVSxVQUFVLFdBQVc7RUFDekMsVUFBVSxJQUFJO0VBQ2QsaUJBQWlCLFVBQVUsS0FBSyxHQUFHLEdBQUk7Q0FDekM7O0NBR0EsTUFBTSxhQUFhLE1BQU0sU0FBUyxNQUFNLFFBQVEsV0FBVyxFQUFFO0NBQzdELE1BQU0sV0FBVyxXQUFXLFdBQVcsR0FBRyxJQUFJLEtBQUssV0FBVyxNQUFNLENBQUMsTUFBTTtDQUMzRSxNQUFNLFlBQVksbUJBQ2hCLFNBQVMsTUFBTSxTQUFTLFNBQVMsMkJBQTJCLE1BQU0sWUFBWSxXQUFXLE1BQU0sWUFBWSxlQUFlLEVBQUUsc0RBQXNELE1BQU0sU0FBUyxnQkFBZ0IsSUFBSSxNQUFNLFNBQVMsS0FBSyxFQUMzTztDQUNBLE1BQU0sY0FBYyxpQkFBaUIsU0FBUyxRQUFRO0NBRXRELE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUFrRSxVQUN6RCxNQUFNLFdBQ1Q7Ozs7OztPQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5QjtPQUFPOzs7OztPQUNoRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixJQUFJLEtBQUssTUFBTSxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRztTQUFFLFdBQVc7U0FBVSxXQUFXO1FBQVEsQ0FBQztPQUNyRjs7Ozs7TUFDSDs7Ozs7ZUFDTCx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZ0M7S0FFMUM7Ozs7YUFDQTs7OztlQUVMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztLQUNsQjs7OzthQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBFO09BRXBGOzs7O2lCQUNOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUF5QjtPQUVuQzs7OztlQUNIOzs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxPQUFPLE1BQU07U0FDYixXQUFVLE1BQUssZUFBZSxNQUFNLElBQUksRUFBRSxPQUFPLEtBQW9CO1NBQ3JFLFdBQVU7bUJBSFo7VUFLRSx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBVTtVQUFlOzs7OztVQUN2Qyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBWTtVQUFpQjs7Ozs7VUFDM0Msd0JBQUMsVUFBRDtXQUFRLE9BQU07cUJBQVU7VUFBOEI7Ozs7O1VBQ3RELHdCQUFDLFVBQUQ7V0FBUSxPQUFNO3FCQUFZO1VBQWlCOzs7OztVQUMzQyx3QkFBQyxVQUFEO1dBQVEsT0FBTTtxQkFBWTtVQUFpQjs7Ozs7U0FDckM7Ozs7OztPQUNMOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlCQUEwQjs7OzttQkFDNUMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTREO1NBRXRFOzs7O2lCQUNEOzs7OztrQkFFTCx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBRlosQ0FJRyxTQUFTLHdCQUFDLE9BQUQsRUFBTyxXQUFVLCtCQUFnQzs7OztvQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O21CQUM5Rix3QkFBQyxRQUFELFlBQU8sU0FBUyx3QkFBd0Isc0JBQTRCOzs7O2lCQUM5RDs7Ozs7Z0JBQ0w7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE4QjtTQUEwQjs7OzttQkFDeEUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXdDLE1BQU0sU0FBUztTQUFlOzs7O2lCQUNuRjs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQThCO1NBQW9COzs7O21CQUNsRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUEwQyxNQUFNLFNBQVM7V0FBWTs7Ozs7V0FDckYsd0JBQUMsS0FBRDtZQUNFLE1BQU0sT0FBTyxNQUFNLFNBQVM7WUFDNUIsV0FBVTtZQUNWLE9BQU07c0JBRU4sd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7Ozs7V0FDL0I7Ozs7O1dBQ0gsd0JBQUMsS0FBRDtZQUNFLE1BQU07WUFDTixRQUFPO1lBQ1AsS0FBSTtZQUNKLFdBQVU7WUFDVixPQUFNO3NCQUVOLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGNBQWU7Ozs7O1dBQ3ZDOzs7OztVQUNBOzs7OztpQkFDRjs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE4QjtVQUFrQzs7OztvQkFDaEYsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRyxNQUFNLFNBQVM7WUFBZ0I7WUFBRyxNQUFNLFNBQVM7V0FDL0M7Ozs7O2tCQUNGOzs7Ozs7U0FFSixNQUFNLFNBQVMsZ0JBQ2Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBOEI7VUFBOEI7Ozs7b0JBQzVFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQTBGO1lBQ3RGLE1BQU0sU0FBUztZQUFhO1dBQzNCOzs7OztrQkFDRjs7Ozs7O1FBRUo7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLHlCQUEwQjs7OztpQkFDN0Msd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OztlQUN2Qjs7Ozs7Z0JBRUosd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixNQUFNLE1BQU0sS0FBSyxNQUFNLFFBQ3RCLHdCQUFDLE9BQUQ7U0FBZSxXQUFVO21CQUF6QixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUNFLEtBQUssS0FBSztXQUNWLEtBQUssS0FBSztXQUNWLFdBQVU7VUFDWDs7OztvQkFDRCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWdDLEtBQUs7VUFBaUI7Ozs7b0JBQ3JFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmO1lBQTRDO1lBQU0sS0FBSztZQUFTO1lBQVEsS0FBSyxNQUFNLGVBQWU7WUFBRTtXQUFVOzs7OztrQkFDM0c7Ozs7a0JBQ0Y7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQXlFLFNBQ2pFLEtBQUssUUFBUSxLQUFLLFNBQVEsQ0FBRSxlQUFlLENBQzlDOzs7OztpQkFDRjtXQWhCSzs7OztlQWdCTCxDQUNOO09BQ0U7Ozs7aUJBR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlCQUEwQjs7OzttQkFDaEQsd0JBQUMsUUFBRDtVQUFNO1VBQWdCLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFhLE1BQU07VUFBc0I7Ozs7O1VBQUM7U0FBOEI7Ozs7aUJBQzdHOzs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFzQjtTQUFrQjs7OzttQkFDeEQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQStELFFBQ3hELE1BQU0sWUFBWSxlQUFlLENBQ2xDOzs7OztpQkFDSDs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7O0tBRUY7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxLQUFEO01BQ0UsTUFBTTtNQUNOLFFBQU87TUFDUCxLQUFJO01BQ0osV0FBVTtnQkFKWixDQU1FLHdCQUFDLGVBQUQsRUFBZSxXQUFVLGNBQWU7Ozs7Z0JBQ3hDLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7Y0FDaEM7Ozs7O2VBRUgsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0dBRUY7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk9yZGVyRGV0YWlsc01vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgT3JkZXIsIE9yZGVyU3RhdHVzIH0gZnJvbSAnLi4vLi4vdHlwZXMvc3RvcmUnO1xuaW1wb3J0IHsgWCwgTWFwUGluLCBQaG9uZSwgTWVzc2FnZUNpcmNsZSwgQ29weSwgQ2hlY2ssIENhbGVuZGFyLCBDcmVkaXRDYXJkLCBQYWNrYWdlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIE9yZGVyRGV0YWlsc01vZGFsUHJvcHMge1xuICBvcmRlcjogT3JkZXIgfCBudWxsO1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uVXBkYXRlU3RhdHVzOiAob3JkZXJJZDogc3RyaW5nLCBzdGF0dXM6IE9yZGVyU3RhdHVzKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgT3JkZXJEZXRhaWxzTW9kYWw6IFJlYWN0LkZDPE9yZGVyRGV0YWlsc01vZGFsUHJvcHM+ID0gKHtcbiAgb3JkZXIsXG4gIGlzT3BlbixcbiAgb25DbG9zZSxcbiAgb25VcGRhdGVTdGF0dXNcbn0pID0+IHtcbiAgY29uc3QgW2NvcGllZCwgc2V0Q29waWVkXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcblxuICBpZiAoIWlzT3BlbiB8fCAhb3JkZXIpIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGhhbmRsZUNvcHlBZGRyZXNzID0gKCkgPT4ge1xuICAgIGNvbnN0IGZ1bGxBZGRyZXNzID0gYCR7b3JkZXIuY3VzdG9tZXIuZnVsbE5hbWV9XFxuUGhvbmU6ICR7b3JkZXIuY3VzdG9tZXIucGhvbmV9XFxuQWRkcmVzczogJHtvcmRlci5jdXN0b21lci5kZWxpdmVyeUFkZHJlc3N9LCAke29yZGVyLmN1c3RvbWVyLmNpdHl9YDtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChmdWxsQWRkcmVzcyk7XG4gICAgc2V0Q29waWVkKHRydWUpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkKGZhbHNlKSwgMjAwMCk7XG4gIH07XG5cbiAgLy8gV2hhdHNBcHAgZm9ybWF0dGVkIGxpbmtcbiAgY29uc3QgY2xlYW5QaG9uZSA9IG9yZGVyLmN1c3RvbWVyLnBob25lLnJlcGxhY2UoL1teMC05XS9nLCAnJyk7XG4gIGNvbnN0IHdhTnVtYmVyID0gY2xlYW5QaG9uZS5zdGFydHNXaXRoKCcwJykgPyBgOTIke2NsZWFuUGhvbmUuc2xpY2UoMSl9YCA6IGNsZWFuUGhvbmU7XG4gIGNvbnN0IHdhTWVzc2FnZSA9IGVuY29kZVVSSUNvbXBvbmVudChcbiAgICBgSGVsbG8gJHtvcmRlci5jdXN0b21lci5mdWxsTmFtZX0hIFdlIHJlY2VpdmVkIHlvdXIgb3JkZXIgJHtvcmRlci5vcmRlck51bWJlcn0gZm9yIFBLUiAke29yZGVyLnRvdGFsQW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9IGF0IEJhemFhckZsb3cuIFdlIGFyZSBwcmVwYXJpbmcgaXQgZm9yIGRlbGl2ZXJ5IHRvICR7b3JkZXIuY3VzdG9tZXIuZGVsaXZlcnlBZGRyZXNzfSwgJHtvcmRlci5jdXN0b21lci5jaXR5fS5gXG4gICk7XG4gIGNvbnN0IHdoYXRzYXBwVXJsID0gYGh0dHBzOi8vd2EubWUvJHt3YU51bWJlcn0/dGV4dD0ke3dhTWVzc2FnZX1gO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLXNsYXRlLTk1MC82MCBiYWNrZHJvcC1ibHVyLXhzIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctMnhsIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBvdmVyZmxvdy1oaWRkZW4gbXktOCBhbmltYXRlLWluIGZhZGUtaW4gZHVyYXRpb24tMjAwXCI+XG4gICAgICAgIFxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktNCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zbGF0ZS01MFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZm9udC1kaXNwbGF5XCI+XG4gICAgICAgICAgICAgICAgT3JkZXIge29yZGVyLm9yZGVyTnVtYmVyfVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICB7bmV3IERhdGUob3JkZXIuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZyhbXSwgeyBkYXRlU3R5bGU6ICdtZWRpdW0nLCB0aW1lU3R5bGU6ICdzaG9ydCcgfSl9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgQ3VzdG9tZXIgJiBEZWxpdmVyeSBEaXNwYXRjaCBEZXRhaWxzXG4gICAgICAgICAgICA8L3A+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTYgc3BhY2UteS02XCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIFN0YXR1cyBCYXIgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcC0zLjUgYmctc2xhdGUtNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICBGdWxmaWxsbWVudCBTdGF0dXNcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgVXBkYXRlIHN0YXR1cyBhcyBjb3VyaWVyIHByb2Nlc3NlcyB0aGlzIGRlbGl2ZXJ5XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17b3JkZXIuc3RhdHVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IG9uVXBkYXRlU3RhdHVzKG9yZGVyLmlkLCBlLnRhcmdldC52YWx1ZSBhcyBPcmRlclN0YXR1cyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgYmctd2hpdGUgdGV4dC1zbGF0ZS05MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1zbGF0ZS05MDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInBlbmRpbmdcIj5QZW5kaW5nPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNvbmZpcm1lZFwiPkNvbmZpcm1lZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJzaGlwcGVkXCI+U2hpcHBlZCAoV2l0aCBDb3VyaWVyKTwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJkZWxpdmVyZWRcIj5EZWxpdmVyZWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FuY2VsbGVkXCI+Q2FuY2VsbGVkPC9vcHRpb24+XG4gICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ3VzdG9tZXIgJiBEZWxpdmVyeSBDYXJkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTQgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtMTAwIHBiLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNsYXRlLTcwMFwiIC8+XG4gICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgICAgRGVsaXZlcnkgRGVzdGluYXRpb25cbiAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29weUFkZHJlc3N9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMi41IHB5LTEgdGV4dC1bMTFweF0gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS03MDAgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtjb3BpZWQgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICA8c3Bhbj57Y29waWVkID8gJ0NvcGllZCB0byBDbGlwYm9hcmQnIDogJ0NvcHkgRGlzcGF0Y2ggTGFiZWwnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0wLjVcIj5SZWNpcGllbnQgRnVsbCBOYW1lOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIHRleHQtc21cIj57b3JkZXIuY3VzdG9tZXIuZnVsbE5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTAuNVwiPlBob25lIENvbnRhY3Q6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e29yZGVyLmN1c3RvbWVyLnBob25lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9e2B0ZWw6JHtvcmRlci5jdXN0b21lci5waG9uZX1gfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZCBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIHRleHQtc2xhdGUtNzAwXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDYWxsIGN1c3RvbWVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgIGhyZWY9e3doYXRzYXBwVXJsfVxuICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xIHJvdW5kZWQgYmctZW1lcmFsZC0xMDAgaG92ZXI6YmctZW1lcmFsZC0yMDAgdGV4dC1lbWVyYWxkLTgwMFwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTWVzc2FnZSBvbiBXaGF0c0FwcFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlQ2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMC41XCI+RnVsbCBTdHJlZXQgLyBIb3VzZSBBZGRyZXNzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci5kZWxpdmVyeUFkZHJlc3N9LCB7b3JkZXIuY3VzdG9tZXIuY2l0eX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge29yZGVyLmN1c3RvbWVyLmRlbGl2ZXJ5Tm90ZSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0wLjVcIj5DdXN0b21lciBEZWxpdmVyeSBOb3Rlczo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIml0YWxpYyB0ZXh0LXNsYXRlLTYwMCBiZy1hbWJlci01MC82MCBwLTIgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICBcIntvcmRlci5jdXN0b21lci5kZWxpdmVyeU5vdGV9XCJcbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogT3JkZXJlZCBQcm9kdWN0cyBUYWJsZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxQYWNrYWdlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS03MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5QYWNrYWdlIEl0ZW1zPC9zcGFuPlxuICAgICAgICAgICAgPC9oND5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpdmlkZS15IGRpdmlkZS1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICB7b3JkZXIuaXRlbXMubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInAtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtpdGVtLmltYWdlVXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtpdGVtLnByb2R1Y3ROYW1lfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIG9iamVjdC1jb3ZlciByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNocmluay0wXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57aXRlbS5wcm9kdWN0TmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj5RdHk6IHtpdGVtLnF1YW50aXR5fSDCtyBQS1Ige2l0ZW0ucHJpY2UudG9Mb2NhbGVTdHJpbmcoKX0gZWFjaDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICBQS1IgeyhpdGVtLnByaWNlICogaXRlbS5xdWFudGl0eSkudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRvdGFsIFJvdyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+UGF5bWVudCBNZXRob2Q6IDxzdHJvbmcgY2xhc3NOYW1lPVwidXBwZXJjYXNlXCI+e29yZGVyLnBheW1lbnRNZXRob2R9PC9zdHJvbmc+IChDb2xsZWN0IHVwb24gZGVsaXZlcnkpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgbXItMlwiPkdyYW5kIFRvdGFsOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgZm9udC1tb25vIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFBLUiB7b3JkZXIudG90YWxBbW91bnQudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyIEFjdGlvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS0zLjUgYmctc2xhdGUtNTAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8YVxuICAgICAgICAgICAgaHJlZj17d2hhdHNhcHBVcmx9XG4gICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtbWVkaXVtIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIHRleHQtd2hpdGUgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+V2hhdHNBcHAgQ29uZmlybWF0aW9uPC9zcGFuPlxuICAgICAgICAgIDwvYT5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIENsb3NlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=