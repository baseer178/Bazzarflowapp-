const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { SellerProductModal } from "/src/components/seller/SellerProductModal.tsx";
import { OrderDetailsModal } from "/src/components/seller/OrderDetailsModal.tsx";
import { Package, DollarSign, Clock, CheckCircle, Plus, MapPin, Phone, ExternalLink, Edit3, Trash2, RotateCcw, Sparkles, Search } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/seller/SellerDashboard.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const SellerDashboard = () => {
	const { products, orders, addProduct, updateProduct, deleteProduct, updateOrderStatus, placeOrder, resetToDefaults, setCurrentView } = useStore();
	const [activeTab, setActiveTab] = useState("orders");
	const [orderFilter, setOrderFilter] = useState("all");
	const [productModalOpen, setProductModalOpen] = useState(false);
	const [editingProduct, setEditingProduct] = useState(null);
	const [selectedOrder, setSelectedOrder] = useState(null);
	const [inventorySearch, setInventorySearch] = useState("");
	const [orderSearch, setOrderSearch] = useState("");
	// Stats Calculations
	const totalRevenue = orders.reduce((sum, o) => sum + o.totalAmount, 0);
	const pendingOrders = orders.filter((o) => o.status === "pending");
	const deliveredOrders = orders.filter((o) => o.status === "delivered");
	// Filtered Orders
	const filteredOrders = orders.filter((order) => {
		const matchesFilter = orderFilter === "all" || order.status === orderFilter;
		const matchesSearch = order.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) || order.customer.fullName.toLowerCase().includes(orderSearch.toLowerCase()) || order.customer.city.toLowerCase().includes(orderSearch.toLowerCase()) || order.customer.phone.includes(orderSearch);
		return matchesFilter && matchesSearch;
	});
	// Filtered Inventory
	const filteredProducts = products.filter((p) => p.name.toLowerCase().includes(inventorySearch.toLowerCase()) || p.sku.toLowerCase().includes(inventorySearch.toLowerCase()) || p.category.toLowerCase().includes(inventorySearch.toLowerCase()));
	const handleSaveProduct = (productData) => {
		if (productData.id) {
			updateProduct(productData.id, productData);
		} else {
			addProduct(productData);
		}
	};
	const handleSimulateIncomingOrder = () => {
		const sampleNames = [
			"Zubair Khan",
			"Mariam Shah",
			"Hassan Raza",
			"Fatima Zahra"
		];
		const sampleCities = [
			"Karachi",
			"Lahore",
			"Islamabad",
			"Peshawar"
		];
		const randomProduct = products[Math.floor(Math.random() * products.length)];
		const randomName = sampleNames[Math.floor(Math.random() * sampleNames.length)];
		const randomCity = sampleCities[Math.floor(Math.random() * sampleCities.length)];
		placeOrder({
			fullName: randomName,
			phone: `03${Math.floor(10 + Math.random() * 40)}-${Math.floor(1e6 + Math.random() * 9e6)}`,
			city: randomCity,
			deliveryAddress: `House #${Math.floor(1 + Math.random() * 99)}, Street #${Math.floor(1 + Math.random() * 20)}, Sector G-10`,
			deliveryNote: "Urgent delivery requested please call first"
		}, [{
			productId: randomProduct.id,
			productName: randomProduct.name,
			price: randomProduct.price,
			quantity: 1,
			imageUrl: randomProduct.imageUrl
		}], "cod");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-20",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-white border-b border-slate-200",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col md:flex-row md:items-center justify-between gap-4",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs text-slate-500 mb-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { children: "Vendor Control Center" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										"aria-hidden": "true",
										children: "·"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 113,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Real-Time Store Management" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 114,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 font-display",
								children: "Seller Command Hub"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 mt-1",
								children: "Manage live customer orders, courier dispatch locations, and product catalog inventory."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 flex-wrap",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleSimulateIncomingOrder,
									className: "px-3.5 py-2 text-xs font-semibold text-slate-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded transition-colors inline-flex items-center gap-1.5 cursor-pointer",
									title: "Simulate a real-time buyer order to test the notification",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Simulate Order" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 131,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 125,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setEditingProduct(null);
										setProductModalOpen(true);
									},
									className: "px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors inline-flex items-center gap-1.5 cursor-pointer shadow-xs",
									children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Add Product" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setCurrentView("buyer"),
									className: "px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded transition-colors cursor-pointer",
									children: "View Storefront →"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 border border-slate-200 rounded-lg p-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 text-xs mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total Gross Sales" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(DollarSign, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 157,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900",
										children: ["PKR ", totalRevenue.toLocaleString()]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 mt-1",
										children: [
											"Across ",
											orders.length,
											" orders"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 164,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 border border-slate-200 rounded-lg p-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 text-xs mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Pending Deliveries" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 169,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 170,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xl sm:text-2xl font-bold font-mono tabular-nums text-amber-700",
										children: pendingOrders.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 172,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 mt-1",
										children: "Awaiting dispatch"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 border border-slate-200 rounded-lg p-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 text-xs mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Delivered Successfully" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 181,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 179,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xl sm:text-2xl font-bold font-mono tabular-nums text-emerald-700",
										children: deliveredOrders.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 mt-1",
										children: "Completed orders"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-50 border border-slate-200 rounded-lg p-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 text-xs mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Active Products" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 191,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV(Package, { className: "w-4 h-4 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xl sm:text-2xl font-bold font-mono tabular-nums text-slate-900",
										children: products.length
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 mt-1",
										children: "Live in store"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 189,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 155,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 107,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between border-b border-slate-200 pb-3 mb-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("orders"),
								className: `px-4 py-2 text-xs font-semibold rounded transition-colors cursor-pointer ${activeTab === "orders" ? "bg-slate-900 text-white" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-100"}`,
								children: [
									"Incoming Orders & Deliveries (",
									orders.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 209,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("inventory"),
								className: `px-4 py-2 text-xs font-semibold rounded transition-colors cursor-pointer ${activeTab === "inventory" ? "bg-slate-900 text-white" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-100"}`,
								children: [
									"Inventory Management (",
									products.length,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: resetToDefaults,
							className: "text-[11px] text-slate-400 hover:text-slate-700 inline-flex items-center gap-1 cursor-pointer",
							title: "Reset store to initial default catalog and orders",
							children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3 h-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 237,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset Demo" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 238,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 232,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 207,
						columnNumber: 9
					}, this),
					activeTab === "orders" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-lg border border-slate-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0",
								children: [
									"all",
									"pending",
									"confirmed",
									"shipped",
									"delivered",
									"cancelled"
								].map((st) => /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setOrderFilter(st),
									className: `px-3 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer capitalize ${orderFilter === st ? "bg-slate-800 text-white" : "text-slate-600 hover:bg-slate-100"}`,
									children: st === "all" ? "All Orders" : st
								}, st, false, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "relative min-w-[220px]",
								children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Search buyer, order #, city...",
									value: orderSearch,
									onChange: (e) => setOrderSearch(e.target.value),
									className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded focus:border-slate-800 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 13
						}, this), filteredOrders.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-lg border border-slate-200 p-12 text-center text-slate-500",
							children: [
								/* @__PURE__ */ _jsxDEV(Clock, { className: "w-10 h-10 text-slate-300 mx-auto mb-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "text-sm font-semibold text-slate-700",
									children: "No orders found matching this filter"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 280,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 mt-1",
									children: "Place an order from the Storefront or click \"Simulate Order\" above to test."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 278,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: filteredOrders.map((order) => /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white rounded-lg border border-slate-200 p-4 hover:border-slate-300 transition-all shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1 min-w-[200px]",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono font-bold text-slate-900 text-sm",
													children: order.orderNumber
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 295,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: `text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded ${order.status === "pending" ? "bg-amber-50 text-amber-700 border border-amber-200" : order.status === "confirmed" ? "bg-blue-50 text-blue-700 border border-blue-200" : order.status === "shipped" ? "bg-purple-50 text-purple-700 border border-purple-200" : order.status === "delivered" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-slate-100 text-slate-600"}`,
													children: order.status
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 298,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 294,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] text-slate-400 font-mono",
												children: new Date(order.createdAt).toLocaleString([], {
													dateStyle: "short",
													timeStyle: "short"
												})
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 312,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-semibold text-slate-800",
												children: order.items.map((i) => `${i.quantity}x ${i.productName}`).join(", ")
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 315,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 293,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 min-w-0 max-w-xl text-xs space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [
												/* @__PURE__ */ _jsxDEV("strong", {
													className: "text-slate-900 font-semibold",
													children: order.customer.fullName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 323,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-400",
													children: "·"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 324,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-slate-600 flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-3 h-3 text-slate-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 326,
														columnNumber: 27
													}, this), order.customer.phone]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 325,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 322,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-1.5 text-slate-600 bg-slate-50 p-2 rounded border border-slate-100",
											children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 332,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "line-clamp-2",
												children: [
													/* @__PURE__ */ _jsxDEV("strong", {
														className: "text-slate-800",
														children: [order.customer.city, ":"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 334,
														columnNumber: 27
													}, this),
													" ",
													order.customer.deliveryAddress,
													order.customer.deliveryNote && /* @__PURE__ */ _jsxDEV("span", {
														className: "italic text-slate-400 block text-[11px]",
														children: ["Note: ", order.customer.deliveryNote]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 336,
														columnNumber: 29
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 333,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 331,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 321,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between lg:justify-end gap-3 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-100",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-left lg:text-right",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] text-slate-400 block uppercase",
												children: "Payable Total"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 345,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-base font-bold font-mono tabular-nums text-slate-900",
												children: ["PKR ", order.totalAmount.toLocaleString()]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 346,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 344,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("select", {
												value: order.status,
												onChange: (e) => updateOrderStatus(order.id, e.target.value),
												className: "px-2.5 py-1.5 text-xs font-medium rounded border border-slate-200 bg-white text-slate-800 focus:outline-none",
												children: [
													/* @__PURE__ */ _jsxDEV("option", {
														value: "pending",
														children: "Pending"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 357,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "confirmed",
														children: "Confirmed"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 358,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "shipped",
														children: "Shipped"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 359,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "delivered",
														children: "Delivered"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 360,
														columnNumber: 27
													}, this),
													/* @__PURE__ */ _jsxDEV("option", {
														value: "cancelled",
														children: "Cancelled"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 361,
														columnNumber: 27
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 352,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: () => setSelectedOrder(order),
												className: "px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors inline-flex items-center gap-1 cursor-pointer",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Details" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 368,
													columnNumber: 27
												}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 369,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 351,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 21
									}, this)
								]
							}, order.id, true, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 286,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 11
					}, this),
					activeTab === "inventory" && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3.5 rounded-lg border border-slate-200",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "relative min-w-[260px] max-w-sm",
								children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Search catalog by name, category, SKU...",
									value: inventorySearch,
									onChange: (e) => setInventorySearch(e.target.value),
									className: "w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded focus:border-slate-800 focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setEditingProduct(null);
									setProductModalOpen(true);
								},
								className: "px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors inline-flex items-center gap-1.5 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(Plus, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 404,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Add New Product" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 385,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-white rounded-lg border border-slate-200 overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ _jsxDEV("table", {
									className: "w-full text-left text-xs",
									children: [/* @__PURE__ */ _jsxDEV("thead", {
										className: "bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]",
										children: /* @__PURE__ */ _jsxDEV("tr", { children: [
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5",
												children: "Product"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 415,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5",
												children: "Category"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 416,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5",
												children: "Price"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 417,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5",
												children: "Stock Status"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5",
												children: "Units"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("th", {
												className: "p-3.5 text-right",
												children: "Actions"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 420,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 414,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 413,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("tbody", {
										className: "divide-y divide-slate-100",
										children: filteredProducts.map((prod) => /* @__PURE__ */ _jsxDEV("tr", {
											className: "hover:bg-slate-50/70 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5 flex items-center gap-3",
													children: [/* @__PURE__ */ _jsxDEV("img", {
														src: prod.imageUrl,
														alt: prod.name,
														className: "w-10 h-10 object-cover rounded border border-slate-200 bg-slate-100 shrink-0"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 427,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "font-semibold text-slate-900 line-clamp-1",
														children: prod.name
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 433,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[11px] font-mono text-slate-400",
														children: prod.sku
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 434,
														columnNumber: 29
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 432,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 426,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5 text-slate-600 font-medium",
													children: prod.category
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 438,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5 font-mono font-bold tabular-nums text-slate-900",
													children: ["PKR ", prod.price.toLocaleString()]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 442,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5",
													children: /* @__PURE__ */ _jsxDEV("span", {
														className: `inline-block text-[10px] font-semibold uppercase px-2 py-0.5 rounded ${prod.stockStatus === "in_stock" ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : prod.stockStatus === "low_stock" ? "bg-amber-50 text-amber-700 border border-amber-200" : "bg-rose-50 text-rose-700 border border-rose-200"}`,
														children: prod.stockStatus.replace("_", " ")
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 447,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 446,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5 font-mono tabular-nums text-slate-700",
													children: prod.stockCount
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 458,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("td", {
													className: "p-3.5 text-right",
													children: /* @__PURE__ */ _jsxDEV("div", {
														className: "inline-flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																setEditingProduct(prod);
																setProductModalOpen(true);
															},
															className: "p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors cursor-pointer",
															title: "Edit Product",
															children: /* @__PURE__ */ _jsxDEV(Edit3, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 472,
																columnNumber: 31
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 464,
															columnNumber: 29
														}, this), /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																if (window.confirm(`Are you sure you want to delete "${prod.name}"?`)) {
																	deleteProduct(prod.id);
																}
															},
															className: "p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors cursor-pointer",
															title: "Delete Product",
															children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 484,
																columnNumber: 31
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 475,
															columnNumber: 29
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 463,
														columnNumber: 27
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 462,
													columnNumber: 25
												}, this)
											]
										}, prod.id, true, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 423,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 412,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 411,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 410,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 382,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(SellerProductModal, {
				product: editingProduct,
				isOpen: productModalOpen,
				onClose: () => {
					setProductModalOpen(false);
					setEditingProduct(null);
				},
				onSave: handleSaveProduct
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 501,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(OrderDetailsModal, {
				order: selectedOrder,
				isOpen: !!selectedOrder,
				onClose: () => setSelectedOrder(null),
				onUpdateStatus: updateOrderStatus
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 512,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 104,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQjtBQUV6QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUNFLFNBQ0EsWUFDQSxPQUNBLGFBQ0EsTUFDQSxRQUNBLE9BQ0EsY0FDQSxPQUNBLFFBQ0EsV0FDQSxVQUNBLGNBRUs7OztBQUVQLE9BQU8sTUFBTSx3QkFBa0M7Q0FDN0MsTUFBTSxFQUNKLFVBQ0EsUUFDQSxZQUNBLGVBQ0EsZUFDQSxtQkFDQSxZQUNBLGlCQUNBLG1CQUNFLFNBQVM7Q0FFYixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBaUMsUUFBUTtDQUMzRSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBOEIsS0FBSztDQUN6RSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFTLEtBQUs7Q0FDOUQsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBeUIsSUFBSTtDQUN6RSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBdUIsSUFBSTtDQUNyRSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLEVBQUU7Q0FDekQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsRUFBRTs7Q0FHakQsTUFBTSxlQUFlLE9BQU8sUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLGFBQWEsQ0FBQztDQUNyRSxNQUFNLGdCQUFnQixPQUFPLFFBQU8sTUFBSyxFQUFFLFdBQVcsU0FBUztDQUMvRCxNQUFNLGtCQUFrQixPQUFPLFFBQU8sTUFBSyxFQUFFLFdBQVcsV0FBVzs7Q0FHbkUsTUFBTSxpQkFBaUIsT0FBTyxRQUFPLFVBQVM7RUFDNUMsTUFBTSxnQkFBZ0IsZ0JBQWdCLFNBQVMsTUFBTSxXQUFXO0VBQ2hFLE1BQU0sZ0JBQ0osTUFBTSxZQUFZLFlBQVksQ0FBQyxDQUFDLFNBQVMsWUFBWSxZQUFZLENBQUMsS0FDbEUsTUFBTSxTQUFTLFNBQVMsWUFBWSxDQUFDLENBQUMsU0FBUyxZQUFZLFlBQVksQ0FBQyxLQUN4RSxNQUFNLFNBQVMsS0FBSyxZQUFZLENBQUMsQ0FBQyxTQUFTLFlBQVksWUFBWSxDQUFDLEtBQ3BFLE1BQU0sU0FBUyxNQUFNLFNBQVMsV0FBVztFQUMzQyxPQUFPLGlCQUFpQjtDQUMxQixDQUFDOztDQUdELE1BQU0sbUJBQW1CLFNBQVMsUUFBTyxNQUN2QyxFQUFFLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxnQkFBZ0IsWUFBWSxDQUFDLEtBQzNELEVBQUUsSUFBSSxZQUFZLENBQUMsQ0FBQyxTQUFTLGdCQUFnQixZQUFZLENBQUMsS0FDMUQsRUFBRSxTQUFTLFlBQVksQ0FBQyxDQUFDLFNBQVMsZ0JBQWdCLFlBQVksQ0FBQyxDQUNqRTtDQUVBLE1BQU0scUJBQXFCLGdCQUE2RTtFQUN0RyxJQUFJLFlBQVksSUFBSTtHQUNsQixjQUFjLFlBQVksSUFBSSxXQUFXO0VBQzNDLE9BQU87R0FDTCxXQUFXLFdBQVc7RUFDeEI7Q0FDRjtDQUVBLE1BQU0sb0NBQW9DO0VBQ3hDLE1BQU0sY0FBYztHQUFDO0dBQWU7R0FBZTtHQUFlO0VBQWM7RUFDaEYsTUFBTSxlQUFlO0dBQUM7R0FBVztHQUFVO0dBQWE7RUFBVTtFQUNsRSxNQUFNLGdCQUFnQixTQUFTLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxTQUFTLE1BQU07RUFDekUsTUFBTSxhQUFhLFlBQVksS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLFlBQVksTUFBTTtFQUM1RSxNQUFNLGFBQWEsYUFBYSxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksYUFBYSxNQUFNO0VBRTlFLFdBQ0U7R0FDRSxVQUFVO0dBQ1YsT0FBTyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssT0FBTyxJQUFJLEVBQUUsRUFBRSxHQUFHLEtBQUssTUFBTSxNQUFVLEtBQUssT0FBTyxJQUFJLEdBQU87R0FDL0YsTUFBTTtHQUNOLGlCQUFpQixVQUFVLEtBQUssTUFBTSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsRUFBRSxZQUFZLEtBQUssTUFBTSxJQUFJLEtBQUssT0FBTyxJQUFJLEVBQUUsRUFBRTtHQUM3RyxjQUFjO0VBQ2hCLEdBQ0EsQ0FDRTtHQUNFLFdBQVcsY0FBYztHQUN6QixhQUFhLGNBQWM7R0FDM0IsT0FBTyxjQUFjO0dBQ3JCLFVBQVU7R0FDVixVQUFVLGNBQWM7RUFDMUIsQ0FDRixHQUNBLEtBQ0Y7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7Ozs7U0FDakMsd0JBQUMsUUFBRDtVQUFNLGVBQVk7b0JBQU87U0FBTzs7Ozs7U0FDaEMsd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7Ozs7UUFDbkM7Ozs7OztPQUNMLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUE0RTtPQUV0Rjs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBOEI7T0FFeEM7Ozs7O01BQ0E7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7U0FDVixPQUFNO21CQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O21CQUNsRCx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2lCQUNwQjs7Ozs7O1FBRVIsd0JBQUMsVUFBRDtTQUNFLGVBQWU7VUFDYixrQkFBa0IsSUFBSTtVQUN0QixvQkFBb0IsSUFBSTtTQUMxQjtTQUNBLFdBQVU7bUJBTFosQ0FPRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O21CQUMvQix3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7aUJBQ2pCOzs7Ozs7UUFFUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxlQUFlLE9BQU87U0FDckMsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7OztjQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7b0JBQzdCLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHlCQUEwQjs7OztrQkFDN0M7Ozs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQXFGLFFBQzlFLGFBQWEsZUFBZSxDQUM5Qjs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBaUQ7V0FBUSxPQUFPO1dBQU87VUFBWTs7Ozs7O1FBQ2hGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7OztvQkFDOUIsd0JBQUMsT0FBRCxFQUFPLFdBQVUseUJBQTBCOzs7O2tCQUN4Qzs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osY0FBYztTQUNaOzs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFrQztTQUFzQjs7Ozs7UUFDcEU7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O29CQUNsQyx3QkFBQyxhQUFELEVBQWEsV0FBVSwyQkFBNEI7Ozs7a0JBQ2hEOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixnQkFBZ0I7U0FDZDs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBa0M7U0FBcUI7Ozs7O1FBQ25FOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztvQkFDM0Isd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7O2tCQUMxQzs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osU0FBUztTQUNQOzs7OztTQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFrQztTQUFrQjs7Ozs7UUFDaEU7Ozs7OztNQUNGOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBR0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGFBQWEsUUFBUTtRQUNwQyxXQUFXLDRFQUNULGNBQWMsV0FDViw0QkFDQTtrQkFMUjtTQU9DO1NBQ2dDLE9BQU87U0FBTztRQUN2Qzs7Ozs7aUJBRVIsd0JBQUMsVUFBRDtRQUNFLGVBQWUsYUFBYSxXQUFXO1FBQ3ZDLFdBQVcsNEVBQ1QsY0FBYyxjQUNWLDRCQUNBO2tCQUxSO1NBT0M7U0FDd0IsU0FBUztTQUFPO1FBQ2pDOzs7OztlQUNMOzs7OztnQkFFTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7OztpQkFDaEMsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2VBQ2hCOzs7OztjQUNMOzs7Ozs7S0FHSixjQUFjLFlBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FHRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNYO1NBQUM7U0FBTztTQUFXO1NBQWE7U0FBVztTQUFhO1FBQVcsQ0FBQyxDQUFXLEtBQUksT0FDbkYsd0JBQUMsVUFBRDtTQUVFLGVBQWUsZUFBZSxFQUFFO1NBQ2hDLFdBQVcsdUdBQ1QsZ0JBQWdCLEtBQ1osNEJBQ0E7bUJBR0wsT0FBTyxRQUFRLGVBQWU7UUFDekIsR0FURDs7OztlQVNDLENBQ1Q7T0FDRTs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHlFQUEwRTs7OztrQkFDNUYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO1NBQzVDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7ZUFDRjs7Ozs7Z0JBR0osZUFBZSxXQUFXLElBQ3pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0NBQXlDOzs7OztRQUMxRCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBdUM7UUFBd0M7Ozs7O1FBQzdGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUE4QjtRQUV4Qzs7Ozs7T0FDQTs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osZUFBZSxLQUFJLFVBQ2xCLHdCQUFDLE9BQUQ7UUFFRSxXQUFVO2tCQUZaO1NBS0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUNiLE1BQU07WUFDSDs7OztzQkFDTix3QkFBQyxRQUFEO2FBQU0sV0FBVywwRUFDZixNQUFNLFdBQVcsWUFDYix1REFDQSxNQUFNLFdBQVcsY0FDakIsb0RBQ0EsTUFBTSxXQUFXLFlBQ2pCLDBEQUNBLE1BQU0sV0FBVyxjQUNqQiw2REFDQTt1QkFFSCxNQUFNO1lBQ0g7Ozs7b0JBQ0g7Ozs7OztXQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNaLElBQUksS0FBSyxNQUFNLFNBQVMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxHQUFHO2FBQUUsV0FBVzthQUFTLFdBQVc7WUFBUSxDQUFDO1dBQ3JGOzs7OztXQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNaLE1BQU0sTUFBTSxLQUFJLE1BQUssR0FBRyxFQUFFLFNBQVMsSUFBSSxFQUFFLGFBQWEsQ0FBQyxDQUFDLEtBQUssSUFBSTtXQUMvRDs7Ozs7VUFDRjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLFVBQUQ7YUFBUSxXQUFVO3VCQUFnQyxNQUFNLFNBQVM7WUFBaUI7Ozs7O1lBQ2xGLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFpQjtZQUFPOzs7OztZQUN4Qyx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7dUJBQzFDLE1BQU0sU0FBUyxLQUNaOzs7Ozs7V0FDSDs7Ozs7b0JBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw0Q0FBNkM7Ozs7cUJBQy9ELHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQjthQUNFLHdCQUFDLFVBQUQ7Y0FBUSxXQUFVO3dCQUFsQixDQUFvQyxNQUFNLFNBQVMsTUFBSyxHQUFTOzs7Ozs7YUFBQzthQUFFLE1BQU0sU0FBUzthQUNsRixNQUFNLFNBQVMsZ0JBQ2Qsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQTBELFVBQU8sTUFBTSxTQUFTLFlBQW1COzs7Ozs7WUFFakc7Ozs7O21CQUNIOzs7OztrQkFDRjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE2QztXQUFtQjs7OztxQkFDaEYsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQTRFLFFBQ3JFLE1BQU0sWUFBWSxlQUFlLENBQ2xDOzs7OzttQkFDSDs7Ozs7b0JBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1lBQ0UsT0FBTyxNQUFNO1lBQ2IsV0FBVSxNQUFLLGtCQUFrQixNQUFNLElBQUksRUFBRSxPQUFPLEtBQW9CO1lBQ3hFLFdBQVU7c0JBSFo7YUFLRSx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBVTthQUFlOzs7OzthQUN2Qyx3QkFBQyxVQUFEO2NBQVEsT0FBTTt3QkFBWTthQUFpQjs7Ozs7YUFDM0Msd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQVU7YUFBZTs7Ozs7YUFDdkMsd0JBQUMsVUFBRDtjQUFRLE9BQU07d0JBQVk7YUFBaUI7Ozs7O2FBQzNDLHdCQUFDLFVBQUQ7Y0FBUSxPQUFNO3dCQUFZO2FBQWlCOzs7OztZQUNyQzs7Ozs7cUJBRVIsd0JBQUMsVUFBRDtZQUNFLGVBQWUsaUJBQWlCLEtBQUs7WUFDckMsV0FBVTtzQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7O3NCQUNuQix3QkFBQyxjQUFELEVBQWMsV0FBVSxjQUFlOzs7O29CQUNqQzs7Ozs7bUJBQ0w7Ozs7O2tCQUNGOzs7Ozs7UUFDRjtVQXBGRSxNQUFNOzs7O2NBb0ZSLENBQ047TUFDRTs7OztjQUVKOzs7Ozs7S0FJTixjQUFjLGVBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FHRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUseUVBQTBFOzs7O2tCQUM1Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVSxNQUFLLG1CQUFtQixFQUFFLE9BQU8sS0FBSztTQUNoRCxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O2lCQUVMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlO1NBQ2Isa0JBQWtCLElBQUk7U0FDdEIsb0JBQW9CLElBQUk7UUFDMUI7UUFDQSxXQUFVO2tCQUxaLENBT0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztrQkFDL0Isd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztnQkFDckI7Ozs7O2VBQ0w7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUFqQixDQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNmLHdCQUFDLE1BQUQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUTtXQUFXOzs7OztXQUNqQyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUTtXQUFZOzs7OztXQUNsQyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUTtXQUFTOzs7OztXQUMvQix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBUTtXQUFnQjs7Ozs7V0FDdEMsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQVE7V0FBUzs7Ozs7V0FDL0Isd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQW1CO1dBQVc7Ozs7O1VBQzFDOzs7OztTQUNDOzs7O21CQUNQLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUNkLGlCQUFpQixLQUFJLFNBQ3BCLHdCQUFDLE1BQUQ7V0FBa0IsV0FBVTtxQkFBNUI7WUFDRSx3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFBZCxDQUNFLHdCQUFDLE9BQUQ7Y0FDRSxLQUFLLEtBQUs7Y0FDVixLQUFLLEtBQUs7Y0FDVixXQUFVO2FBQ1g7Ozs7dUJBQ0Qsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUE2QyxLQUFLO2FBQVU7Ozs7dUJBQzNFLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUF3QyxLQUFLO2FBQVM7Ozs7cUJBQ2xFOzs7O3FCQUNIOzs7Ozs7WUFFSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxLQUFLO1lBQ0o7Ozs7O1lBRUosd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQWQsQ0FBc0UsUUFDL0QsS0FBSyxNQUFNLGVBQWUsQ0FDN0I7Ozs7OztZQUVKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUNaLHdCQUFDLFFBQUQ7Y0FBTSxXQUFXLHdFQUNmLEtBQUssZ0JBQWdCLGFBQ2pCLDZEQUNBLEtBQUssZ0JBQWdCLGNBQ3JCLHVEQUNBO3dCQUVILEtBQUssWUFBWSxRQUFRLEtBQUssR0FBRzthQUM5Qjs7Ozs7WUFDSjs7Ozs7WUFFSix3QkFBQyxNQUFEO2FBQUksV0FBVTt1QkFDWCxLQUFLO1lBQ0o7Ozs7O1lBRUosd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQ1osd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxVQUFEO2VBQ0UsZUFBZTtnQkFDYixrQkFBa0IsSUFBSTtnQkFDdEIsb0JBQW9CLElBQUk7ZUFDMUI7ZUFDQSxXQUFVO2VBQ1YsT0FBTTt5QkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7OztjQUMxQjs7Ozt3QkFFUix3QkFBQyxVQUFEO2VBQ0UsZUFBZTtnQkFDYixJQUFJLE9BQU8sUUFBUSxvQ0FBb0MsS0FBSyxLQUFLLEdBQUcsR0FBRztpQkFDckUsY0FBYyxLQUFLLEVBQUU7Z0JBQ3ZCO2VBQ0Y7ZUFDQSxXQUFVO2VBQ1YsT0FBTTt5QkFFTix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztjQUMzQjs7OztzQkFDTDs7Ozs7O1lBQ0g7Ozs7O1dBQ0Y7YUEvREssS0FBSzs7OztpQkErRFYsQ0FDTDtTQUNJOzs7O2lCQUNGOzs7Ozs7T0FDSjs7Ozs7TUFDRjs7OztjQUVGOzs7Ozs7SUFHSjs7Ozs7O0dBR0wsd0JBQUMsb0JBQUQ7SUFDRSxTQUFTO0lBQ1QsUUFBUTtJQUNSLGVBQWU7S0FDYixvQkFBb0IsS0FBSztLQUN6QixrQkFBa0IsSUFBSTtJQUN4QjtJQUNBLFFBQVE7R0FDVDs7Ozs7R0FHRCx3QkFBQyxtQkFBRDtJQUNFLE9BQU87SUFDUCxRQUFRLENBQUMsQ0FBQztJQUNWLGVBQWUsaUJBQWlCLElBQUk7SUFDcEMsZ0JBQWdCO0dBQ2pCOzs7OztFQUVFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZWxsZXJEYXNoYm9hcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSAnLi4vLi4vY29udGV4dC9TdG9yZUNvbnRleHQnO1xuaW1wb3J0IHsgUHJvZHVjdCwgT3JkZXIsIE9yZGVyU3RhdHVzIH0gZnJvbSAnLi4vLi4vdHlwZXMvc3RvcmUnO1xuaW1wb3J0IHsgU2VsbGVyUHJvZHVjdE1vZGFsIH0gZnJvbSAnLi9TZWxsZXJQcm9kdWN0TW9kYWwnO1xuaW1wb3J0IHsgT3JkZXJEZXRhaWxzTW9kYWwgfSBmcm9tICcuL09yZGVyRGV0YWlsc01vZGFsJztcbmltcG9ydCB7IFxuICBQYWNrYWdlLCBcbiAgRG9sbGFyU2lnbiwgXG4gIENsb2NrLCBcbiAgQ2hlY2tDaXJjbGUsIFxuICBQbHVzLCBcbiAgTWFwUGluLCBcbiAgUGhvbmUsIFxuICBFeHRlcm5hbExpbmssIFxuICBFZGl0MywgXG4gIFRyYXNoMiwgXG4gIFJvdGF0ZUNjdyxcbiAgU3BhcmtsZXMsXG4gIFNlYXJjaCxcbiAgRmlsdGVyXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBTZWxsZXJEYXNoYm9hcmQ6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7XG4gICAgcHJvZHVjdHMsXG4gICAgb3JkZXJzLFxuICAgIGFkZFByb2R1Y3QsXG4gICAgdXBkYXRlUHJvZHVjdCxcbiAgICBkZWxldGVQcm9kdWN0LFxuICAgIHVwZGF0ZU9yZGVyU3RhdHVzLFxuICAgIHBsYWNlT3JkZXIsXG4gICAgcmVzZXRUb0RlZmF1bHRzLFxuICAgIHNldEN1cnJlbnRWaWV3XG4gIH0gPSB1c2VTdG9yZSgpO1xuXG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwnb3JkZXJzJyB8ICdpbnZlbnRvcnknPignb3JkZXJzJyk7XG4gIGNvbnN0IFtvcmRlckZpbHRlciwgc2V0T3JkZXJGaWx0ZXJdID0gdXNlU3RhdGU8J2FsbCcgfCBPcmRlclN0YXR1cz4oJ2FsbCcpO1xuICBjb25zdCBbcHJvZHVjdE1vZGFsT3Blbiwgc2V0UHJvZHVjdE1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtlZGl0aW5nUHJvZHVjdCwgc2V0RWRpdGluZ1Byb2R1Y3RdID0gdXNlU3RhdGU8UHJvZHVjdCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbc2VsZWN0ZWRPcmRlciwgc2V0U2VsZWN0ZWRPcmRlcl0gPSB1c2VTdGF0ZTxPcmRlciB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaW52ZW50b3J5U2VhcmNoLCBzZXRJbnZlbnRvcnlTZWFyY2hdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbb3JkZXJTZWFyY2gsIHNldE9yZGVyU2VhcmNoXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBTdGF0cyBDYWxjdWxhdGlvbnNcbiAgY29uc3QgdG90YWxSZXZlbnVlID0gb3JkZXJzLnJlZHVjZSgoc3VtLCBvKSA9PiBzdW0gKyBvLnRvdGFsQW1vdW50LCAwKTtcbiAgY29uc3QgcGVuZGluZ09yZGVycyA9IG9yZGVycy5maWx0ZXIobyA9PiBvLnN0YXR1cyA9PT0gJ3BlbmRpbmcnKTtcbiAgY29uc3QgZGVsaXZlcmVkT3JkZXJzID0gb3JkZXJzLmZpbHRlcihvID0+IG8uc3RhdHVzID09PSAnZGVsaXZlcmVkJyk7XG5cbiAgLy8gRmlsdGVyZWQgT3JkZXJzXG4gIGNvbnN0IGZpbHRlcmVkT3JkZXJzID0gb3JkZXJzLmZpbHRlcihvcmRlciA9PiB7XG4gICAgY29uc3QgbWF0Y2hlc0ZpbHRlciA9IG9yZGVyRmlsdGVyID09PSAnYWxsJyB8fCBvcmRlci5zdGF0dXMgPT09IG9yZGVyRmlsdGVyO1xuICAgIGNvbnN0IG1hdGNoZXNTZWFyY2ggPVxuICAgICAgb3JkZXIub3JkZXJOdW1iZXIudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhvcmRlclNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgb3JkZXIuY3VzdG9tZXIuZnVsbE5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhvcmRlclNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxuICAgICAgb3JkZXIuY3VzdG9tZXIuY2l0eS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG9yZGVyU2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICBvcmRlci5jdXN0b21lci5waG9uZS5pbmNsdWRlcyhvcmRlclNlYXJjaCk7XG4gICAgcmV0dXJuIG1hdGNoZXNGaWx0ZXIgJiYgbWF0Y2hlc1NlYXJjaDtcbiAgfSk7XG5cbiAgLy8gRmlsdGVyZWQgSW52ZW50b3J5XG4gIGNvbnN0IGZpbHRlcmVkUHJvZHVjdHMgPSBwcm9kdWN0cy5maWx0ZXIocCA9PlxuICAgIHAubmFtZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGludmVudG9yeVNlYXJjaC50b0xvd2VyQ2FzZSgpKSB8fFxuICAgIHAuc2t1LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoaW52ZW50b3J5U2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgcC5jYXRlZ29yeS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKGludmVudG9yeVNlYXJjaC50b0xvd2VyQ2FzZSgpKVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZVNhdmVQcm9kdWN0ID0gKHByb2R1Y3REYXRhOiBPbWl0PFByb2R1Y3QsICdpZCcgfCAnY3JlYXRlZEF0JyB8ICdza3UnPiAmIHsgaWQ/OiBzdHJpbmcgfSkgPT4ge1xuICAgIGlmIChwcm9kdWN0RGF0YS5pZCkge1xuICAgICAgdXBkYXRlUHJvZHVjdChwcm9kdWN0RGF0YS5pZCwgcHJvZHVjdERhdGEpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhZGRQcm9kdWN0KHByb2R1Y3REYXRhKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU2ltdWxhdGVJbmNvbWluZ09yZGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IHNhbXBsZU5hbWVzID0gWydadWJhaXIgS2hhbicsICdNYXJpYW0gU2hhaCcsICdIYXNzYW4gUmF6YScsICdGYXRpbWEgWmFocmEnXTtcbiAgICBjb25zdCBzYW1wbGVDaXRpZXMgPSBbJ0thcmFjaGknLCAnTGFob3JlJywgJ0lzbGFtYWJhZCcsICdQZXNoYXdhciddO1xuICAgIGNvbnN0IHJhbmRvbVByb2R1Y3QgPSBwcm9kdWN0c1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBwcm9kdWN0cy5sZW5ndGgpXTtcbiAgICBjb25zdCByYW5kb21OYW1lID0gc2FtcGxlTmFtZXNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogc2FtcGxlTmFtZXMubGVuZ3RoKV07XG4gICAgY29uc3QgcmFuZG9tQ2l0eSA9IHNhbXBsZUNpdGllc1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBzYW1wbGVDaXRpZXMubGVuZ3RoKV07XG5cbiAgICBwbGFjZU9yZGVyKFxuICAgICAge1xuICAgICAgICBmdWxsTmFtZTogcmFuZG9tTmFtZSxcbiAgICAgICAgcGhvbmU6IGAwMyR7TWF0aC5mbG9vcigxMCArIE1hdGgucmFuZG9tKCkgKiA0MCl9LSR7TWF0aC5mbG9vcigxMDAwMDAwICsgTWF0aC5yYW5kb20oKSAqIDkwMDAwMDApfWAsXG4gICAgICAgIGNpdHk6IHJhbmRvbUNpdHksXG4gICAgICAgIGRlbGl2ZXJ5QWRkcmVzczogYEhvdXNlICMke01hdGguZmxvb3IoMSArIE1hdGgucmFuZG9tKCkgKiA5OSl9LCBTdHJlZXQgIyR7TWF0aC5mbG9vcigxICsgTWF0aC5yYW5kb20oKSAqIDIwKX0sIFNlY3RvciBHLTEwYCxcbiAgICAgICAgZGVsaXZlcnlOb3RlOiAnVXJnZW50IGRlbGl2ZXJ5IHJlcXVlc3RlZCBwbGVhc2UgY2FsbCBmaXJzdCdcbiAgICAgIH0sXG4gICAgICBbXG4gICAgICAgIHtcbiAgICAgICAgICBwcm9kdWN0SWQ6IHJhbmRvbVByb2R1Y3QuaWQsXG4gICAgICAgICAgcHJvZHVjdE5hbWU6IHJhbmRvbVByb2R1Y3QubmFtZSxcbiAgICAgICAgICBwcmljZTogcmFuZG9tUHJvZHVjdC5wcmljZSxcbiAgICAgICAgICBxdWFudGl0eTogMSxcbiAgICAgICAgICBpbWFnZVVybDogcmFuZG9tUHJvZHVjdC5pbWFnZVVybFxuICAgICAgICB9XG4gICAgICBdLFxuICAgICAgJ2NvZCdcbiAgICApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTAgcGItMjBcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBCYW5uZXIgLyBCcmVhZGNydW1iICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LTggcHktNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBtZDppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00XCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgdGV4dC1zbGF0ZS01MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlZlbmRvciBDb250cm9sIENlbnRlcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZWFsLVRpbWUgU3RvcmUgTWFuYWdlbWVudDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgZm9udC1kaXNwbGF5XCI+XG4gICAgICAgICAgICAgICAgU2VsbGVyIENvbW1hbmQgSHViXG4gICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgIE1hbmFnZSBsaXZlIGN1c3RvbWVyIG9yZGVycywgY291cmllciBkaXNwYXRjaCBsb2NhdGlvbnMsIGFuZCBwcm9kdWN0IGNhdGFsb2cgaW52ZW50b3J5LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNpbXVsYXRlSW5jb21pbmdPcmRlcn1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgYmctYW1iZXItNTAgaG92ZXI6YmctYW1iZXItMTAwIGJvcmRlciBib3JkZXItYW1iZXItMjAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiU2ltdWxhdGUgYSByZWFsLXRpbWUgYnV5ZXIgb3JkZXIgdG8gdGVzdCB0aGUgbm90aWZpY2F0aW9uXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U2ltdWxhdGUgT3JkZXI8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nUHJvZHVjdChudWxsKTtcbiAgICAgICAgICAgICAgICAgIHNldFByb2R1Y3RNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGN1cnNvci1wb2ludGVyIHNoYWRvdy14c1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UGx1cyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+QWRkIFByb2R1Y3Q8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50VmlldygnYnV5ZXInKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgYmctd2hpdGUgaG92ZXI6Ymctc2xhdGUtMTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgVmlldyBTdG9yZWZyb250ICZyYXJyO1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEtQSSBTdGF0IENhcmRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCBtdC02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNTAwIHRleHQteHMgbWItMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsIEdyb3NzIFNhbGVzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxEb2xsYXJTaWduIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCBmb250LW1vbm8gdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgUEtSIHt0b3RhbFJldmVudWUudG9Mb2NhbGVTdHJpbmcoKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPkFjcm9zcyB7b3JkZXJzLmxlbmd0aH0gb3JkZXJzPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHAtNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzIG1iLTFcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5QZW5kaW5nIERlbGl2ZXJpZXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCBmb250LW1vbm8gdGFidWxhci1udW1zIHRleHQtYW1iZXItNzAwXCI+XG4gICAgICAgICAgICAgICAge3BlbmRpbmdPcmRlcnMubGVuZ3RofVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+QXdhaXRpbmcgZGlzcGF0Y2g8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNTAwIHRleHQteHMgbWItMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPkRlbGl2ZXJlZCBTdWNjZXNzZnVsbHk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTUwMFwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteGwgc206dGV4dC0yeGwgZm9udC1ib2xkIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgdGV4dC1lbWVyYWxkLTcwMFwiPlxuICAgICAgICAgICAgICAgIHtkZWxpdmVyZWRPcmRlcnMubGVuZ3RofVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBtdC0xXCI+Q29tcGxldGVkIG9yZGVyczwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS01MDAgdGV4dC14cyBtYi0xXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+QWN0aXZlIFByb2R1Y3RzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxQYWNrYWdlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhsIHNtOnRleHQtMnhsIGZvbnQtYm9sZCBmb250LW1vbm8gdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAge3Byb2R1Y3RzLmxlbmd0aH1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMVwiPkxpdmUgaW4gc3RvcmU8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWFpbiBXb3Jrc3BhY2UgVGFicyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LTggbXQtNlwiPlxuICAgICAgICBcbiAgICAgICAgey8qIE5hdmlnYXRpb24gVGFicyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBwYi0zIG1iLTZcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignb3JkZXJzJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ29yZGVycydcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgdGV4dC1zbGF0ZS02MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtMTAwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgSW5jb21pbmcgT3JkZXJzICYgRGVsaXZlcmllcyAoe29yZGVycy5sZW5ndGh9KVxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdpbnZlbnRvcnknKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnaW52ZW50b3J5J1xuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LXNsYXRlLTYwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBob3ZlcjpiZy1zbGF0ZS0xMDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBJbnZlbnRvcnkgTWFuYWdlbWVudCAoe3Byb2R1Y3RzLmxlbmd0aH0pXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e3Jlc2V0VG9EZWZhdWx0c31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT1cIlJlc2V0IHN0b3JlIHRvIGluaXRpYWwgZGVmYXVsdCBjYXRhbG9nIGFuZCBvcmRlcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICA8c3Bhbj5SZXNldCBEZW1vPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVEFCIDE6IE9SREVSUyAmIERFTElWRVJJRVMgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdvcmRlcnMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogRmlsdGVyIGFuZCBTZWFyY2ggQmFyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctd2hpdGUgcC0zLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgb3ZlcmZsb3cteC1hdXRvIHBiLTEgc206cGItMFwiPlxuICAgICAgICAgICAgICAgIHsoWydhbGwnLCAncGVuZGluZycsICdjb25maXJtZWQnLCAnc2hpcHBlZCcsICdkZWxpdmVyZWQnLCAnY2FuY2VsbGVkJ10gYXMgY29uc3QpLm1hcChzdCA9PiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGtleT17c3R9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9yZGVyRmlsdGVyKHN0KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBjdXJzb3ItcG9pbnRlciBjYXBpdGFsaXplICR7XG4gICAgICAgICAgICAgICAgICAgICAgb3JkZXJGaWx0ZXIgPT09IHN0XG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS04MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwIGhvdmVyOmJnLXNsYXRlLTEwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzdCA9PT0gJ2FsbCcgPyAnQWxsIE9yZGVycycgOiBzdH1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG1pbi13LVsyMjBweF1cIj5cbiAgICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41IHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggYnV5ZXIsIG9yZGVyICMsIGNpdHkuLi5cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e29yZGVyU2VhcmNofVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0T3JkZXJTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHBsLTggcHItMyBweS0xLjUgdGV4dC14cyBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogT3JkZXJzIExpc3QgKi99XG4gICAgICAgICAgICB7ZmlsdGVyZWRPcmRlcnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC0xMiB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTUwMFwiPlxuICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1zbGF0ZS0zMDAgbXgtYXV0byBtYi0yXCIgLz5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+Tm8gb3JkZXJzIGZvdW5kIG1hdGNoaW5nIHRoaXMgZmlsdGVyPC9oND5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgIFBsYWNlIGFuIG9yZGVyIGZyb20gdGhlIFN0b3JlZnJvbnQgb3IgY2xpY2sgXCJTaW11bGF0ZSBPcmRlclwiIGFib3ZlIHRvIHRlc3QuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAge2ZpbHRlcmVkT3JkZXJzLm1hcChvcmRlciA9PiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17b3JkZXIuaWR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcC00IGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXhzIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBMZWZ0OiBPcmRlciBJZGVudGlmaWVyICYgU3RhdHVzICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMSBtaW4tdy1bMjAwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlci5vcmRlck51bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHB4LTIgcHktMC41IHJvdW5kZWQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgb3JkZXIuc3RhdHVzID09PSAncGVuZGluZydcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG9yZGVyLnN0YXR1cyA9PT0gJ2NvbmZpcm1lZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwIHRleHQtYmx1ZS03MDAgYm9yZGVyIGJvcmRlci1ibHVlLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IG9yZGVyLnN0YXR1cyA9PT0gJ3NoaXBwZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcHVycGxlLTUwIHRleHQtcHVycGxlLTcwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBvcmRlci5zdGF0dXMgPT09ICdkZWxpdmVyZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXIuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUob3JkZXIuY3JlYXRlZEF0KS50b0xvY2FsZVN0cmluZyhbXSwgeyBkYXRlU3R5bGU6ICdzaG9ydCcsIHRpbWVTdHlsZTogJ3Nob3J0JyB9KX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge29yZGVyLml0ZW1zLm1hcChpID0+IGAke2kucXVhbnRpdHl9eCAke2kucHJvZHVjdE5hbWV9YCkuam9pbignLCAnKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIE1pZGRsZTogQnV5ZXIgRGV0YWlscyAmIERlbGl2ZXJ5IExvY2F0aW9uICovfVxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBtaW4tdy0wIG1heC13LXhsIHRleHQteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkXCI+e29yZGVyLmN1c3RvbWVyLmZ1bGxOYW1lfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNsYXRlLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LXNsYXRlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41IHRleHQtc2xhdGUtNjAwIGJnLXNsYXRlLTUwIHAtMiByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcm9zZS01MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImxpbmUtY2xhbXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtODAwXCI+e29yZGVyLmN1c3RvbWVyLmNpdHl9Ojwvc3Ryb25nPiB7b3JkZXIuY3VzdG9tZXIuZGVsaXZlcnlBZGRyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3JkZXIuY3VzdG9tZXIuZGVsaXZlcnlOb3RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJpdGFsaWMgdGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5Ob3RlOiB7b3JkZXIuY3VzdG9tZXIuZGVsaXZlcnlOb3RlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgey8qIFJpZ2h0OiBBbW91bnQsIFN0YXR1cyBEcm9wZG93biAmIEFjdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbGc6anVzdGlmeS1lbmQgZ2FwLTMgc2hyaW5rLTAgcHQtMiBsZzpwdC0wIGJvcmRlci10IGxnOmJvcmRlci10LTAgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGxnOnRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrIHVwcGVyY2FzZVwiPlBheWFibGUgVG90YWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgUEtSIHtvcmRlci50b3RhbEFtb3VudC50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17b3JkZXIuc3RhdHVzfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiB1cGRhdGVPcmRlclN0YXR1cyhvcmRlci5pZCwgZS50YXJnZXQudmFsdWUgYXMgT3JkZXJTdGF0dXMpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy13aGl0ZSB0ZXh0LXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwicGVuZGluZ1wiPlBlbmRpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImNvbmZpcm1lZFwiPkNvbmZpcm1lZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwic2hpcHBlZFwiPlNoaXBwZWQ8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImRlbGl2ZXJlZFwiPkRlbGl2ZXJlZDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiY2FuY2VsbGVkXCI+Q2FuY2VsbGVkPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZE9yZGVyKG9yZGVyKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EZXRhaWxzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RXh0ZXJuYWxMaW5rIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRBQiAyOiBJTlZFTlRPUlkgJiBQUk9EVUNUUyAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2ludmVudG9yeScgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHsvKiBTZWFyY2ggYW5kIEFjdGlvbiBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBiZy13aGl0ZSBwLTMuNSByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbWluLXctWzI2MHB4XSBtYXgtdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgYWJzb2x1dGUgbGVmdC0zIHRvcC0yLjUgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBjYXRhbG9nIGJ5IG5hbWUsIGNhdGVnb3J5LCBTS1UuLi5cIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2ludmVudG9yeVNlYXJjaH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldEludmVudG9yeVNlYXJjaChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtOCBwci0zIHB5LTEuNSB0ZXh0LXhzIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9jdXM6Ym9yZGVyLXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRFZGl0aW5nUHJvZHVjdChudWxsKTtcbiAgICAgICAgICAgICAgICAgIHNldFByb2R1Y3RNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFBsdXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkFkZCBOZXcgUHJvZHVjdDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEludmVudG9yeSBUYWJsZSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtNTAgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LVsxMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMy41XCI+UHJvZHVjdDwvdGg+XG4gICAgICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInAtMy41XCI+Q2F0ZWdvcnk8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMuNVwiPlByaWNlPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zLjVcIj5TdG9jayBTdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJwLTMuNVwiPlVuaXRzPC90aD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicC0zLjUgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtmaWx0ZXJlZFByb2R1Y3RzLm1hcChwcm9kID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtwcm9kLmlkfSBjbGFzc05hbWU9XCJob3ZlcjpiZy1zbGF0ZS01MC83MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMy41IGZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9e3Byb2QuaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PXtwcm9kLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIG9iamVjdC1jb3ZlciByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBzaHJpbmstMFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGxpbmUtY2xhbXAtMVwiPntwcm9kLm5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj57cHJvZC5za3V9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMy41IHRleHQtc2xhdGUtNjAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kLmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMy41IGZvbnQtbW9ubyBmb250LWJvbGQgdGFidWxhci1udW1zIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIFBLUiB7cHJvZC5wcmljZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInAtMy41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YGlubGluZS1ibG9jayB0ZXh0LVsxMHB4XSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSBweC0yIHB5LTAuNSByb3VuZGVkICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvZC5zdG9ja1N0YXR1cyA9PT0gJ2luX3N0b2NrJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MCB0ZXh0LWVtZXJhbGQtNzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IHByb2Quc3RvY2tTdGF0dXMgPT09ICdsb3dfc3RvY2snXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MCB0ZXh0LWFtYmVyLTcwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTIwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXJvc2UtNTAgdGV4dC1yb3NlLTcwMCBib3JkZXIgYm9yZGVyLXJvc2UtMjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Byb2Quc3RvY2tTdGF0dXMucmVwbGFjZSgnXycsICcgJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJwLTMuNSBmb250LW1vbm8gdGFidWxhci1udW1zIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtwcm9kLnN0b2NrQ291bnR9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicC0zLjUgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0RWRpdGluZ1Byb2R1Y3QocHJvZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFByb2R1Y3RNb2RhbE9wZW4odHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtMTAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJFZGl0IFByb2R1Y3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxFZGl0MyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh3aW5kb3cuY29uZmlybShgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSBcIiR7cHJvZC5uYW1lfVwiP2ApKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlUHJvZHVjdChwcm9kLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtcm9zZS02MDAgaG92ZXI6Ymctcm9zZS01MCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIFByb2R1Y3RcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQcm9kdWN0IEFkZCAvIEVkaXQgTW9kYWwgKi99XG4gICAgICA8U2VsbGVyUHJvZHVjdE1vZGFsXG4gICAgICAgIHByb2R1Y3Q9e2VkaXRpbmdQcm9kdWN0fVxuICAgICAgICBpc09wZW49e3Byb2R1Y3RNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHtcbiAgICAgICAgICBzZXRQcm9kdWN0TW9kYWxPcGVuKGZhbHNlKTtcbiAgICAgICAgICBzZXRFZGl0aW5nUHJvZHVjdChudWxsKTtcbiAgICAgICAgfX1cbiAgICAgICAgb25TYXZlPXtoYW5kbGVTYXZlUHJvZHVjdH1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBPcmRlciBEZXRhaWxzIE1vZGFsICovfVxuICAgICAgPE9yZGVyRGV0YWlsc01vZGFsXG4gICAgICAgIG9yZGVyPXtzZWxlY3RlZE9yZGVyfVxuICAgICAgICBpc09wZW49eyEhc2VsZWN0ZWRPcmRlcn1cbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2VsZWN0ZWRPcmRlcihudWxsKX1cbiAgICAgICAgb25VcGRhdGVTdGF0dXM9e3VwZGF0ZU9yZGVyU3RhdHVzfVxuICAgICAgLz5cblxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==