const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { PRESET_IMAGE_OPTIONS } from "/src/data/defaultProducts.ts";
import { X, Image as ImageIcon, Check } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/seller/SellerProductModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const SellerProductModal = ({ product, isOpen, onClose, onSave }) => {
	const [name, setName] = useState("");
	const [description, setDescription] = useState("");
	const [price, setPrice] = useState(0);
	const [stockStatus, setStockStatus] = useState("in_stock");
	const [stockCount, setStockCount] = useState(10);
	const [category, setCategory] = useState("Electronics");
	const [imageUrl, setImageUrl] = useState("");
	const [errorMsg, setErrorMsg] = useState("");
	useEffect(() => {
		if (product) {
			setName(product.name);
			setDescription(product.description);
			setPrice(product.price);
			setStockStatus(product.stockStatus);
			setStockCount(product.stockCount);
			setCategory(product.category);
			setImageUrl(product.imageUrl);
		} else {
			setName("");
			setDescription("");
			setPrice(5e3);
			setStockStatus("in_stock");
			setStockCount(15);
			setCategory("Electronics");
			setImageUrl(PRESET_IMAGE_OPTIONS[0].url);
		}
		setErrorMsg("");
	}, [product, isOpen]);
	if (!isOpen) return null;
	const handleSubmit = (e) => {
		e.preventDefault();
		if (!name.trim()) {
			setErrorMsg("Product name is required");
			return;
		}
		if (price <= 0) {
			setErrorMsg("Price must be greater than 0");
			return;
		}
		if (!imageUrl.trim()) {
			setErrorMsg("Product image is required");
			return;
		}
		onSave({
			id: product?.id,
			name: name.trim(),
			description: description.trim(),
			price: Number(price),
			stockStatus,
			stockCount: Number(stockCount),
			category,
			imageUrl: imageUrl.trim()
		});
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in duration-200",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: "text-base font-bold text-slate-900 font-display",
					children: product ? "Edit Product Details" : "Add New Product to Store"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-500",
					children: product ? "Update product pricing, stock status, or description" : "Enter product information and stock availability"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors cursor-pointer",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "p-6 space-y-4",
				children: [
					errorMsg && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded",
						children: errorMsg
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 104,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-slate-700 mb-1",
						children: ["Product Name ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-rose-500",
							children: "*"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 28
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						required: true,
						placeholder: "e.g. Wireless Noise Canceling Headphones",
						value: name,
						onChange: (e) => setName(e.target.value),
						className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none transition-colors"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 mb-1",
							children: ["Category ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-rose-500",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 26
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none bg-white",
							children: [
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Electronics",
									children: "Electronics"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 135,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Audio Gear",
									children: "Audio Gear"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Leather & Travel",
									children: "Leather & Travel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Footwear",
									children: "Footwear"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Accessories",
									children: "Accessories"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "Home & Living",
									children: "Home & Living"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 mb-1",
							children: ["Price (PKR) ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-rose-500",
								children: "*"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "number",
							min: "100",
							step: "50",
							required: true,
							value: price,
							onChange: (e) => setPrice(Number(e.target.value)),
							className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none font-mono tabular-nums"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 144,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 mb-1",
							children: "Stock Status"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("select", {
							value: stockStatus,
							onChange: (e) => setStockStatus(e.target.value),
							className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none bg-white",
							children: [
								/* @__PURE__ */ _jsxDEV("option", {
									value: "in_stock",
									children: "In Stock"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 171,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "low_stock",
									children: "Low Stock"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "out_of_stock",
									children: "Out of Stock"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 162,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 mb-1",
							children: "Stock Units"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "number",
							min: "0",
							value: stockCount,
							onChange: (e) => setStockCount(Number(e.target.value)),
							className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none font-mono tabular-nums"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-semibold text-slate-700 mb-1",
							children: "Product Image"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 193,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "mb-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-400 block mb-1",
								children: "Quick Select Studio Photo Presets:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-4 gap-2",
								children: PRESET_IMAGE_OPTIONS.map((preset) => /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setImageUrl(preset.url),
									className: `relative aspect-4/3 rounded border overflow-hidden transition-all cursor-pointer ${imageUrl === preset.url ? "border-slate-900 ring-2 ring-slate-900/20" : "border-slate-200 hover:border-slate-300 opacity-70 hover:opacity-100"}`,
									children: [/* @__PURE__ */ _jsxDEV("img", {
										src: preset.url,
										alt: preset.label,
										className: "w-full h-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 212,
										columnNumber: 21
									}, this), imageUrl === preset.url && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 bg-slate-900/40 flex items-center justify-center text-white",
										children: /* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 23
									}, this)]
								}, preset.url, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 200,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV(ImageIcon, { className: "w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 224,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Or paste direct Image URL...",
								value: imageUrl,
								onChange: (e) => setImageUrl(e.target.value),
								className: "w-full pl-9 pr-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none font-mono text-[11px]"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 223,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						className: "block text-xs font-semibold text-slate-700 mb-1",
						children: "Description / Specifications"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 237,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						rows: 3,
						placeholder: "Highlight product features, materials, warranty, or packaging contents...",
						value: description,
						onChange: (e) => setDescription(e.target.value),
						className: "w-full px-3 py-2 text-xs border border-slate-200 rounded focus:border-slate-800 focus:outline-none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 240,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 236,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "pt-3 border-t border-slate-200 flex items-center justify-end gap-2",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: onClose,
							className: "px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors cursor-pointer",
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "px-5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors cursor-pointer shadow-xs",
							children: product ? "Save Changes" : "Publish Product"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 250,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 80,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBRTNDLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsR0FBRyxTQUFTLFdBQVcsYUFBYTs7O0FBUzdDLE9BQU8sTUFBTSxzQkFBeUQsRUFDcEUsU0FDQSxRQUNBLFNBQ0EsYUFDSTtDQUNKLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBQ25DLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFpQixDQUFDO0NBQzVDLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFzQixVQUFVO0NBQ3RFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxhQUFhO0NBQ3RELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBRTNDLGdCQUFnQjtFQUNkLElBQUksU0FBUztHQUNYLFFBQVEsUUFBUSxJQUFJO0dBQ3BCLGVBQWUsUUFBUSxXQUFXO0dBQ2xDLFNBQVMsUUFBUSxLQUFLO0dBQ3RCLGVBQWUsUUFBUSxXQUFXO0dBQ2xDLGNBQWMsUUFBUSxVQUFVO0dBQ2hDLFlBQVksUUFBUSxRQUFRO0dBQzVCLFlBQVksUUFBUSxRQUFRO0VBQzlCLE9BQU87R0FDTCxRQUFRLEVBQUU7R0FDVixlQUFlLEVBQUU7R0FDakIsU0FBUyxHQUFJO0dBQ2IsZUFBZSxVQUFVO0dBQ3pCLGNBQWMsRUFBRTtHQUNoQixZQUFZLGFBQWE7R0FDekIsWUFBWSxxQkFBcUIsRUFBRSxDQUFDLEdBQUc7RUFDekM7RUFDQSxZQUFZLEVBQUU7Q0FDaEIsR0FBRyxDQUFDLFNBQVMsTUFBTSxDQUFDO0NBRXBCLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxnQkFBZ0IsTUFBdUI7RUFDM0MsRUFBRSxlQUFlO0VBQ2pCLElBQUksQ0FBQyxLQUFLLEtBQUssR0FBRztHQUNoQixZQUFZLDBCQUEwQjtHQUN0QztFQUNGO0VBQ0EsSUFBSSxTQUFTLEdBQUc7R0FDZCxZQUFZLDhCQUE4QjtHQUMxQztFQUNGO0VBQ0EsSUFBSSxDQUFDLFNBQVMsS0FBSyxHQUFHO0dBQ3BCLFlBQVksMkJBQTJCO0dBQ3ZDO0VBQ0Y7RUFFQSxPQUFPO0dBQ0wsSUFBSSxTQUFTO0dBQ2IsTUFBTSxLQUFLLEtBQUs7R0FDaEIsYUFBYSxZQUFZLEtBQUs7R0FDOUIsT0FBTyxPQUFPLEtBQUs7R0FDbkI7R0FDQSxZQUFZLE9BQU8sVUFBVTtHQUM3QjtHQUNBLFVBQVUsU0FBUyxLQUFLO0VBQzFCLENBQUM7RUFDRCxRQUFRO0NBQ1Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUdFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFDWCxVQUFVLHlCQUF5QjtJQUNsQzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsVUFBVSx5REFBeUQ7SUFDbkU7Ozs7WUFDQTs7OztjQUNMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0lBQ2xCOzs7O1lBQ0w7Ozs7O2FBR0wsd0JBQUMsUUFBRDtJQUFNLFVBQVU7SUFBYyxXQUFVO2NBQXhDO0tBQ0csWUFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWjtLQUNFOzs7OztLQUlQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FBbUUsaUJBQ3BELHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnQjtNQUFPOzs7O2NBQy9DOzs7OztlQUNQLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0w7TUFDQSxhQUFZO01BQ1osT0FBTztNQUNQLFdBQVUsTUFBSyxRQUFRLEVBQUUsT0FBTyxLQUFLO01BQ3JDLFdBQVU7S0FDWDs7OzthQUNFOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUFtRSxhQUN4RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBTzs7OztlQUMzQzs7Ozs7Z0JBQ1Asd0JBQUMsVUFBRDtPQUNFLE9BQU87T0FDUCxXQUFVLE1BQUssWUFBWSxFQUFFLE9BQU8sS0FBSztPQUN6QyxXQUFVO2lCQUhaO1FBS0Usd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQWM7UUFBbUI7Ozs7O1FBQy9DLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFhO1FBQWtCOzs7OztRQUM3Qyx3QkFBQyxVQUFEO1NBQVEsT0FBTTttQkFBbUI7UUFBd0I7Ozs7O1FBQ3pELHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFXO1FBQWdCOzs7OztRQUN6Qyx3QkFBQyxVQUFEO1NBQVEsT0FBTTttQkFBYztRQUFtQjs7Ozs7UUFDL0Msd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQWdCO1FBQXFCOzs7OztPQUM3Qzs7Ozs7Y0FDTDs7OztnQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQW1FLGdCQUNyRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBTzs7OztlQUM5Qzs7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxLQUFJO09BQ0osTUFBSztPQUNMO09BQ0EsT0FBTztPQUNQLFdBQVUsTUFBSyxTQUFTLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztPQUM5QyxXQUFVO01BQ1g7Ozs7Y0FDRTs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0Q7TUFFNUQ7Ozs7Z0JBQ1Asd0JBQUMsVUFBRDtPQUNFLE9BQU87T0FDUCxXQUFVLE1BQUssZUFBZSxFQUFFLE9BQU8sS0FBb0I7T0FDM0QsV0FBVTtpQkFIWjtRQUtFLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFXO1FBQWdCOzs7OztRQUN6Qyx3QkFBQyxVQUFEO1NBQVEsT0FBTTttQkFBWTtRQUFpQjs7Ozs7UUFDM0Msd0JBQUMsVUFBRDtTQUFRLE9BQU07bUJBQWU7UUFBb0I7Ozs7O09BQzNDOzs7OztjQUNMOzs7O2dCQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBa0Q7TUFFNUQ7Ozs7Z0JBQ1Asd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxLQUFJO09BQ0osT0FBTztPQUNQLFdBQVUsTUFBSyxjQUFjLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztPQUNuRCxXQUFVO01BQ1g7Ozs7Y0FDRTs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWtEO01BRTVEOzs7OztNQUdQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdDO09BQXdDOzs7O2lCQUNoRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixxQkFBcUIsS0FBSSxXQUN4Qix3QkFBQyxVQUFEO1NBRUUsTUFBSztTQUNMLGVBQWUsWUFBWSxPQUFPLEdBQUc7U0FDckMsV0FBVyxvRkFDVCxhQUFhLE9BQU8sTUFDaEIsOENBQ0E7bUJBUFIsQ0FVRSx3QkFBQyxPQUFEO1VBQUssS0FBSyxPQUFPO1VBQUssS0FBSyxPQUFPO1VBQU8sV0FBVTtTQUE4Qjs7OzttQkFDaEYsYUFBYSxPQUFPLE9BQ25CLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNiLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7O1NBQ3pCOzs7O2lCQUVEO1dBZkQsT0FBTzs7OztlQWVOLENBQ1Q7T0FDRTs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLHFFQUFzRTs7OztpQkFDM0Ysd0JBQUMsU0FBRDtRQUNFLE1BQUs7UUFDTCxhQUFZO1FBQ1osT0FBTztRQUNQLFdBQVUsTUFBSyxZQUFZLEVBQUUsT0FBTyxLQUFLO1FBQ3pDLFdBQVU7T0FDWDs7OztlQUNFOzs7Ozs7S0FDRjs7Ozs7S0FHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtNQUFPLFdBQVU7Z0JBQWtEO0tBRTVEOzs7O2VBQ1Asd0JBQUMsWUFBRDtNQUNFLE1BQU07TUFDTixhQUFZO01BQ1osT0FBTztNQUNQLFdBQVUsTUFBSyxlQUFlLEVBQUUsT0FBTyxLQUFLO01BQzVDLFdBQVU7S0FDWDs7OzthQUNFOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVTtpQkFDWDtNQUVPOzs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtpQkFFVCxVQUFVLGlCQUFpQjtNQUN0Qjs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7V0FFSDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2VsbGVyUHJvZHVjdE1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFByb2R1Y3QsIFN0b2NrU3RhdHVzIH0gZnJvbSAnLi4vLi4vdHlwZXMvc3RvcmUnO1xuaW1wb3J0IHsgUFJFU0VUX0lNQUdFX09QVElPTlMgfSBmcm9tICcuLi8uLi9kYXRhL2RlZmF1bHRQcm9kdWN0cyc7XG5pbXBvcnQgeyBYLCBJbWFnZSBhcyBJbWFnZUljb24sIENoZWNrIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIFNlbGxlclByb2R1Y3RNb2RhbFByb3BzIHtcbiAgcHJvZHVjdDogUHJvZHVjdCB8IG51bGw7IC8vIG51bGwgbWVhbnMgQWRkIE5ld1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uU2F2ZTogKHByb2R1Y3REYXRhOiBPbWl0PFByb2R1Y3QsICdpZCcgfCAnY3JlYXRlZEF0JyB8ICdza3UnPiAmIHsgaWQ/OiBzdHJpbmcgfSkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFNlbGxlclByb2R1Y3RNb2RhbDogUmVhY3QuRkM8U2VsbGVyUHJvZHVjdE1vZGFsUHJvcHM+ID0gKHtcbiAgcHJvZHVjdCxcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBvblNhdmVcbn0pID0+IHtcbiAgY29uc3QgW25hbWUsIHNldE5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3ByaWNlLCBzZXRQcmljZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbc3RvY2tTdGF0dXMsIHNldFN0b2NrU3RhdHVzXSA9IHVzZVN0YXRlPFN0b2NrU3RhdHVzPignaW5fc3RvY2snKTtcbiAgY29uc3QgW3N0b2NrQ291bnQsIHNldFN0b2NrQ291bnRdID0gdXNlU3RhdGU8bnVtYmVyPigxMCk7XG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoJ0VsZWN0cm9uaWNzJyk7XG4gIGNvbnN0IFtpbWFnZVVybCwgc2V0SW1hZ2VVcmxdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbZXJyb3JNc2csIHNldEVycm9yTXNnXSA9IHVzZVN0YXRlKCcnKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcm9kdWN0KSB7XG4gICAgICBzZXROYW1lKHByb2R1Y3QubmFtZSk7XG4gICAgICBzZXREZXNjcmlwdGlvbihwcm9kdWN0LmRlc2NyaXB0aW9uKTtcbiAgICAgIHNldFByaWNlKHByb2R1Y3QucHJpY2UpO1xuICAgICAgc2V0U3RvY2tTdGF0dXMocHJvZHVjdC5zdG9ja1N0YXR1cyk7XG4gICAgICBzZXRTdG9ja0NvdW50KHByb2R1Y3Quc3RvY2tDb3VudCk7XG4gICAgICBzZXRDYXRlZ29yeShwcm9kdWN0LmNhdGVnb3J5KTtcbiAgICAgIHNldEltYWdlVXJsKHByb2R1Y3QuaW1hZ2VVcmwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXROYW1lKCcnKTtcbiAgICAgIHNldERlc2NyaXB0aW9uKCcnKTtcbiAgICAgIHNldFByaWNlKDUwMDApO1xuICAgICAgc2V0U3RvY2tTdGF0dXMoJ2luX3N0b2NrJyk7XG4gICAgICBzZXRTdG9ja0NvdW50KDE1KTtcbiAgICAgIHNldENhdGVnb3J5KCdFbGVjdHJvbmljcycpO1xuICAgICAgc2V0SW1hZ2VVcmwoUFJFU0VUX0lNQUdFX09QVElPTlNbMF0udXJsKTtcbiAgICB9XG4gICAgc2V0RXJyb3JNc2coJycpO1xuICB9LCBbcHJvZHVjdCwgaXNPcGVuXSk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuYW1lLnRyaW0oKSkge1xuICAgICAgc2V0RXJyb3JNc2coJ1Byb2R1Y3QgbmFtZSBpcyByZXF1aXJlZCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAocHJpY2UgPD0gMCkge1xuICAgICAgc2V0RXJyb3JNc2coJ1ByaWNlIG11c3QgYmUgZ3JlYXRlciB0aGFuIDAnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFpbWFnZVVybC50cmltKCkpIHtcbiAgICAgIHNldEVycm9yTXNnKCdQcm9kdWN0IGltYWdlIGlzIHJlcXVpcmVkJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgb25TYXZlKHtcbiAgICAgIGlkOiBwcm9kdWN0Py5pZCxcbiAgICAgIG5hbWU6IG5hbWUudHJpbSgpLFxuICAgICAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uLnRyaW0oKSxcbiAgICAgIHByaWNlOiBOdW1iZXIocHJpY2UpLFxuICAgICAgc3RvY2tTdGF0dXMsXG4gICAgICBzdG9ja0NvdW50OiBOdW1iZXIoc3RvY2tDb3VudCksXG4gICAgICBjYXRlZ29yeSxcbiAgICAgIGltYWdlVXJsOiBpbWFnZVVybC50cmltKClcbiAgICB9KTtcbiAgICBvbkNsb3NlKCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctc2xhdGUtOTUwLzYwIGJhY2tkcm9wLWJsdXIteHMgb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyBiZy13aGl0ZSByb3VuZGVkLXhsIHNoYWRvdy0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgb3ZlcmZsb3ctaGlkZGVuIG15LTggYW5pbWF0ZS1pbiBmYWRlLWluIGR1cmF0aW9uLTIwMFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYmctc2xhdGUtNTBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZm9udC1kaXNwbGF5XCI+XG4gICAgICAgICAgICAgIHtwcm9kdWN0ID8gJ0VkaXQgUHJvZHVjdCBEZXRhaWxzJyA6ICdBZGQgTmV3IFByb2R1Y3QgdG8gU3RvcmUnfVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAge3Byb2R1Y3QgPyAnVXBkYXRlIHByb2R1Y3QgcHJpY2luZywgc3RvY2sgc3RhdHVzLCBvciBkZXNjcmlwdGlvbicgOiAnRW50ZXIgcHJvZHVjdCBpbmZvcm1hdGlvbiBhbmQgc3RvY2sgYXZhaWxhYmlsaXR5J31cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1zbGF0ZS03MDAgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS0yMDAvNTAgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9ybSAqL31cbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0gY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgIHtlcnJvck1zZyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IHRleHQteHMgdGV4dC1yb3NlLTcwMCBiZy1yb3NlLTUwIGJvcmRlciBib3JkZXItcm9zZS0yMDAgcm91bmRlZFwiPlxuICAgICAgICAgICAgICB7ZXJyb3JNc2d9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFByb2R1Y3QgTmFtZSAqL31cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIFByb2R1Y3QgTmFtZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXJvc2UtNTAwXCI+Kjwvc3Bhbj5cbiAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gV2lyZWxlc3MgTm9pc2UgQ2FuY2VsaW5nIEhlYWRwaG9uZXNcIlxuICAgICAgICAgICAgICB2YWx1ZT17bmFtZX1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0TmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2F0ZWdvcnkgJiBQcmljZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgIENhdGVnb3J5IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtcm9zZS01MDBcIj4qPC9zcGFuPlxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8c2VsZWN0XG4gICAgICAgICAgICAgICAgdmFsdWU9e2NhdGVnb3J5fVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldENhdGVnb3J5KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSBiZy13aGl0ZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiRWxlY3Ryb25pY3NcIj5FbGVjdHJvbmljczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJBdWRpbyBHZWFyXCI+QXVkaW8gR2Vhcjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJMZWF0aGVyICYgVHJhdmVsXCI+TGVhdGhlciAmIFRyYXZlbDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJGb290d2VhclwiPkZvb3R3ZWFyPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkFjY2Vzc29yaWVzXCI+QWNjZXNzb3JpZXM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVwiSG9tZSAmIExpdmluZ1wiPkhvbWUgJiBMaXZpbmc8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgUHJpY2UgKFBLUikgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTUwMFwiPio8L3NwYW4+XG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgIG1pbj1cIjEwMFwiXG4gICAgICAgICAgICAgICAgc3RlcD1cIjUwXCJcbiAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgIHZhbHVlPXtwcmljZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRQcmljZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb250LW1vbm8gdGFidWxhci1udW1zXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFN0b2NrIFN0YXR1cyAmIFN0b2NrIENvdW50ICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgU3RvY2sgU3RhdHVzXG4gICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICB2YWx1ZT17c3RvY2tTdGF0dXN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U3RvY2tTdGF0dXMoZS50YXJnZXQudmFsdWUgYXMgU3RvY2tTdGF0dXMpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0zIHB5LTIgdGV4dC14cyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIGZvY3VzOmJvcmRlci1zbGF0ZS04MDAgZm9jdXM6b3V0bGluZS1ub25lIGJnLXdoaXRlXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJpbl9zdG9ja1wiPkluIFN0b2NrPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImxvd19zdG9ja1wiPkxvdyBTdG9jazwvb3B0aW9uPlxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJvdXRfb2Zfc3RvY2tcIj5PdXQgb2YgU3RvY2s8L29wdGlvbj5cbiAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgU3RvY2sgVW5pdHNcbiAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3N0b2NrQ291bnR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0U3RvY2tDb3VudChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHgtMyBweS0yIHRleHQteHMgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBmb2N1czpib3JkZXItc2xhdGUtODAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb250LW1vbm8gdGFidWxhci1udW1zXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEltYWdlIFNlbGVjdGlvbiB3aXRoIFByZXNldHMgKi99XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICBQcm9kdWN0IEltYWdlXG4gICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICB7LyogUXVpY2sgUHJlc2V0cyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+UXVpY2sgU2VsZWN0IFN0dWRpbyBQaG90byBQcmVzZXRzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAge1BSRVNFVF9JTUFHRV9PUFRJT05TLm1hcChwcmVzZXQgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3ByZXNldC51cmx9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJbWFnZVVybChwcmVzZXQudXJsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgYXNwZWN0LTQvMyByb3VuZGVkIGJvcmRlciBvdmVyZmxvdy1oaWRkZW4gdHJhbnNpdGlvbi1hbGwgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICBpbWFnZVVybCA9PT0gcHJlc2V0LnVybFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLXNsYXRlLTkwMCByaW5nLTIgcmluZy1zbGF0ZS05MDAvMjAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAgb3BhY2l0eS03MCBob3ZlcjpvcGFjaXR5LTEwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtwcmVzZXQudXJsfSBhbHQ9e3ByZXNldC5sYWJlbH0gY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICB7aW1hZ2VVcmwgPT09IHByZXNldC51cmwgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy1zbGF0ZS05MDAvNDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPEltYWdlSWNvbiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMyB0b3AtMi41IHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJPciBwYXN0ZSBkaXJlY3QgSW1hZ2UgVVJMLi4uXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17aW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9e2UgPT4gc2V0SW1hZ2VVcmwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC05IHByLTMgcHktMiB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9jdXM6Ym9yZGVyLXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9udC1tb25vIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIERlc2NyaXB0aW9uICovfVxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgRGVzY3JpcHRpb24gLyBTcGVjaWZpY2F0aW9uc1xuICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkhpZ2hsaWdodCBwcm9kdWN0IGZlYXR1cmVzLCBtYXRlcmlhbHMsIHdhcnJhbnR5LCBvciBwYWNrYWdpbmcgY29udGVudHMuLi5cIlxuICAgICAgICAgICAgICB2YWx1ZT17ZGVzY3JpcHRpb259XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTMgcHktMiB0ZXh0LXhzIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQgZm9jdXM6Ym9yZGVyLXNsYXRlLTgwMCBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBCdXR0b25zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMjAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTEwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgc2hhZG93LXhzXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge3Byb2R1Y3QgPyAnU2F2ZSBDaGFuZ2VzJyA6ICdQdWJsaXNoIFByb2R1Y3QnfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZm9ybT5cblxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19