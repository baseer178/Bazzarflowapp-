const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { ShoppingBag, LayoutDashboard, Store, Layers, Github } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/common/Header.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const Header = () => {
	const { currentView, setCurrentView, cart, orders, setIsCartOpen, setIsExportOpen } = useStore();
	const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
	const pendingOrdersCount = orders.filter((o) => o.status === "pending").length;
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 shrink-0",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setCurrentView("buyer"),
						className: "text-left group flex items-center gap-2 cursor-pointer focus:outline-none",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-8 h-8 rounded bg-slate-900 text-white flex items-center justify-center font-bold text-sm tracking-wider",
							children: "BF"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xl font-bold tracking-tight text-slate-900 font-display whitespace-nowrap shrink-0",
							children: "BazaarFlow"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 17,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("nav", {
					className: "flex items-center gap-6 text-sm font-medium text-slate-600",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setCurrentView("buyer"),
							className: `cursor-pointer whitespace-nowrap shrink-0 transition-colors py-1 ${currentView === "buyer" ? "text-slate-900 font-semibold border-b-2 border-slate-900" : "hover:text-slate-900"}`,
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Store, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 41,
									columnNumber: 15
								}, this), "Storefront"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setCurrentView("seller"),
							className: `cursor-pointer whitespace-nowrap shrink-0 transition-colors py-1 relative ${currentView === "seller" ? "text-slate-900 font-semibold border-b-2 border-slate-900" : "hover:text-slate-900"}`,
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ _jsxDEV(LayoutDashboard, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 55,
										columnNumber: 15
									}, this),
									"Seller Hub",
									pendingOrdersCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
										className: "ml-1 text-[11px] font-mono tabular-nums px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded",
										children: pendingOrdersCount
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 58,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setCurrentView("architecture"),
							className: `cursor-pointer whitespace-nowrap shrink-0 transition-colors py-1 ${currentView === "architecture" ? "text-slate-900 font-semibold border-b-2 border-slate-900" : "hover:text-slate-900"}`,
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 15
								}, this), "Architecture & Docs"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 65,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5 shrink-0",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsExportOpen(true),
						className: "flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer",
						title: "Download ZIP or Export to GitHub",
						children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline",
							children: "Export / GitHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsCartOpen(true),
						className: "flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 rounded hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer",
						"aria-label": "View Shopping Cart",
						children: [
							/* @__PURE__ */ _jsxDEV(ShoppingBag, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 96,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Bag" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono tabular-nums bg-slate-800 px-1.5 py-0.5 rounded text-[11px]",
								children: totalCartCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsYUFBYSxpQkFBaUIsT0FBTyxRQUFRLGNBQWM7OztBQUVwRSxPQUFPLE1BQU0sZUFBeUI7Q0FDcEMsTUFBTSxFQUFFLGFBQWEsZ0JBQWdCLE1BQU0sUUFBUSxlQUFlLG9CQUFvQixTQUFTO0NBRS9GLE1BQU0saUJBQWlCLEtBQUssUUFBUSxLQUFLLFNBQVMsTUFBTSxLQUFLLFVBQVUsQ0FBQztDQUN4RSxNQUFNLHFCQUFxQixPQUFPLFFBQU8sTUFBSyxFQUFFLFdBQVcsU0FBUyxDQUFDLENBQUM7Q0FFdEUsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUNoQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxVQUFEO01BQ0UsZUFBZSxlQUFlLE9BQU87TUFDckMsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUE0RztNQUV0SDs7OztnQkFDTCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMEY7TUFFcEc7Ozs7Y0FDQTs7Ozs7O0lBQ0w7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGVBQWUsT0FBTztPQUNyQyxXQUFXLG9FQUNULGdCQUFnQixVQUNaLDZEQUNBO2lCQUdOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7a0JBQUMsWUFFekI7Ozs7OztNQUNBOzs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGVBQWUsUUFBUTtPQUN0QyxXQUFXLDZFQUNULGdCQUFnQixXQUNaLDZEQUNBO2lCQUdOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUNFLHdCQUFDLGlCQUFELEVBQWlCLFdBQVUsVUFBVzs7Ozs7U0FBQztTQUV0QyxxQkFBcUIsS0FDcEIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2I7U0FDRzs7Ozs7UUFFSjs7Ozs7O01BQ0E7Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsZUFBZSxjQUFjO09BQzVDLFdBQVcsb0VBQ1QsZ0JBQWdCLGlCQUNaLDZEQUNBO2lCQUdOLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7a0JBQUMscUJBRTFCOzs7Ozs7TUFDQTs7Ozs7S0FDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGdCQUFnQixJQUFJO01BQ25DLFdBQVU7TUFDVixPQUFNO2dCQUhSLENBS0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OztnQkFDakMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1CO01BQXFCOzs7O2NBQ2xEOzs7OztlQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGNBQWMsSUFBSTtNQUNqQyxXQUFVO01BQ1YsY0FBVztnQkFIYjtPQUtFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O09BQ2xDLHdCQUFDLFFBQUQsWUFBTSxNQUFTOzs7OztPQUNmLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiO09BQ0c7Ozs7O01BQ0E7Ozs7O2FBQ0w7Ozs7OztHQUVGOzs7Ozs7Q0FDQzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gJy4uLy4uL2NvbnRleHQvU3RvcmVDb250ZXh0JztcbmltcG9ydCB7IFNob3BwaW5nQmFnLCBMYXlvdXREYXNoYm9hcmQsIFN0b3JlLCBMYXllcnMsIEdpdGh1YiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBIZWFkZXI6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IGN1cnJlbnRWaWV3LCBzZXRDdXJyZW50VmlldywgY2FydCwgb3JkZXJzLCBzZXRJc0NhcnRPcGVuLCBzZXRJc0V4cG9ydE9wZW4gfSA9IHVzZVN0b3JlKCk7XG5cbiAgY29uc3QgdG90YWxDYXJ0Q291bnQgPSBjYXJ0LnJlZHVjZSgoc3VtLCBpdGVtKSA9PiBzdW0gKyBpdGVtLnF1YW50aXR5LCAwKTtcbiAgY29uc3QgcGVuZGluZ09yZGVyc0NvdW50ID0gb3JkZXJzLmZpbHRlcihvID0+IG8uc3RhdHVzID09PSAncGVuZGluZycpLmxlbmd0aDtcblxuICByZXR1cm4gKFxuICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic3RpY2t5IHRvcC0wIHotNDAgYmctd2hpdGUvOTUgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04IGgtMTYgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogWm9uZSAxOiBTaW5nbGUgQnJhbmQgV29yZG1hcmsgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDdXJyZW50VmlldygnYnV5ZXInKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtbGVmdCBncm91cCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciBmb2N1czpvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkIGJnLXNsYXRlLTkwMCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZvbnQtYm9sZCB0ZXh0LXNtIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIEJGXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheSB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICBCYXphYXJGbG93XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBab25lIDI6IE5hdmlnYXRpb24gTGlua3MgKFNpbmdsZS1saW5lLCBxdWlldCBob3ZlciwgMy00IGxpbmtzKSAqL31cbiAgICAgICAgPG5hdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNiB0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ2J1eWVyJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMCB0cmFuc2l0aW9uLWNvbG9ycyBweS0xICR7XG4gICAgICAgICAgICAgIGN1cnJlbnRWaWV3ID09PSAnYnV5ZXInXG4gICAgICAgICAgICAgICAgPyAndGV4dC1zbGF0ZS05MDAgZm9udC1zZW1pYm9sZCBib3JkZXItYi0yIGJvcmRlci1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgICAgOiAnaG92ZXI6dGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxTdG9yZSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgU3RvcmVmcm9udFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ3NlbGxlcicpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTAgdHJhbnNpdGlvbi1jb2xvcnMgcHktMSByZWxhdGl2ZSAke1xuICAgICAgICAgICAgICBjdXJyZW50VmlldyA9PT0gJ3NlbGxlcidcbiAgICAgICAgICAgICAgICA/ICd0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTkwMCdcbiAgICAgICAgICAgICAgICA6ICdob3Zlcjp0ZXh0LXNsYXRlLTkwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPExheW91dERhc2hib2FyZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgU2VsbGVyIEh1YlxuICAgICAgICAgICAgICB7cGVuZGluZ09yZGVyc0NvdW50ID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWwtMSB0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGFidWxhci1udW1zIHB4LTEuNSBweS0wLjIgYmctYW1iZXItMTAwIHRleHQtYW1iZXItODAwIHJvdW5kZWRcIj5cbiAgICAgICAgICAgICAgICAgIHtwZW5kaW5nT3JkZXJzQ291bnR9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ2FyY2hpdGVjdHVyZScpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgY3Vyc29yLXBvaW50ZXIgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTAgdHJhbnNpdGlvbi1jb2xvcnMgcHktMSAke1xuICAgICAgICAgICAgICBjdXJyZW50VmlldyA9PT0gJ2FyY2hpdGVjdHVyZSdcbiAgICAgICAgICAgICAgICA/ICd0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkIGJvcmRlci1iLTIgYm9yZGVyLXNsYXRlLTkwMCdcbiAgICAgICAgICAgICAgICA6ICdob3Zlcjp0ZXh0LXNsYXRlLTkwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgQXJjaGl0ZWN0dXJlICYgRG9jc1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L25hdj5cblxuICAgICAgICB7LyogWm9uZSAzOiBBY3Rpb25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cG9ydE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgWklQIG9yIEV4cG9ydCB0byBHaXRIdWJcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxHaXRodWIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZVwiPkV4cG9ydCAvIEdpdEh1Yjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzQ2FydE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zLjUgcHktMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZSBiZy1zbGF0ZS05MDAgcm91bmRlZCBob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlZpZXcgU2hvcHBpbmcgQ2FydFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+QmFnPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtcyBiZy1zbGF0ZS04MDAgcHgtMS41IHB5LTAuNSByb3VuZGVkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgIHt0b3RhbENhcnRDb3VudH1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufTtcbiJdfQ==