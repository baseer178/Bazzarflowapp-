const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { BellRing, ArrowRight, X, MapPin } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/common/OrderNotificationToast.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const OrderNotificationToast = () => {
	const { activeNotification, dismissNotification, setCurrentView } = useStore();
	if (!activeNotification) return null;
	const { order } = activeNotification;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-5 right-5 z-50 max-w-md w-full bg-slate-900 text-white rounded-lg shadow-xl border border-slate-800 p-4 animate-in fade-in slide-in-from-bottom-4 duration-300",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-8 h-8 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0",
						children: /* @__PURE__ */ _jsxDEV(BellRing, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 17,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 16,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-xs font-semibold text-amber-400 uppercase tracking-wider",
						children: "New Order Received"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-sm font-bold text-white",
						children: [
							"Order ",
							order.orderNumber,
							" · PKR ",
							order.totalAmount.toLocaleString()
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 23,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: dismissNotification,
					className: "text-slate-400 hover:text-white transition-colors cursor-pointer",
					"aria-label": "Dismiss notification",
					children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-2.5 pt-2 border-t border-slate-800 text-xs text-slate-300 space-y-1",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400",
						children: "Customer:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-medium text-white",
						children: [
							order.customer.fullName,
							" (",
							order.customer.phone,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 shrink-0",
						children: "Delivery:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "truncate flex items-center gap-1 text-slate-300",
						children: [
							/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3 h-3 text-slate-400 shrink-0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this),
							order.customer.city,
							" · ",
							order.customer.deliveryAddress
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "mt-3 flex items-center justify-end gap-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: dismissNotification,
					className: "px-3 py-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer",
					children: "Dismiss"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						dismissNotification();
						setCurrentView("seller");
					},
					className: "inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-medium text-xs rounded transition-colors cursor-pointer",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Open Seller Hub" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-3.5 h-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsVUFBVSxZQUFZLEdBQUcsY0FBYzs7O0FBRWhELE9BQU8sTUFBTSwrQkFBeUM7Q0FDcEQsTUFBTSxFQUFFLG9CQUFvQixxQkFBcUIsbUJBQW1CLFNBQVM7Q0FFN0UsSUFBSSxDQUFDLG9CQUFvQixPQUFPO0NBRWhDLE1BQU0sRUFBRSxVQUFVO0NBRWxCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7S0FDNUI7Ozs7ZUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWdFO0tBRTFFOzs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBOEM7T0FDckMsTUFBTTtPQUFZO09BQVEsTUFBTSxZQUFZLGVBQWU7TUFDL0Q7Ozs7O2FBQ0Y7Ozs7YUFDRjs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQ0UsU0FBUztLQUNULFdBQVU7S0FDVixjQUFXO2VBRVgsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7SUFDbEI7Ozs7WUFDTDs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaUI7S0FBZTs7OztlQUNoRCx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEI7T0FBMEMsTUFBTSxTQUFTO09BQVM7T0FBRyxNQUFNLFNBQVM7T0FBTTtNQUFPOzs7OzthQUM5Rjs7Ozs7Y0FDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTBCO0tBQWU7Ozs7ZUFDekQsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsa0NBQW1DOzs7OztPQUNwRCxNQUFNLFNBQVM7T0FBSztPQUFJLE1BQU0sU0FBUztNQUNwQzs7Ozs7YUFDSDs7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVTtlQUNYO0lBRU87Ozs7Y0FDUix3QkFBQyxVQUFEO0tBQ0UsZUFBZTtNQUNiLG9CQUFvQjtNQUNwQixlQUFlLFFBQVE7S0FDekI7S0FDQSxXQUFVO2VBTFosQ0FPRSx3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O2VBQzNCLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7YUFDL0I7Ozs7O1lBQ0w7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJPcmRlck5vdGlmaWNhdGlvblRvYXN0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RvcmUgfSBmcm9tICcuLi8uLi9jb250ZXh0L1N0b3JlQ29udGV4dCc7XG5pbXBvcnQgeyBCZWxsUmluZywgQXJyb3dSaWdodCwgWCwgTWFwUGluIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuZXhwb3J0IGNvbnN0IE9yZGVyTm90aWZpY2F0aW9uVG9hc3Q6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IGFjdGl2ZU5vdGlmaWNhdGlvbiwgZGlzbWlzc05vdGlmaWNhdGlvbiwgc2V0Q3VycmVudFZpZXcgfSA9IHVzZVN0b3JlKCk7XG5cbiAgaWYgKCFhY3RpdmVOb3RpZmljYXRpb24pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IHsgb3JkZXIgfSA9IGFjdGl2ZU5vdGlmaWNhdGlvbjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgYm90dG9tLTUgcmlnaHQtNSB6LTUwIG1heC13LW1kIHctZnVsbCBiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tYm90dG9tLTQgZHVyYXRpb24tMzAwXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZCBiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hyaW5rLTBcIj5cbiAgICAgICAgICAgIDxCZWxsUmluZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1hbWJlci00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgIE5ldyBPcmRlciBSZWNlaXZlZFxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgT3JkZXIge29yZGVyLm9yZGVyTnVtYmVyfSDCtyBQS1Ige29yZGVyLnRvdGFsQW1vdW50LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtkaXNtaXNzTm90aWZpY2F0aW9ufVxuICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJEaXNtaXNzIG5vdGlmaWNhdGlvblwiXG4gICAgICAgID5cbiAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yLjUgcHQtMiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIHRleHQteHMgdGV4dC1zbGF0ZS0zMDAgc3BhY2UteS0xXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj5DdXN0b21lcjo8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC13aGl0ZVwiPntvcmRlci5jdXN0b21lci5mdWxsTmFtZX0gKHtvcmRlci5jdXN0b21lci5waG9uZX0pPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMFwiPkRlbGl2ZXJ5Ojwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtc2xhdGUtNDAwIHNocmluay0wXCIgLz5cbiAgICAgICAgICAgIHtvcmRlci5jdXN0b21lci5jaXR5fSDCtyB7b3JkZXIuY3VzdG9tZXIuZGVsaXZlcnlBZGRyZXNzfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtkaXNtaXNzTm90aWZpY2F0aW9ufVxuICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IHRleHQteHMgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgID5cbiAgICAgICAgICBEaXNtaXNzXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgZGlzbWlzc05vdGlmaWNhdGlvbigpO1xuICAgICAgICAgICAgc2V0Q3VycmVudFZpZXcoJ3NlbGxlcicpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgYmctYW1iZXItNTAwIGhvdmVyOmJnLWFtYmVyLTQwMCB0ZXh0LXNsYXRlLTk1MCBmb250LW1lZGl1bSB0ZXh0LXhzIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4+T3BlbiBTZWxsZXIgSHViPC9zcGFuPlxuICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=