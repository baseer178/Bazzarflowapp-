const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const JSZip = __vite__cjsImport1_jszip;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import __vite__cjsImport1_jszip from "/node_modules/.vite/deps/jszip.js?v=8a8f6294";
import { Download, Github, Check, Copy, X, Terminal, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/common/ExportModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const ExportModal = ({ isOpen, onClose }) => {
	const [isZipping, setIsZipping] = useState(false);
	const [downloadSuccess, setDownloadSuccess] = useState(false);
	const [copiedKey, setCopiedKey] = useState(null);
	if (!isOpen) return null;
	const handleCopy = (key, text) => {
		navigator.clipboard.writeText(text);
		setCopiedKey(key);
		setTimeout(() => setCopiedKey(null), 2e3);
	};
	const handleDownloadZip = async () => {
		setIsZipping(true);
		setDownloadSuccess(false);
		try {
			const zip = new JSZip();
			// List of project files to fetch & bundle
			const filePaths = [
				"/package.json",
				"/tsconfig.json",
				"/vite.config.ts",
				"/index.html",
				"/metadata.json",
				"/README.md",
				"/.gitignore",
				"/.env.example",
				"/src/main.tsx",
				"/src/App.tsx",
				"/src/index.css",
				"/src/types/store.ts",
				"/src/data/defaultProducts.ts",
				"/src/context/StoreContext.tsx",
				"/src/components/common/Header.tsx",
				"/src/components/common/OrderNotificationToast.tsx",
				"/src/components/common/ExportModal.tsx",
				"/src/components/buyer/ProductCard.tsx",
				"/src/components/buyer/QuickOrderModal.tsx",
				"/src/components/buyer/CartDrawer.tsx",
				"/src/components/buyer/BuyerStorefront.tsx",
				"/src/components/seller/SellerDashboard.tsx",
				"/src/components/seller/SellerProductModal.tsx",
				"/src/components/seller/OrderDetailsModal.tsx",
				"/src/components/architecture/ArchitectureView.tsx"
			];
			// Image assets
			const imagePaths = [
				"/src/assets/images/product_smartwatch_minimal_1792257510116.jpg",
				"/src/assets/images/product_leather_bag_brown_1792257532543.jpg",
				"/src/assets/images/product_audio_headphones_1792257552187.jpg",
				"/src/assets/images/product_sneakers_lifestyle_1792257567253.jpg"
			];
			// Fetch and add text/code files
			await Promise.all(filePaths.map(async (path) => {
				try {
					const res = await fetch(path);
					if (res.ok) {
						const text = await res.text();
						const cleanPath = path.startsWith("/") ? path.slice(1) : path;
						zip.file(cleanPath, text);
					}
				} catch (e) {
					console.warn("Failed to bundle file in zip:", path, e);
				}
			}));
			// Fetch and add image binary files
			await Promise.all(imagePaths.map(async (path) => {
				try {
					const res = await fetch(path);
					if (res.ok) {
						const blob = await res.blob();
						const cleanPath = path.startsWith("/") ? path.slice(1) : path;
						zip.file(cleanPath, blob);
					}
				} catch (e) {
					console.warn("Failed to bundle image in zip:", path, e);
				}
			}));
			// Generate the ZIP blob
			const zipContent = await zip.generateAsync({ type: "blob" });
			// Trigger instant browser download
			const downloadUrl = URL.createObjectURL(zipContent);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.download = "bazaarflow-shop-complete.zip";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(downloadUrl);
			setDownloadSuccess(true);
		} catch (err) {
			console.error("Error generating zip:", err);
		} finally {
			setIsZipping(false);
		}
	};
	const gitCliCommands = `# Step 1: Extract downloaded bazaarflow-shop-complete.zip & open terminal
cd bazaarflow-shop-complete

# Step 2: Initialize Git repository
git init
git add .
git commit -m "Initial commit of BazaarFlow e-commerce platform"

# Step 3: Set main branch & link your GitHub repository
git branch -M main
git remote add origin https://github.com/<YOUR-GITHUB-USERNAME>/<YOUR-REPO-NAME>.git

# Step 4: Push to GitHub!
git push -u origin main`;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-8 h-8 rounded bg-slate-900 text-white flex items-center justify-center",
							children: /* @__PURE__ */ _jsxDEV(Github, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-slate-900 font-display",
							children: "Download Code & Export to GitHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 156,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500",
							children: "1-click full source code download and step-by-step GitHub publishing instructions"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 155,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/50 transition-colors cursor-pointer",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 150,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-6 space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start justify-between gap-4",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-amber-700 uppercase tracking-wider block",
										children: "Method 1 (Instant · Single Click)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 180,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-sm font-bold text-slate-900",
										children: "Download Complete Project ZIP Archive"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-600 mt-1",
										children: "Bundles all code (`src/`, `components/`, Tailwind setup, types, seed data, and images) into a single ready-to-run `.zip` file."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 186,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 179,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleDownloadZip,
									disabled: isZipping,
									className: "inline-flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white text-xs font-semibold rounded-lg shadow-sm transition-all cursor-pointer whitespace-nowrap shrink-0",
									children: isZipping ? /* @__PURE__ */ _jsxDEV("span", { children: "Generating ZIP..." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 19
									}, this) : downloadSuccess ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 200,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Downloaded!" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 201,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 199,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 205,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download Project ZIP" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 206,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 204,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 178,
								columnNumber: 13
							}, this), downloadSuccess && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-2.5 bg-emerald-50 border border-emerald-200 rounded text-xs text-emerald-800 flex items-center gap-2 animate-in fade-in",
								children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-600 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 214,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "bazaarflow-shop-complete.zip" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 23
								}, this), " has been downloaded to your computer!"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 215,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 213,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider block",
									children: "Method 2 (Publish to GitHub)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 224,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("h3", {
									className: "text-sm font-bold text-slate-900",
									children: "Git Commands to Push to your GitHub Account"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleCopy("git_cmds", gitCliCommands),
									className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors cursor-pointer",
									children: [copiedKey === "git_cmds" ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 236,
										columnNumber: 45
									}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 236,
										columnNumber: 98
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedKey === "git_cmds" ? "Copied Commands" : "Copy Commands" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 232,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 text-slate-200 rounded-lg p-3.5 font-mono text-xs overflow-x-auto relative",
								children: /* @__PURE__ */ _jsxDEV("pre", {
									className: "leading-relaxed",
									children: gitCliCommands
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 242,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 241,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 border border-slate-200 rounded-lg bg-white space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-slate-900 font-bold",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 249,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Alternative: AI Studio Top-Right Export Menu" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 250,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-600 leading-relaxed",
								children: [
									"Google AI Studio ke screen ke ",
									/* @__PURE__ */ _jsxDEV("strong", { children: "top-right corner" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 45
									}, this),
									" par ",
									/* @__PURE__ */ _jsxDEV("strong", { children: "\"Export\"" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 83
									}, this),
									" ya teen dots (⋮) menu par click karein. Wahan se aap direct ",
									/* @__PURE__ */ _jsxDEV("strong", { children: "\"Create GitHub Repository\"" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 253,
										columnNumber: 169
									}, this),
									" select karke apne GitHub account ke sath 1-click connect kar sakte hain."
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 174,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-xs text-slate-500",
						children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 262,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Works with standard Node.js (v18+) & `npm install`" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded transition-colors cursor-pointer",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 260,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 147,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 146,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLFdBQVc7QUFDbEIsU0FDRSxVQUNBLFFBQ0EsT0FDQSxNQUNBLEdBRUEsVUFFQSxnQkFDSzs7O0FBT1AsT0FBTyxNQUFNLGVBQTJDLEVBQUUsUUFBUSxjQUFjO0NBQzlFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FDaEQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBRTlELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxjQUFjLEtBQWEsU0FBaUI7RUFDaEQsVUFBVSxVQUFVLFVBQVUsSUFBSTtFQUNsQyxhQUFhLEdBQUc7RUFDaEIsaUJBQWlCLGFBQWEsSUFBSSxHQUFHLEdBQUk7Q0FDM0M7Q0FFQSxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLGFBQWEsSUFBSTtFQUNqQixtQkFBbUIsS0FBSztFQUV4QixJQUFJO0dBQ0YsTUFBTSxNQUFNLElBQUksTUFBTTs7R0FHdEIsTUFBTSxZQUFZO0lBQ2hCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7O0dBR0EsTUFBTSxhQUFhO0lBQ2pCO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7O0dBR0EsTUFBTSxRQUFRLElBQ1osVUFBVSxJQUFJLE9BQU8sU0FBUztJQUM1QixJQUFJO0tBQ0YsTUFBTSxNQUFNLE1BQU0sTUFBTSxJQUFJO0tBQzVCLElBQUksSUFBSSxJQUFJO01BQ1YsTUFBTSxPQUFPLE1BQU0sSUFBSSxLQUFLO01BQzVCLE1BQU0sWUFBWSxLQUFLLFdBQVcsR0FBRyxJQUFJLEtBQUssTUFBTSxDQUFDLElBQUk7TUFDekQsSUFBSSxLQUFLLFdBQVcsSUFBSTtLQUMxQjtJQUNGLFNBQVMsR0FBRztLQUNWLFFBQVEsS0FBSyxpQ0FBaUMsTUFBTSxDQUFDO0lBQ3ZEO0dBQ0YsQ0FBQyxDQUNIOztHQUdBLE1BQU0sUUFBUSxJQUNaLFdBQVcsSUFBSSxPQUFPLFNBQVM7SUFDN0IsSUFBSTtLQUNGLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSTtLQUM1QixJQUFJLElBQUksSUFBSTtNQUNWLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztNQUM1QixNQUFNLFlBQVksS0FBSyxXQUFXLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJO01BQ3pELElBQUksS0FBSyxXQUFXLElBQUk7S0FDMUI7SUFDRixTQUFTLEdBQUc7S0FDVixRQUFRLEtBQUssa0NBQWtDLE1BQU0sQ0FBQztJQUN4RDtHQUNGLENBQUMsQ0FDSDs7R0FHQSxNQUFNLGFBQWEsTUFBTSxJQUFJLGNBQWMsRUFBRSxNQUFNLE9BQU8sQ0FBQzs7R0FHM0QsTUFBTSxjQUFjLElBQUksZ0JBQWdCLFVBQVU7R0FDbEQsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTztHQUNaLEtBQUssV0FBVztHQUNoQixTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsSUFBSSxnQkFBZ0IsV0FBVztHQUUvQixtQkFBbUIsSUFBSTtFQUN6QixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0seUJBQXlCLEdBQUc7RUFDNUMsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBRUEsTUFBTSxpQkFBaUI7Ozs7Ozs7Ozs7Ozs7O0NBZXZCLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDMUI7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFrRDtNQUU1RDs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7Y0FDQTs7OztjQUNGOzs7OztlQUVMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztLQUNsQjs7OzthQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BR0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBc0U7U0FFaEY7Ozs7O1NBQ04sd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1DO1NBRTdDOzs7OztTQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUE4QjtTQUV4Qzs7Ozs7UUFDQTs7OztrQkFFTCx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFVBQVU7U0FDVixXQUFVO21CQUVULFlBQ0Msd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztvQkFDM0Isa0JBQ0YsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsMkJBQTRCOzs7O21CQUM3Qyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7aUJBQ3ZCOzs7O29CQUVGLGdEQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7bUJBQy9CLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7aUJBQ2hDOzs7OztRQUVFOzs7O2dCQUNMOzs7OztpQkFFSixtQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLG9DQUFxQzs7OztrQkFDdEQsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSwrQkFBb0M7Ozs7a0JBQUMsd0NBQTRDOzs7O2dCQUM1Rjs7Ozs7ZUFFSjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0U7UUFFaEY7Ozs7a0JBQ04sd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQW1DO1FBRTdDOzs7O2dCQUNEOzs7O2tCQUVMLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLFdBQVcsWUFBWSxjQUFjO1NBQ3BELFdBQVU7bUJBRlosQ0FJRyxjQUFjLGFBQWEsd0JBQUMsT0FBRCxFQUFPLFdBQVUsK0JBQWdDOzs7O29CQUFJLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7bUJBQ2hILHdCQUFDLFFBQUQsWUFBTyxjQUFjLGFBQWEsb0JBQW9CLGdCQUFzQjs7OztpQkFDdEU7Ozs7O2dCQUNMOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBbUI7UUFBb0I7Ozs7O09BQ25EOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx5QkFBMEI7Ozs7a0JBQzlDLHdCQUFDLFFBQUQsWUFBTSwrQ0FBa0Q7Ozs7Z0JBQ3JEOzs7OztpQkFDTCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUE4QztTQUNkLHdCQUFDLFVBQUQsWUFBUSxtQkFBd0I7Ozs7O1NBQUM7U0FBSyx3QkFBQyxVQUFELFlBQVEsYUFBZ0I7Ozs7O1NBQUM7U0FBNkQsd0JBQUMsVUFBRCxZQUFRLCtCQUFrQzs7Ozs7U0FBQztRQUNwTTs7Ozs7ZUFDQTs7Ozs7O0tBRUY7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7Z0JBQ25DLHdCQUFDLFFBQUQsWUFBTSxxREFBd0Q7Ozs7Y0FDM0Q7Ozs7O2VBRUwsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0dBRUY7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkV4cG9ydE1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgSlNaaXAgZnJvbSAnanN6aXAnO1xuaW1wb3J0IHsgXG4gIERvd25sb2FkLCBcbiAgR2l0aHViLCBcbiAgQ2hlY2ssIFxuICBDb3B5LCBcbiAgWCwgXG4gIEZvbGRlckFyY2hpdmUsIFxuICBUZXJtaW5hbCwgXG4gIEV4dGVybmFsTGluayxcbiAgU3BhcmtsZXNcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIEV4cG9ydE1vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBFeHBvcnRNb2RhbDogUmVhY3QuRkM8RXhwb3J0TW9kYWxQcm9wcz4gPSAoeyBpc09wZW4sIG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCBbaXNaaXBwaW5nLCBzZXRJc1ppcHBpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbZG93bmxvYWRTdWNjZXNzLCBzZXREb3dubG9hZFN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY29waWVkS2V5LCBzZXRDb3BpZWRLZXldID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGhhbmRsZUNvcHkgPSAoa2V5OiBzdHJpbmcsIHRleHQ6IHN0cmluZykgPT4ge1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KHRleHQpO1xuICAgIHNldENvcGllZEtleShrZXkpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkS2V5KG51bGwpLCAyMDAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEb3dubG9hZFppcCA9IGFzeW5jICgpID0+IHtcbiAgICBzZXRJc1ppcHBpbmcodHJ1ZSk7XG4gICAgc2V0RG93bmxvYWRTdWNjZXNzKGZhbHNlKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcblxuICAgICAgLy8gTGlzdCBvZiBwcm9qZWN0IGZpbGVzIHRvIGZldGNoICYgYnVuZGxlXG4gICAgICBjb25zdCBmaWxlUGF0aHMgPSBbXG4gICAgICAgICcvcGFja2FnZS5qc29uJyxcbiAgICAgICAgJy90c2NvbmZpZy5qc29uJyxcbiAgICAgICAgJy92aXRlLmNvbmZpZy50cycsXG4gICAgICAgICcvaW5kZXguaHRtbCcsXG4gICAgICAgICcvbWV0YWRhdGEuanNvbicsXG4gICAgICAgICcvUkVBRE1FLm1kJyxcbiAgICAgICAgJy8uZ2l0aWdub3JlJyxcbiAgICAgICAgJy8uZW52LmV4YW1wbGUnLFxuICAgICAgICAnL3NyYy9tYWluLnRzeCcsXG4gICAgICAgICcvc3JjL0FwcC50c3gnLFxuICAgICAgICAnL3NyYy9pbmRleC5jc3MnLFxuICAgICAgICAnL3NyYy90eXBlcy9zdG9yZS50cycsXG4gICAgICAgICcvc3JjL2RhdGEvZGVmYXVsdFByb2R1Y3RzLnRzJyxcbiAgICAgICAgJy9zcmMvY29udGV4dC9TdG9yZUNvbnRleHQudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9jb21tb24vSGVhZGVyLnRzeCcsXG4gICAgICAgICcvc3JjL2NvbXBvbmVudHMvY29tbW9uL09yZGVyTm90aWZpY2F0aW9uVG9hc3QudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9jb21tb24vRXhwb3J0TW9kYWwudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9idXllci9Qcm9kdWN0Q2FyZC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL2J1eWVyL1F1aWNrT3JkZXJNb2RhbC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL2J1eWVyL0NhcnREcmF3ZXIudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9idXllci9CdXllclN0b3JlZnJvbnQudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9zZWxsZXIvU2VsbGVyRGFzaGJvYXJkLnRzeCcsXG4gICAgICAgICcvc3JjL2NvbXBvbmVudHMvc2VsbGVyL1NlbGxlclByb2R1Y3RNb2RhbC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL3NlbGxlci9PcmRlckRldGFpbHNNb2RhbC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL2FyY2hpdGVjdHVyZS9BcmNoaXRlY3R1cmVWaWV3LnRzeCdcbiAgICAgIF07XG5cbiAgICAgIC8vIEltYWdlIGFzc2V0c1xuICAgICAgY29uc3QgaW1hZ2VQYXRocyA9IFtcbiAgICAgICAgJy9zcmMvYXNzZXRzL2ltYWdlcy9wcm9kdWN0X3NtYXJ0d2F0Y2hfbWluaW1hbF8xNzkyMjU3NTEwMTE2LmpwZycsXG4gICAgICAgICcvc3JjL2Fzc2V0cy9pbWFnZXMvcHJvZHVjdF9sZWF0aGVyX2JhZ19icm93bl8xNzkyMjU3NTMyNTQzLmpwZycsXG4gICAgICAgICcvc3JjL2Fzc2V0cy9pbWFnZXMvcHJvZHVjdF9hdWRpb19oZWFkcGhvbmVzXzE3OTIyNTc1NTIxODcuanBnJyxcbiAgICAgICAgJy9zcmMvYXNzZXRzL2ltYWdlcy9wcm9kdWN0X3NuZWFrZXJzX2xpZmVzdHlsZV8xNzkyMjU3NTY3MjUzLmpwZydcbiAgICAgIF07XG5cbiAgICAgIC8vIEZldGNoIGFuZCBhZGQgdGV4dC9jb2RlIGZpbGVzXG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgICAgZmlsZVBhdGhzLm1hcChhc3luYyAocGF0aCkgPT4ge1xuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChwYXRoKTtcbiAgICAgICAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgICAgICAgIGNvbnN0IGNsZWFuUGF0aCA9IHBhdGguc3RhcnRzV2l0aCgnLycpID8gcGF0aC5zbGljZSgxKSA6IHBhdGg7XG4gICAgICAgICAgICAgIHppcC5maWxlKGNsZWFuUGF0aCwgdGV4dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdGYWlsZWQgdG8gYnVuZGxlIGZpbGUgaW4gemlwOicsIHBhdGgsIGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICk7XG5cbiAgICAgIC8vIEZldGNoIGFuZCBhZGQgaW1hZ2UgYmluYXJ5IGZpbGVzXG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgICAgaW1hZ2VQYXRocy5tYXAoYXN5bmMgKHBhdGgpID0+IHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2gocGF0aCk7XG4gICAgICAgICAgICBpZiAocmVzLm9rKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXMuYmxvYigpO1xuICAgICAgICAgICAgICBjb25zdCBjbGVhblBhdGggPSBwYXRoLnN0YXJ0c1dpdGgoJy8nKSA/IHBhdGguc2xpY2UoMSkgOiBwYXRoO1xuICAgICAgICAgICAgICB6aXAuZmlsZShjbGVhblBhdGgsIGJsb2IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybignRmFpbGVkIHRvIGJ1bmRsZSBpbWFnZSBpbiB6aXA6JywgcGF0aCwgZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KVxuICAgICAgKTtcblxuICAgICAgLy8gR2VuZXJhdGUgdGhlIFpJUCBibG9iXG4gICAgICBjb25zdCB6aXBDb250ZW50ID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoeyB0eXBlOiAnYmxvYicgfSk7XG5cbiAgICAgIC8vIFRyaWdnZXIgaW5zdGFudCBicm93c2VyIGRvd25sb2FkXG4gICAgICBjb25zdCBkb3dubG9hZFVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoemlwQ29udGVudCk7XG4gICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgbGluay5ocmVmID0gZG93bmxvYWRVcmw7XG4gICAgICBsaW5rLmRvd25sb2FkID0gJ2JhemFhcmZsb3ctc2hvcC1jb21wbGV0ZS56aXAnO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIGxpbmsuY2xpY2soKTtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG4gICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKGRvd25sb2FkVXJsKTtcblxuICAgICAgc2V0RG93bmxvYWRTdWNjZXNzKHRydWUpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZ2VuZXJhdGluZyB6aXA6JywgZXJyKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNaaXBwaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgZ2l0Q2xpQ29tbWFuZHMgPSBgIyBTdGVwIDE6IEV4dHJhY3QgZG93bmxvYWRlZCBiYXphYXJmbG93LXNob3AtY29tcGxldGUuemlwICYgb3BlbiB0ZXJtaW5hbFxuY2QgYmF6YWFyZmxvdy1zaG9wLWNvbXBsZXRlXG5cbiMgU3RlcCAyOiBJbml0aWFsaXplIEdpdCByZXBvc2l0b3J5XG5naXQgaW5pdFxuZ2l0IGFkZCAuXG5naXQgY29tbWl0IC1tIFwiSW5pdGlhbCBjb21taXQgb2YgQmF6YWFyRmxvdyBlLWNvbW1lcmNlIHBsYXRmb3JtXCJcblxuIyBTdGVwIDM6IFNldCBtYWluIGJyYW5jaCAmIGxpbmsgeW91ciBHaXRIdWIgcmVwb3NpdG9yeVxuZ2l0IGJyYW5jaCAtTSBtYWluXG5naXQgcmVtb3RlIGFkZCBvcmlnaW4gaHR0cHM6Ly9naXRodWIuY29tLzxZT1VSLUdJVEhVQi1VU0VSTkFNRT4vPFlPVVItUkVQTy1OQU1FPi5naXRcblxuIyBTdGVwIDQ6IFB1c2ggdG8gR2l0SHViIVxuZ2l0IHB1c2ggLXUgb3JpZ2luIG1haW5gO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLXNsYXRlLTk1MC82MCBiYWNrZHJvcC1ibHVyLXhzIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctMnhsIGJnLXdoaXRlIHJvdW5kZWQteGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBvdmVyZmxvdy1oaWRkZW4gbXktOCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJnLXNsYXRlLTUwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZCBiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8R2l0aHViIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBmb250LWRpc3BsYXlcIj5cbiAgICAgICAgICAgICAgICBEb3dubG9hZCBDb2RlICYgRXhwb3J0IHRvIEdpdEh1YlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgMS1jbGljayBmdWxsIHNvdXJjZSBjb2RlIGRvd25sb2FkIGFuZCBzdGVwLWJ5LXN0ZXAgR2l0SHViIHB1Ymxpc2hpbmcgaW5zdHJ1Y3Rpb25zXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtNzAwIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtMjAwLzUwIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRlbnQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNlwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBPcHRpb24gMTogRGlyZWN0IFNpbmdsZSBDbGljayBaSVAgRG93bmxvYWQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTUgYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1hbWJlci03MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICBNZXRob2QgMSAoSW5zdGFudCDCtyBTaW5nbGUgQ2xpY2spXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgRG93bmxvYWQgQ29tcGxldGUgUHJvamVjdCBaSVAgQXJjaGl2ZVxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICBCdW5kbGVzIGFsbCBjb2RlIChgc3JjL2AsIGBjb21wb25lbnRzL2AsIFRhaWx3aW5kIHNldHVwLCB0eXBlcywgc2VlZCBkYXRhLCBhbmQgaW1hZ2VzKSBpbnRvIGEgc2luZ2xlIHJlYWR5LXRvLXJ1biBgLnppcGAgZmlsZS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFppcH1cbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNaaXBwaW5nfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGRpc2FibGVkOmJnLXNsYXRlLTQwMCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkLWxnIHNoYWRvdy1zbSB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7aXNaaXBwaW5nID8gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4+R2VuZXJhdGluZyBaSVAuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IGRvd25sb2FkU3VjY2VzcyA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Eb3dubG9hZGVkITwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkRvd25sb2FkIFByb2plY3QgWklQPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAge2Rvd25sb2FkU3VjY2VzcyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yLjUgYmctZW1lcmFsZC01MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIHJvdW5kZWQgdGV4dC14cyB0ZXh0LWVtZXJhbGQtODAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC02MDAgc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+YmF6YWFyZmxvdy1zaG9wLWNvbXBsZXRlLnppcDwvc3Ryb25nPiBoYXMgYmVlbiBkb3dubG9hZGVkIHRvIHlvdXIgY29tcHV0ZXIhPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogT3B0aW9uIDI6IFB1c2ggdG8gR2l0SHViIHZpYSBDTEkgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAgTWV0aG9kIDIgKFB1Ymxpc2ggdG8gR2l0SHViKVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgIEdpdCBDb21tYW5kcyB0byBQdXNoIHRvIHlvdXIgR2l0SHViIEFjY291bnRcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29weSgnZ2l0X2NtZHMnLCBnaXRDbGlDb21tYW5kcyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGJnLXNsYXRlLTEwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7Y29waWVkS2V5ID09PSAnZ2l0X2NtZHMnID8gPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC02MDBcIiAvPiA6IDxDb3B5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz59XG4gICAgICAgICAgICAgICAgPHNwYW4+e2NvcGllZEtleSA9PT0gJ2dpdF9jbWRzJyA/ICdDb3BpZWQgQ29tbWFuZHMnIDogJ0NvcHkgQ29tbWFuZHMnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTMuNSBmb250LW1vbm8gdGV4dC14cyBvdmVyZmxvdy14LWF1dG8gcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJsZWFkaW5nLXJlbGF4ZWRcIj57Z2l0Q2xpQ29tbWFuZHN9PC9wcmU+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBPcHRpb24gMzogQUkgU3R1ZGlvIEJ1aWx0LWluIEhlYWRlciBFeHBvcnQgQnV0dG9uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgYmctd2hpdGUgc3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1zbGF0ZS05MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+QWx0ZXJuYXRpdmU6IEFJIFN0dWRpbyBUb3AtUmlnaHQgRXhwb3J0IE1lbnU8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICBHb29nbGUgQUkgU3R1ZGlvIGtlIHNjcmVlbiBrZSA8c3Ryb25nPnRvcC1yaWdodCBjb3JuZXI8L3N0cm9uZz4gcGFyIDxzdHJvbmc+XCJFeHBvcnRcIjwvc3Ryb25nPiB5YSB0ZWVuIGRvdHMgKOKLrikgbWVudSBwYXIgY2xpY2sga2FyZWluLiBXYWhhbiBzZSBhYXAgZGlyZWN0IDxzdHJvbmc+XCJDcmVhdGUgR2l0SHViIFJlcG9zaXRvcnlcIjwvc3Ryb25nPiBzZWxlY3Qga2Fya2UgYXBuZSBHaXRIdWIgYWNjb3VudCBrZSBzYXRoIDEtY2xpY2sgY29ubmVjdCBrYXIgc2FrdGUgaGFpbi5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB4LTYgcHktMy41IGJnLXNsYXRlLTUwIGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICA8VGVybWluYWwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+V29ya3Mgd2l0aCBzdGFuZGFyZCBOb2RlLmpzICh2MTgrKSAmIGBucG0gaW5zdGFsbGA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJnLXNsYXRlLTEwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDbG9zZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19