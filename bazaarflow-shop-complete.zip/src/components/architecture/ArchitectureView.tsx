const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fbe4f0b6";
import { useStore } from "/src/context/StoreContext.tsx";
import { Database, Layers, Code2, Rocket, Layout, Copy, Check, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=e3a8a8c9";
var _jsxFileName = "/app/applet/src/components/architecture/ArchitectureView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fbe4f0b6";
export const ArchitectureView = () => {
	const { setCurrentView } = useStore();
	const [activeSection, setActiveSection] = useState("stack");
	const [copiedKey, setCopiedKey] = useState(null);
	const [lang, setLang] = useState("urdu");
	const handleCopy = (key, text) => {
		navigator.clipboard.writeText(text);
		setCopiedKey(key);
		setTimeout(() => setCopiedKey(null), 2e3);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-50 pb-20",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-white border-b border-slate-200",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col md:flex-row md:items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "System Engineering & Architecture" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									"aria-hidden": "true",
									children: "·"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 37,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "20-Year Full-Stack Blueprint" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 38,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 font-display",
							children: "E-Commerce Architecture & Implementation Blueprint"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-500 mt-1",
							children: "Complete technical specification, schemas, wireframe workflows, and production deployment guide."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center border border-slate-200 rounded p-0.5 bg-slate-100",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setLang("urdu"),
								className: `px-3 py-1 text-xs font-semibold rounded transition-colors cursor-pointer ${lang === "urdu" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
								children: "Roman Urdu"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setLang("english"),
								className: `px-3 py-1 text-xs font-semibold rounded transition-colors cursor-pointer ${lang === "english" ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"}`,
								children: "English"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setCurrentView("buyer"),
							className: "px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors cursor-pointer",
							children: "Back to Store →"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 overflow-x-auto pt-6 border-t border-slate-100 mt-6 scrollbar-none",
					children: [
						{
							id: "stack",
							label: "1. Recommended Tech Stack",
							icon: Layers
						},
						{
							id: "wireframes",
							label: "2. UI/UX Blueprint & Wireframes",
							icon: Layout
						},
						{
							id: "schema",
							label: "3. Database Schemas",
							icon: Database
						},
						{
							id: "code",
							label: "4. Core Production Code",
							icon: Code2
						},
						{
							id: "deployment",
							label: "5. Deployment on Vercel / Netlify",
							icon: Rocket
						}
					].map((tab) => {
						const Icon = tab.icon;
						return /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveSection(tab.id),
							className: `px-3.5 py-2 text-xs font-medium rounded transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${activeSection === tab.id ? "bg-slate-900 text-white" : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50"}`,
							children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: tab.label }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 99,
								columnNumber: 19
							}, this)]
						}, tab.id, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8",
			children: [
				activeSection === "stack" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white border border-slate-200 rounded-xl p-6",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold text-slate-900 font-display mb-2",
								children: lang === "urdu" ? "1. Recommended Lightweight Tech Stack (Behtareen Combinations)" : "1. Recommended Lightweight Tech Stack"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600 mb-6 leading-relaxed",
								children: lang === "urdu" ? "Fast performance, zero bloat, mobile responsiveness, aur easy maintenance ke liye hum modern decoupled architecture recommend karte hain jisme frontend instant load hota hai aur backend scalable rehta hai." : "For ultra-fast load times, mobile performance, and low infrastructure costs, we recommend a modern decoupled stack with client-side caching and lightweight serverless APIs."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 117,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "border border-slate-200 rounded-lg p-5 bg-slate-50",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-1",
												children: "Layer 1: Frontend"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 127,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-base font-bold text-slate-900 mb-2",
												children: "React 19 + Vite + Tailwind CSS"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 128,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "text-xs text-slate-600 space-y-2",
												children: [
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 131,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Vite:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 132,
															columnNumber: 29
														}, this), " Ultra-fast bundling (sub-second HMR) aur zero runtime overhead."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 132,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 130,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 135,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Tailwind CSS:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 136,
															columnNumber: 29
														}, this), " Minimal CSS bundle size (<15KB gzipped in production), responsive utilities."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 136,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 134,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 139,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Lucide Icons:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 140,
															columnNumber: 29
														}, this), " Tree-shakable SVG icons without heavy icon packages."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 140,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 138,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 129,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 126,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "border border-slate-200 rounded-lg p-5 bg-slate-50",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-1",
												children: "Layer 2: Backend & API"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 147,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-base font-bold text-slate-900 mb-2",
												children: "Node.js + Express / Serverless"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 148,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "text-xs text-slate-600 space-y-2",
												children: [
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 151,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Express REST / Edge Functions:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 152,
															columnNumber: 29
														}, this), " Fast API routes for `/api/orders`, `/api/products`."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 152,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 150,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 155,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Zero Session State:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 156,
															columnNumber: 29
														}, this), " JWT authentication for Seller Admin with secure HttpOnly cookies."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 156,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 154,
														columnNumber: 21
													}, this),
													/* @__PURE__ */ _jsxDEV("li", {
														className: "flex items-start gap-1.5",
														children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 159,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "WebSockets / SSE:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 160,
															columnNumber: 29
														}, this), " Real-time push notification when a buyer submits a new order."] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 160,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 158,
														columnNumber: 21
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 149,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 146,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "border border-slate-200 rounded-lg p-5 bg-slate-50",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold text-slate-400 uppercase tracking-wider mb-1",
												children: "Layer 3: Database"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 167,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-base font-bold text-slate-900 mb-2",
												children: "PostgreSQL (Supabase) ya Firebase"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 168,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("ul", {
												className: "text-xs text-slate-600 space-y-2",
												children: [/* @__PURE__ */ _jsxDEV("li", {
													className: "flex items-start gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 171,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Option A (SQL - Recommended):" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 172,
														columnNumber: 29
													}, this), " PostgreSQL with Drizzle/Prisma ORM for strict order & inventory transactions."] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 172,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 170,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("li", {
													className: "flex items-start gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 175,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Option B (NoSQL / Realtime):" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 176,
														columnNumber: 29
													}, this), " Firebase Firestore for instant real-time live sync between buyer and seller out of the box."] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 176,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 174,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 169,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 11
				}, this),
				activeSection === "wireframes" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white border border-slate-200 rounded-xl p-6",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold text-slate-900 font-display mb-2",
								children: lang === "urdu" ? "2. UI/UX Wireframe & Workflow Blueprint" : "2. UI/UX Wireframe & Workflow Architecture"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 190,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600 mb-6",
								children: lang === "urdu" ? "Buyer aur Seller dono ke liye clean 2-step direct ordering loop jo Pakistani/South Asian e-commerce conversion rates ko maximum barhata hai." : "Streamlined 2-step direct checkout loop optimized for high mobile conversion and rapid seller order fulfillment."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 rounded-lg p-5 space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-3 border-b border-slate-200",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-900 uppercase tracking-wider",
											children: "A. Buyer View Workflow (Khareedar)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 203,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-mono text-emerald-600 font-semibold",
											children: "< 30s Checkout"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 204,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 202,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 1: Product Discovery (Grid View)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 209,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Clean product cards showing photo (65%), product name, category, clear tabular price (e.g. PKR 18,500), stock tag, and high-visibility \"Order Now\" button."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 210,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 208,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 2: Instant Express Modal (No Registration Friction)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Buyer doesn't need to create an account or remember passwords. Clicking \"Order Now\" opens a popup with 3 essential fields: Full Name, Phone / WhatsApp, and Complete Street Address."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 215,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 213,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 3: Instant Confirmation & WhatsApp Receipt"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 219,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Unique Order Tracking Number (#BF-XXXX) is generated, with immediate confirmation screen and direct WhatsApp confirmation share."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 220,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 218,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 207,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 201,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 rounded-lg p-5 space-y-4",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-3 border-b border-slate-200",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-900 uppercase tracking-wider",
											children: "B. Seller Dashboard Workflow (Dukandar / Admin)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 228,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-mono text-amber-600 font-semibold",
											children: "Real-Time Dispatch"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 229,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 227,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-3 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 1: Incoming Order Notification Alert"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 234,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Seller dashboard displays visual alert and badge count the moment any buyer submits an order."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 235,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 233,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 2: Dispatch Label & Customer Contact"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 239,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Seller gets 1-click \"Copy Dispatch Label\" for courier booking (TCS, Leopards, Trax, PostEx), plus 1-click WhatsApp chat button."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 240,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 238,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "p-3 bg-slate-50 rounded border border-slate-200",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-semibold text-slate-800 mb-1",
													children: "Step 3: Product Inventory Control"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 244,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("p", {
													className: "text-slate-600 text-[11px]",
													children: "Add, edit, or delete items, update stock status (In Stock / Low Stock / Out of Stock), and adjust prices dynamically."
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 245,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 243,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 199,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 11
				}, this),
				activeSection === "schema" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white border border-slate-200 rounded-xl p-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold text-slate-900 font-display",
								children: lang === "urdu" ? "3. Database Schema (SQL aur NoSQL Structure)" : "3. Production Database Schema"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 260,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600",
								children: lang === "urdu" ? "Products, Orders, aur OrderItems tables ka complete DDL structure for PostgreSQL aur Firestore." : "Relational PostgreSQL DDL schema with foreign key constraints, indexes, and order status enums."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 263,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleCopy("sql_schema", sqlSchemaCode),
								className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded cursor-pointer",
								children: [copiedKey === "sql_schema" ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 49
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 274,
									columnNumber: 102
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedKey === "sql_schema" ? "Copied SQL" : "Copy SQL Schema" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 275,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 270,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 text-slate-200 rounded-lg p-4 font-mono text-xs overflow-x-auto",
							children: /* @__PURE__ */ _jsxDEV("pre", { children: sqlSchemaCode }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 257,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 256,
					columnNumber: 11
				}, this),
				activeSection === "code" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white border border-slate-200 rounded-xl p-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold text-slate-900 font-display",
								children: lang === "urdu" ? "4. Production Code Examples (Front-End & Handler Logic)" : "4. Core Production Code Snippets"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600",
								children: lang === "urdu" ? "Tailwind CSS se Product Card, Express Order Handler, aur Quick Checkout Modal ka clean code." : "Clean, copy-pasteable React + Tailwind CSS code for buyer order checkout and backend submission."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 295,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleCopy("express_handler", expressHandlerCode),
								className: "inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded cursor-pointer",
								children: [copiedKey === "express_handler" ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 54
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 107
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedKey === "express_handler" ? "Copied" : "Copy Backend API Code" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 302,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 290,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 text-slate-200 rounded-lg p-4 font-mono text-xs overflow-x-auto",
							children: /* @__PURE__ */ _jsxDEV("pre", { children: expressHandlerCode }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 312,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 289,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 288,
					columnNumber: 11
				}, this),
				activeSection === "deployment" && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-white border border-slate-200 rounded-xl p-6",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-xl font-bold text-slate-900 font-display mb-2",
								children: lang === "urdu" ? "5. Deployment Strategy (Vercel & Netlify Hosting Guide)" : "5. Production Deployment Strategy"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600 mb-6",
								children: lang === "urdu" ? "Step-by-step tareeqa Vercel aur Netlify par apni shop store live karne ke liye (Zero cost free-tier supported)." : "Step-by-step instructions for hosting frontend and backend on Vercel and Netlify with custom domain support."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-6",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 rounded-lg p-5 space-y-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-2 border-b border-slate-200",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-900",
											children: "Hosting on Vercel (Recommended)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-mono text-slate-500",
											children: "vercel.json"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 336,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 334,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("ol", {
										className: "text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed",
										children: [
											/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "GitHub Repository:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 340,
												columnNumber: 25
											}, this), " Apna code GitHub repo mein push karein (`git push origin main`)."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 340,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [
												/* @__PURE__ */ _jsxDEV("strong", { children: "Connect Vercel:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 341,
													columnNumber: 25
												}, this),
												" ",
												/* @__PURE__ */ _jsxDEV("a", {
													href: "https://vercel.com",
													target: "_blank",
													rel: "noreferrer",
													className: "text-slate-900 font-semibold underline",
													children: "vercel.com"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 341,
													columnNumber: 58
												}, this),
												" par login karein aur \"Import Git Repository\" select karein."
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 341,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Build Settings:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 342,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "mt-1 bg-slate-100 p-2 rounded font-mono text-[11px]",
												children: [
													"Build Command: npm run build",
													/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 344,
														columnNumber: 53
													}, this),
													"Output Directory: dist",
													/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 345,
														columnNumber: 47
													}, this),
													"Install Command: npm install"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 343,
												columnNumber: 23
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 342,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Environment Variables:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 349,
												columnNumber: 25
											}, this), " Agar backend API ya Database use kar rahe hain to `DATABASE_URL` ya `VITE_API_URL` add karein."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 349,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Deploy:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 350,
												columnNumber: 25
											}, this), " \"Deploy\" button click karein. 45 seconds ke andar aapki shop live URL (`myshop.vercel.app`) par active ho jayegi!"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 350,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 339,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 333,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "border border-slate-200 rounded-lg p-5 space-y-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-2 border-b border-slate-200",
										children: [/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-sm font-bold text-slate-900",
											children: "Hosting on Netlify"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 357,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-mono text-slate-500",
											children: "_redirects"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 358,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("ol", {
										className: "text-xs text-slate-600 space-y-2 list-decimal list-inside leading-relaxed",
										children: [
											/* @__PURE__ */ _jsxDEV("li", { children: [
												/* @__PURE__ */ _jsxDEV("strong", { children: "Netlify Dashboard:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 362,
													columnNumber: 25
												}, this),
												" ",
												/* @__PURE__ */ _jsxDEV("a", {
													href: "https://netlify.com",
													target: "_blank",
													rel: "noreferrer",
													className: "text-slate-900 font-semibold underline",
													children: "netlify.com"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 362,
													columnNumber: 61
												}, this),
												" par \"Add new site\" > \"Import an existing project\" karein."
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [
												/* @__PURE__ */ _jsxDEV("strong", { children: "SPA Redirects Rule:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 363,
													columnNumber: 25
												}, this),
												" React single-page routing ke liye `public/_redirects` file mein yeh line likhein:",
												/* @__PURE__ */ _jsxDEV("div", {
													className: "mt-1 bg-slate-100 p-2 rounded font-mono text-[11px]",
													children: "/* /index.html 200"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 364,
													columnNumber: 23
												}, this)
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Custom Domain & SSL:" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 25
											}, this), " Netlify Settings mein jakar apna custom `.com` ya `.pk` domain add karein; Free Let's Encrypt SSL automatically activate ho jayega."] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 368,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 361,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 355,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 28,
		columnNumber: 5
	}, this);
};
// Database Schema Code Block
const sqlSchemaCode = `-- PostgreSQL Production Database Schema for Single/Multi-Vendor Store

-- 1. Products Table
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sku VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
  stock_status VARCHAR(20) NOT NULL DEFAULT 'in_stock' CHECK (stock_status IN ('in_stock', 'low_stock', 'out_of_stock')),
  stock_count INT NOT NULL DEFAULT 0,
  category VARCHAR(100) NOT NULL,
  image_url TEXT NOT NULL,
  vendor_id UUID, -- For multi-vendor support
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Orders Table
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number VARCHAR(50) UNIQUE NOT NULL,
  customer_full_name VARCHAR(150) NOT NULL,
  customer_phone VARCHAR(50) NOT NULL,
  delivery_city VARCHAR(100) NOT NULL,
  delivery_address TEXT NOT NULL,
  delivery_note TEXT,
  total_amount DECIMAL(10, 2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'shipped', 'delivered', 'cancelled')),
  payment_method VARCHAR(30) NOT NULL DEFAULT 'cod' CHECK (payment_method IN ('cod', 'bank_transfer', 'online')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Order Items Table (Many-to-Many relationship)
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  product_name VARCHAR(255) NOT NULL,
  unit_price DECIMAL(10, 2) NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  subtotal DECIMAL(10, 2) NOT NULL
);

-- Indexes for lightning fast queries
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);`;
// Express API Code Block
const expressHandlerCode = `// Server-Side Node.js / Express Order Placement Handler
// Route: POST /api/orders

import express from 'express';
const router = express.Router();

router.post('/orders', async (req, res) => {
  try {
    const { customer, items, paymentMethod } = req.body;

    // 1. Validate mandatory buyer inputs
    if (!customer?.fullName || !customer?.phone || !customer?.deliveryAddress) {
      return res.status(400).json({ error: 'Full name, phone, and delivery address are required' });
    }

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'Order must contain at least one product' });
    }

    // 2. Calculate grand total securely on server side
    const totalAmount = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const orderNumber = 'BF-' + Math.floor(1000 + Math.random() * 9000);

    // 3. Insert order record inside database transaction
    const newOrder = {
      orderNumber,
      customer,
      items,
      totalAmount,
      status: 'pending',
      paymentMethod: paymentMethod || 'cod',
      createdAt: new Date().toISOString()
    };

    // 4. Notify connected seller sockets in real-time
    // io.emit('new_order', newOrder);

    return res.status(201).json({
      success: true,
      message: 'Order created successfully',
      order: newOrder
    });
  } catch (error) {
    console.error('Order creation failed:', error);
    return res.status(500).json({ error: 'Internal server error processing order' });
  }
});

export default router;`;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGdCQUFnQjtBQUN6QixTQUNFLFVBQ0EsUUFDQSxPQUNBLFFBQ0EsUUFDQSxNQUNBLE9BRUEsb0JBQ0s7OztBQUVQLE9BQU8sTUFBTSx5QkFBbUM7Q0FDOUMsTUFBTSxFQUFFLG1CQUFtQixTQUFTO0NBQ3BDLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFvRSxPQUFPO0NBQ3JILE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixJQUFJO0NBQzlELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBNkIsTUFBTTtDQUUzRCxNQUFNLGNBQWMsS0FBYSxTQUFpQjtFQUNoRCxVQUFVLFVBQVUsVUFBVSxJQUFJO0VBQ2xDLGFBQWEsR0FBRztFQUNoQixpQkFBaUIsYUFBYSxJQUFJLEdBQUcsR0FBSTtDQUMzQztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUdFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFELFlBQU0sb0NBQXVDOzs7OztRQUM3Qyx3QkFBQyxRQUFEO1NBQU0sZUFBWTttQkFBTztRQUFPOzs7OztRQUNoQyx3QkFBQyxRQUFELFlBQU0sK0JBQWtDOzs7OztPQUNyQzs7Ozs7O01BQ0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTRFO01BRXRGOzs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE4QjtNQUV4Qzs7Ozs7S0FDQTs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxRQUFRLE1BQU07UUFDN0IsV0FBVyw0RUFDVCxTQUFTLFNBQVMsc0NBQXNDO2tCQUUzRDtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFFBQVEsU0FBUztRQUNoQyxXQUFXLDRFQUNULFNBQVMsWUFBWSxzQ0FBc0M7a0JBRTlEO09BRU87Ozs7ZUFDTDs7Ozs7Z0JBRUwsd0JBQUMsVUFBRDtPQUNFLGVBQWUsZUFBZSxPQUFPO09BQ3JDLFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7OzthQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1o7TUFDQztPQUFFLElBQUk7T0FBUyxPQUFPO09BQTZCLE1BQU07TUFBTztNQUNoRTtPQUFFLElBQUk7T0FBYyxPQUFPO09BQW1DLE1BQU07TUFBTztNQUMzRTtPQUFFLElBQUk7T0FBVSxPQUFPO09BQXVCLE1BQU07TUFBUztNQUM3RDtPQUFFLElBQUk7T0FBUSxPQUFPO09BQTJCLE1BQU07TUFBTTtNQUM1RDtPQUFFLElBQUk7T0FBYyxPQUFPO09BQXFDLE1BQU07TUFBTztLQUMvRSxDQUFDLENBQUMsS0FBSSxRQUFPO01BQ1gsTUFBTSxPQUFPLElBQUk7TUFDakIsT0FDRSx3QkFBQyxVQUFEO09BRUUsZUFBZSxpQkFBaUIsSUFBSSxFQUFTO09BQzdDLFdBQVcsd0hBQ1Qsa0JBQWtCLElBQUksS0FDbEIsNEJBQ0E7aUJBTlIsQ0FTRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU8sSUFBSSxNQUFZOzs7O2VBQ2pCO1NBVkQsSUFBSTs7OzthQVVIO0tBRVosQ0FBQztJQUNFOzs7O1lBQ0Y7Ozs7OztFQUNGOzs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdHLGtCQUFrQixXQUNqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsU0FBUyxTQUFTLG1FQUFtRTtPQUNwRjs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixTQUFTLFNBQ04sa05BQ0E7T0FDSDs7Ozs7T0FFSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUdFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWlFO1dBQXNCOzs7OztXQUN0Ryx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBMEM7V0FBa0M7Ozs7O1dBQzFGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkO2FBQ0Usd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWQsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2Q0FBOEM7Ozs7d0JBQ3RFLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsUUFBYTs7Ozt3QkFBQyxrRUFBc0U7Ozs7c0JBQ2hHOzs7Ozs7YUFDSix3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBZCxDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDZDQUE4Qzs7Ozt3QkFDdEUsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxnQkFBcUI7Ozs7d0JBQUMsK0VBQXNGOzs7O3NCQUN4SDs7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWQsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2Q0FBOEM7Ozs7d0JBQ3RFLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsZ0JBQXFCOzs7O3dCQUFDLHVEQUEyRDs7OztzQkFDN0Y7Ozs7OztZQUNGOzs7Ozs7VUFDRDs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBaUU7V0FBMkI7Ozs7O1dBQzNHLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUEwQztXQUFrQzs7Ozs7V0FDMUYsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFDRSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBZCxDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDZDQUE4Qzs7Ozt3QkFDdEUsd0JBQUMsUUFBRCxhQUFNLHdCQUFDLFVBQUQsWUFBUSxpQ0FBc0M7Ozs7d0JBQUMsc0RBQTBEOzs7O3NCQUM3Rzs7Ozs7O2FBQ0osd0JBQUMsTUFBRDtjQUFJLFdBQVU7d0JBQWQsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2Q0FBOEM7Ozs7d0JBQ3RFLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsc0JBQTJCOzs7O3dCQUFDLG9FQUF3RTs7OztzQkFDaEg7Ozs7OzthQUNKLHdCQUFDLE1BQUQ7Y0FBSSxXQUFVO3dCQUFkLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsNkNBQThDOzs7O3dCQUN0RSx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFRLG9CQUF5Qjs7Ozt3QkFBQyxnRUFBb0U7Ozs7c0JBQzFHOzs7Ozs7WUFDRjs7Ozs7O1VBQ0Q7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWlFO1dBQXNCOzs7OztXQUN0Ryx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBMEM7V0FBcUM7Ozs7O1dBQzdGLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkLENBQ0Usd0JBQUMsTUFBRDthQUFJLFdBQVU7dUJBQWQsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSw2Q0FBOEM7Ozs7dUJBQ3RFLHdCQUFDLFFBQUQsYUFBTSx3QkFBQyxVQUFELFlBQVEsZ0NBQXFDOzs7O3VCQUFDLGdGQUFvRjs7OztxQkFDdEk7Ozs7O3NCQUNKLHdCQUFDLE1BQUQ7YUFBSSxXQUFVO3VCQUFkLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsNkNBQThDOzs7O3VCQUN0RSx3QkFBQyxRQUFELGFBQU0sd0JBQUMsVUFBRCxZQUFRLCtCQUFvQzs7Ozt1QkFBQyw4RkFBa0c7Ozs7cUJBQ25KOzs7OztvQkFDRjs7Ozs7O1VBQ0Q7Ozs7OztRQUVGOzs7Ozs7TUFDRjs7Ozs7O0lBQ0Y7Ozs7O0lBSU4sa0JBQWtCLGdCQUNqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsU0FBUyxTQUFTLDRDQUE0QztPQUM3RDs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixTQUFTLFNBQ04saUpBQ0E7T0FDSDs7Ozs7T0FFSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBNEQ7VUFBc0M7Ozs7b0JBQ2hILHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUF1RDtVQUF1Qjs7OztrQkFDM0Y7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBb0M7WUFBMEM7Ozs7c0JBQzdGLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUE2QjtZQUE2Sjs7OztvQkFDcE07Ozs7OztXQUVMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQW9DO1lBQTZEOzs7O3NCQUNoSCx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBNkI7WUFBdUw7Ozs7b0JBQzlOOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFvQztZQUFvRDs7OztzQkFDdkcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQW1JOzs7O29CQUMxSzs7Ozs7O1VBQ0Y7Ozs7O2lCQUNGOzs7OztrQkFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQTREO1VBQW1EOzs7O29CQUM3SCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUQ7VUFBd0I7Ozs7a0JBQzFGOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQW9DO1lBQThDOzs7O3NCQUNqRyx3QkFBQyxLQUFEO2FBQUcsV0FBVTt1QkFBNkI7WUFBZ0c7Ozs7b0JBQ3ZJOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFvQztZQUE4Qzs7OztzQkFDakcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQWtJOzs7O29CQUN6Szs7Ozs7O1dBRUwsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBb0M7WUFBc0M7Ozs7c0JBQ3pGLHdCQUFDLEtBQUQ7YUFBRyxXQUFVO3VCQUE2QjtZQUF3SDs7OztvQkFDL0o7Ozs7OztVQUNGOzs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7Ozs7SUFDRjs7Ozs7SUFJTixrQkFBa0IsWUFDakIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFNBQVMsU0FBUyxpREFBaUQ7T0FDbEU7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsU0FBUyxTQUNOLG9HQUNBO09BQ0g7Ozs7ZUFDQTs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxXQUFXLGNBQWMsYUFBYTtRQUNyRCxXQUFVO2tCQUZaLENBSUcsY0FBYyxlQUFlLHdCQUFDLE9BQUQsRUFBTyxXQUFVLCtCQUFnQzs7OzttQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2tCQUNsSCx3QkFBQyxRQUFELFlBQU8sY0FBYyxlQUFlLGVBQWUsa0JBQXdCOzs7O2dCQUNyRTs7Ozs7ZUFDTDs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRCxZQUFNLGNBQW1COzs7OztNQUN0Qjs7OztjQUNGOzs7Ozs7SUFDRjs7Ozs7SUFJTixrQkFBa0IsVUFDakIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUNYLFNBQVMsU0FBUyw0REFBNEQ7T0FDN0U7Ozs7aUJBQ0osd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsU0FBUyxTQUNOLGlHQUNBO09BQ0g7Ozs7ZUFDQTs7OztpQkFFTCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxXQUFXLG1CQUFtQixrQkFBa0I7UUFDL0QsV0FBVTtrQkFGWixDQUlHLGNBQWMsb0JBQW9CLHdCQUFDLE9BQUQsRUFBTyxXQUFVLCtCQUFnQzs7OzttQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2tCQUN2SCx3QkFBQyxRQUFELFlBQU8sY0FBYyxvQkFBb0IsV0FBVyx3QkFBOEI7Ozs7Z0JBQzVFOzs7OztlQUNMOzs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFELFlBQU0sbUJBQXdCOzs7OztNQUMzQjs7OztjQUNGOzs7Ozs7SUFDRjs7Ozs7SUFJTixrQkFBa0IsZ0JBQ2pCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFDWCxTQUFTLFNBQVMsNERBQTREO09BQzdFOzs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLFNBQVMsU0FDTixvSEFDQTtPQUNIOzs7OztPQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFtQztVQUFtQzs7OztvQkFDcEYsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXVDO1VBQWlCOzs7O2tCQUNyRTs7Ozs7bUJBRUwsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRSx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLHFCQUEwQjs7OztxQkFBQyxtRUFBcUU7Ozs7O1dBQzVHLHdCQUFDLE1BQUQ7WUFBSSx3QkFBQyxVQUFELFlBQVEsa0JBQXVCOzs7OztZQUFDO1lBQUMsd0JBQUMsS0FBRDthQUFHLE1BQUs7YUFBcUIsUUFBTzthQUFTLEtBQUk7YUFBYSxXQUFVO3VCQUF5QztZQUFhOzs7OztZQUFDO1dBQWdFOzs7OztXQUNwTyx3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLGtCQUF1Qjs7OztxQkFDakMsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFBcUU7YUFDdkMsd0JBQUMsTUFBRCxDQUFLOzs7OzthQUFDO2FBQ1osd0JBQUMsTUFBRCxDQUFLOzs7OzthQUFDO1lBRXpCOzs7OzttQkFDSDs7Ozs7V0FDSix3QkFBQyxNQUFELGFBQUksd0JBQUMsVUFBRCxZQUFRLHlCQUE4Qjs7OztxQkFBQyxpR0FBbUc7Ozs7O1dBQzlJLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEsVUFBZTs7OztxQkFBQyxzSEFBc0g7Ozs7O1VBQ2hKOzs7OztpQkFDRDs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFtQztVQUFzQjs7OztvQkFDdkUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXVDO1VBQWdCOzs7O2tCQUNwRTs7Ozs7bUJBRUwsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FDRSx3QkFBQyxNQUFEO1lBQUksd0JBQUMsVUFBRCxZQUFRLHFCQUEwQjs7Ozs7WUFBQztZQUFDLHdCQUFDLEtBQUQ7YUFBRyxNQUFLO2FBQXNCLFFBQU87YUFBUyxLQUFJO2FBQWEsV0FBVTt1QkFBeUM7WUFBYzs7Ozs7WUFBQztXQUFpRTs7Ozs7V0FDMU8sd0JBQUMsTUFBRDtZQUFJLHdCQUFDLFVBQUQsWUFBUSxzQkFBMkI7Ozs7O1lBQUM7WUFDdEMsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQXNEO1lBRWhFOzs7OztXQUNIOzs7OztXQUNKLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxVQUFELFlBQVEsdUJBQTRCOzs7O3FCQUFDLHNJQUF3STs7Ozs7VUFDL0s7Ozs7O2lCQUNEOzs7OztnQkFDRjs7Ozs7O01BQ0Y7Ozs7OztJQUNGOzs7OztHQUdKOzs7OztVQUVGOzs7Ozs7QUFFVDs7QUFHQSxNQUFNLGdCQUFnQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtEdEIsTUFBTSxxQkFBcUIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXJjaGl0ZWN0dXJlVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU3RvcmUgfSBmcm9tICcuLi8uLi9jb250ZXh0L1N0b3JlQ29udGV4dCc7XG5pbXBvcnQgeyBcbiAgRGF0YWJhc2UsIFxuICBMYXllcnMsIFxuICBDb2RlMiwgXG4gIFJvY2tldCwgXG4gIExheW91dCwgXG4gIENvcHksIFxuICBDaGVjaywgXG4gIEV4dGVybmFsTGluayxcbiAgQ2hldnJvblJpZ2h0XG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmV4cG9ydCBjb25zdCBBcmNoaXRlY3R1cmVWaWV3OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBzZXRDdXJyZW50VmlldyB9ID0gdXNlU3RvcmUoKTtcbiAgY29uc3QgW2FjdGl2ZVNlY3Rpb24sIHNldEFjdGl2ZVNlY3Rpb25dID0gdXNlU3RhdGU8J3N0YWNrJyB8ICd3aXJlZnJhbWVzJyB8ICdzY2hlbWEnIHwgJ2NvZGUnIHwgJ2RlcGxveW1lbnQnPignc3RhY2snKTtcbiAgY29uc3QgW2NvcGllZEtleSwgc2V0Q29waWVkS2V5XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbGFuZywgc2V0TGFuZ10gPSB1c2VTdGF0ZTwndXJkdScgfCAnZW5nbGlzaCc+KCd1cmR1Jyk7XG5cbiAgY29uc3QgaGFuZGxlQ29weSA9IChrZXk6IHN0cmluZywgdGV4dDogc3RyaW5nKSA9PiB7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodGV4dCk7XG4gICAgc2V0Q29waWVkS2V5KGtleSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWRLZXkobnVsbCksIDIwMDApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctc2xhdGUtNTAgcGItMjBcIj5cbiAgICAgIFxuICAgICAgey8qIFRvcCBIZWFkZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBweS04XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IG1kOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+U3lzdGVtIEVuZ2luZWVyaW5nICYgQXJjaGl0ZWN0dXJlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPsK3PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPjIwLVllYXIgRnVsbC1TdGFjayBCbHVlcHJpbnQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgc206dGV4dC0zeGwgZm9udC1ib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheVwiPlxuICAgICAgICAgICAgICAgIEUtQ29tbWVyY2UgQXJjaGl0ZWN0dXJlICYgSW1wbGVtZW50YXRpb24gQmx1ZXByaW50XG4gICAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgIENvbXBsZXRlIHRlY2huaWNhbCBzcGVjaWZpY2F0aW9uLCBzY2hlbWFzLCB3aXJlZnJhbWUgd29ya2Zsb3dzLCBhbmQgcHJvZHVjdGlvbiBkZXBsb3ltZW50IGd1aWRlLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICB7LyogTGFuZ3VhZ2UgU3dpdGNoZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZCBwLTAuNSBiZy1zbGF0ZS0xMDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRMYW5nKCd1cmR1Jyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQgdHJhbnNpdGlvbi1jb2xvcnMgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgbGFuZyA9PT0gJ3VyZHUnID8gJ2JnLXdoaXRlIHRleHQtc2xhdGUtOTAwIHNoYWRvdy14cycgOiAndGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBSb21hbiBVcmR1XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TGFuZygnZW5nbGlzaCcpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xIHRleHQteHMgZm9udC1zZW1pYm9sZCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgIGxhbmcgPT09ICdlbmdsaXNoJyA/ICdiZy13aGl0ZSB0ZXh0LXNsYXRlLTkwMCBzaGFkb3cteHMnIDogJ3RleHQtc2xhdGUtNjAwIGhvdmVyOnRleHQtc2xhdGUtOTAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgRW5nbGlzaFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q3VycmVudFZpZXcoJ2J1eWVyJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGUgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEJhY2sgdG8gU3RvcmUgJnJhcnI7XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU2VjdGlvbiBOYXZpZ2F0aW9uIFRhYnMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBvdmVyZmxvdy14LWF1dG8gcHQtNiBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIG10LTYgc2Nyb2xsYmFyLW5vbmVcIj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgaWQ6ICdzdGFjaycsIGxhYmVsOiAnMS4gUmVjb21tZW5kZWQgVGVjaCBTdGFjaycsIGljb246IExheWVycyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnd2lyZWZyYW1lcycsIGxhYmVsOiAnMi4gVUkvVVggQmx1ZXByaW50ICYgV2lyZWZyYW1lcycsIGljb246IExheW91dCB9LFxuICAgICAgICAgICAgICB7IGlkOiAnc2NoZW1hJywgbGFiZWw6ICczLiBEYXRhYmFzZSBTY2hlbWFzJywgaWNvbjogRGF0YWJhc2UgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2NvZGUnLCBsYWJlbDogJzQuIENvcmUgUHJvZHVjdGlvbiBDb2RlJywgaWNvbjogQ29kZTIgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2RlcGxveW1lbnQnLCBsYWJlbDogJzUuIERlcGxveW1lbnQgb24gVmVyY2VsIC8gTmV0bGlmeScsIGljb246IFJvY2tldCB9XG4gICAgICAgICAgICBdLm1hcCh0YWIgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBJY29uID0gdGFiLmljb247XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAga2V5PXt0YWIuaWR9XG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTZWN0aW9uKHRhYi5pZCBhcyBhbnkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMy41IHB5LTIgdGV4dC14cyBmb250LW1lZGl1bSByb3VuZGVkIHRyYW5zaXRpb24tY29sb3JzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgd2hpdGVzcGFjZS1ub3dyYXAgY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgYWN0aXZlU2VjdGlvbiA9PT0gdGFiLmlkXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgdGV4dC1zbGF0ZS02MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ymctc2xhdGUtNTAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57dGFiLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWFpbiBCb2R5ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCBtdC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU0VDVElPTiAxOiBURUNIIFNUQUNLICovfVxuICAgICAgICB7YWN0aXZlU2VjdGlvbiA9PT0gJ3N0YWNrJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBwLTZcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheSBtYi0yXCI+XG4gICAgICAgICAgICAgICAge2xhbmcgPT09ICd1cmR1JyA/ICcxLiBSZWNvbW1lbmRlZCBMaWdodHdlaWdodCBUZWNoIFN0YWNrIChCZWh0YXJlZW4gQ29tYmluYXRpb25zKScgOiAnMS4gUmVjb21tZW5kZWQgTGlnaHR3ZWlnaHQgVGVjaCBTdGFjayd9XG4gICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgbWItNiBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnXG4gICAgICAgICAgICAgICAgICA/ICdGYXN0IHBlcmZvcm1hbmNlLCB6ZXJvIGJsb2F0LCBtb2JpbGUgcmVzcG9uc2l2ZW5lc3MsIGF1ciBlYXN5IG1haW50ZW5hbmNlIGtlIGxpeWUgaHVtIG1vZGVybiBkZWNvdXBsZWQgYXJjaGl0ZWN0dXJlIHJlY29tbWVuZCBrYXJ0ZSBoYWluIGppc21lIGZyb250ZW5kIGluc3RhbnQgbG9hZCBob3RhIGhhaSBhdXIgYmFja2VuZCBzY2FsYWJsZSByZWh0YSBoYWkuJ1xuICAgICAgICAgICAgICAgICAgOiAnRm9yIHVsdHJhLWZhc3QgbG9hZCB0aW1lcywgbW9iaWxlIHBlcmZvcm1hbmNlLCBhbmQgbG93IGluZnJhc3RydWN0dXJlIGNvc3RzLCB3ZSByZWNvbW1lbmQgYSBtb2Rlcm4gZGVjb3VwbGVkIHN0YWNrIHdpdGggY2xpZW50LXNpZGUgY2FjaGluZyBhbmQgbGlnaHR3ZWlnaHQgc2VydmVybGVzcyBBUElzLid9XG4gICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogRnJvbnRlbmQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHAtNSBiZy1zbGF0ZS01MFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPkxheWVyIDE6IEZyb250ZW5kPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0yXCI+UmVhY3QgMTkgKyBWaXRlICsgVGFpbHdpbmQgQ1NTPC9oMz5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+Vml0ZTo8L3N0cm9uZz4gVWx0cmEtZmFzdCBidW5kbGluZyAoc3ViLXNlY29uZCBITVIpIGF1ciB6ZXJvIHJ1bnRpbWUgb3ZlcmhlYWQuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+VGFpbHdpbmQgQ1NTOjwvc3Ryb25nPiBNaW5pbWFsIENTUyBidW5kbGUgc2l6ZSAoJmx0OzE1S0IgZ3ppcHBlZCBpbiBwcm9kdWN0aW9uKSwgcmVzcG9uc2l2ZSB1dGlsaXRpZXMuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+THVjaWRlIEljb25zOjwvc3Ryb25nPiBUcmVlLXNoYWthYmxlIFNWRyBpY29ucyB3aXRob3V0IGhlYXZ5IGljb24gcGFja2FnZXMuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBCYWNrZW5kICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTUgYmctc2xhdGUtNTBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5MYXllciAyOiBCYWNrZW5kICYgQVBJPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBtYi0yXCI+Tm9kZS5qcyArIEV4cHJlc3MgLyBTZXJ2ZXJsZXNzPC9oMz5cbiAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8bGkgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNsYXRlLTQwMCBzaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjxzdHJvbmc+RXhwcmVzcyBSRVNUIC8gRWRnZSBGdW5jdGlvbnM6PC9zdHJvbmc+IEZhc3QgQVBJIHJvdXRlcyBmb3IgYC9hcGkvb3JkZXJzYCwgYC9hcGkvcHJvZHVjdHNgLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nPlplcm8gU2Vzc2lvbiBTdGF0ZTo8L3N0cm9uZz4gSldUIGF1dGhlbnRpY2F0aW9uIGZvciBTZWxsZXIgQWRtaW4gd2l0aCBzZWN1cmUgSHR0cE9ubHkgY29va2llcy48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+PHN0cm9uZz5XZWJTb2NrZXRzIC8gU1NFOjwvc3Ryb25nPiBSZWFsLXRpbWUgcHVzaCBub3RpZmljYXRpb24gd2hlbiBhIGJ1eWVyIHN1Ym1pdHMgYSBuZXcgb3JkZXIuPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBEYXRhYmFzZSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcC01IGJnLXNsYXRlLTUwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+TGF5ZXIgMzogRGF0YWJhc2U8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG1iLTJcIj5Qb3N0Z3JlU1FMIChTdXBhYmFzZSkgeWEgRmlyZWJhc2U8L2gzPlxuICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIHNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+PHN0cm9uZz5PcHRpb24gQSAoU1FMIC0gUmVjb21tZW5kZWQpOjwvc3Ryb25nPiBQb3N0Z3JlU1FMIHdpdGggRHJpenpsZS9QcmlzbWEgT1JNIGZvciBzdHJpY3Qgb3JkZXIgJiBpbnZlbnRvcnkgdHJhbnNhY3Rpb25zLjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj48c3Ryb25nPk9wdGlvbiBCIChOb1NRTCAvIFJlYWx0aW1lKTo8L3N0cm9uZz4gRmlyZWJhc2UgRmlyZXN0b3JlIGZvciBpbnN0YW50IHJlYWwtdGltZSBsaXZlIHN5bmMgYmV0d2VlbiBidXllciBhbmQgc2VsbGVyIG91dCBvZiB0aGUgYm94Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogU0VDVElPTiAyOiBVSS9VWCBCTFVFUFJJTlQgKi99XG4gICAgICAgIHthY3RpdmVTZWN0aW9uID09PSAnd2lyZWZyYW1lcycgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgcC02XCI+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBmb250LWRpc3BsYXkgbWItMlwiPlxuICAgICAgICAgICAgICAgIHtsYW5nID09PSAndXJkdScgPyAnMi4gVUkvVVggV2lyZWZyYW1lICYgV29ya2Zsb3cgQmx1ZXByaW50JyA6ICcyLiBVSS9VWCBXaXJlZnJhbWUgJiBXb3JrZmxvdyBBcmNoaXRlY3R1cmUnfVxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIG1iLTZcIj5cbiAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnXG4gICAgICAgICAgICAgICAgICA/ICdCdXllciBhdXIgU2VsbGVyIGRvbm8ga2UgbGl5ZSBjbGVhbiAyLXN0ZXAgZGlyZWN0IG9yZGVyaW5nIGxvb3Agam8gUGFraXN0YW5pL1NvdXRoIEFzaWFuIGUtY29tbWVyY2UgY29udmVyc2lvbiByYXRlcyBrbyBtYXhpbXVtIGJhcmhhdGEgaGFpLidcbiAgICAgICAgICAgICAgICAgIDogJ1N0cmVhbWxpbmVkIDItc3RlcCBkaXJlY3QgY2hlY2tvdXQgbG9vcCBvcHRpbWl6ZWQgZm9yIGhpZ2ggbW9iaWxlIGNvbnZlcnNpb24gYW5kIHJhcGlkIHNlbGxlciBvcmRlciBmdWxmaWxsbWVudC4nfVxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgey8qIEJ1eWVyIFdvcmtmbG93ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0zIGJvcmRlci1iIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkEuIEJ1eWVyIFZpZXcgV29ya2Zsb3cgKEtoYXJlZWRhcik8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1lbWVyYWxkLTYwMCBmb250LXNlbWlib2xkXCI+Jmx0OyAzMHMgQ2hlY2tvdXQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS01MCByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIG1iLTFcIj5TdGVwIDE6IFByb2R1Y3QgRGlzY292ZXJ5IChHcmlkIFZpZXcpPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1bMTFweF1cIj5DbGVhbiBwcm9kdWN0IGNhcmRzIHNob3dpbmcgcGhvdG8gKDY1JSksIHByb2R1Y3QgbmFtZSwgY2F0ZWdvcnksIGNsZWFyIHRhYnVsYXIgcHJpY2UgKGUuZy4gUEtSIDE4LDUwMCksIHN0b2NrIHRhZywgYW5kIGhpZ2gtdmlzaWJpbGl0eSBcIk9yZGVyIE5vd1wiIGJ1dHRvbi48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTUwIHJvdW5kZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS04MDAgbWItMVwiPlN0ZXAgMjogSW5zdGFudCBFeHByZXNzIE1vZGFsIChObyBSZWdpc3RyYXRpb24gRnJpY3Rpb24pPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1bMTFweF1cIj5CdXllciBkb2Vzbid0IG5lZWQgdG8gY3JlYXRlIGFuIGFjY291bnQgb3IgcmVtZW1iZXIgcGFzc3dvcmRzLiBDbGlja2luZyBcIk9yZGVyIE5vd1wiIG9wZW5zIGEgcG9wdXAgd2l0aCAzIGVzc2VudGlhbCBmaWVsZHM6IEZ1bGwgTmFtZSwgUGhvbmUgLyBXaGF0c0FwcCwgYW5kIENvbXBsZXRlIFN0cmVldCBBZGRyZXNzLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi0xXCI+U3RlcCAzOiBJbnN0YW50IENvbmZpcm1hdGlvbiAmIFdoYXRzQXBwIFJlY2VpcHQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LVsxMXB4XVwiPlVuaXF1ZSBPcmRlciBUcmFja2luZyBOdW1iZXIgKCNCRi1YWFhYKSBpcyBnZW5lcmF0ZWQsIHdpdGggaW1tZWRpYXRlIGNvbmZpcm1hdGlvbiBzY3JlZW4gYW5kIGRpcmVjdCBXaGF0c0FwcCBjb25maXJtYXRpb24gc2hhcmUuPC9wPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFNlbGxlciBXb3JrZmxvdyAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcC01IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5CLiBTZWxsZXIgRGFzaGJvYXJkIFdvcmtmbG93IChEdWthbmRhciAvIEFkbWluKTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtbW9ubyB0ZXh0LWFtYmVyLTYwMCBmb250LXNlbWlib2xkXCI+UmVhbC1UaW1lIERpc3BhdGNoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi0xXCI+U3RlcCAxOiBJbmNvbWluZyBPcmRlciBOb3RpZmljYXRpb24gQWxlcnQ8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LVsxMXB4XVwiPlNlbGxlciBkYXNoYm9hcmQgZGlzcGxheXMgdmlzdWFsIGFsZXJ0IGFuZCBiYWRnZSBjb3VudCB0aGUgbW9tZW50IGFueSBidXllciBzdWJtaXRzIGFuIG9yZGVyLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi0xXCI+U3RlcCAyOiBEaXNwYXRjaCBMYWJlbCAmIEN1c3RvbWVyIENvbnRhY3Q8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCB0ZXh0LVsxMXB4XVwiPlNlbGxlciBnZXRzIDEtY2xpY2sgXCJDb3B5IERpc3BhdGNoIExhYmVsXCIgZm9yIGNvdXJpZXIgYm9va2luZyAoVENTLCBMZW9wYXJkcywgVHJheCwgUG9zdEV4KSwgcGx1cyAxLWNsaWNrIFdoYXRzQXBwIGNoYXQgYnV0dG9uLjwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtNTAgcm91bmRlZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBtYi0xXCI+U3RlcCAzOiBQcm9kdWN0IEludmVudG9yeSBDb250cm9sPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgdGV4dC1bMTFweF1cIj5BZGQsIGVkaXQsIG9yIGRlbGV0ZSBpdGVtcywgdXBkYXRlIHN0b2NrIHN0YXR1cyAoSW4gU3RvY2sgLyBMb3cgU3RvY2sgLyBPdXQgb2YgU3RvY2spLCBhbmQgYWRqdXN0IHByaWNlcyBkeW5hbWljYWxseS48L3A+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFNFQ1RJT04gMzogREFUQUJBU0UgU0NIRU1BICovfVxuICAgICAgICB7YWN0aXZlU2VjdGlvbiA9PT0gJ3NjaGVtYScgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgcC02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheVwiPlxuICAgICAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnID8gJzMuIERhdGFiYXNlIFNjaGVtYSAoU1FMIGF1ciBOb1NRTCBTdHJ1Y3R1cmUpJyA6ICczLiBQcm9kdWN0aW9uIERhdGFiYXNlIFNjaGVtYSd9XG4gICAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnIFxuICAgICAgICAgICAgICAgICAgICAgID8gJ1Byb2R1Y3RzLCBPcmRlcnMsIGF1ciBPcmRlckl0ZW1zIHRhYmxlcyBrYSBjb21wbGV0ZSBEREwgc3RydWN0dXJlIGZvciBQb3N0Z3JlU1FMIGF1ciBGaXJlc3RvcmUuJyBcbiAgICAgICAgICAgICAgICAgICAgICA6ICdSZWxhdGlvbmFsIFBvc3RncmVTUUwgRERMIHNjaGVtYSB3aXRoIGZvcmVpZ24ga2V5IGNvbnN0cmFpbnRzLCBpbmRleGVzLCBhbmQgb3JkZXIgc3RhdHVzIGVudW1zLid9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDb3B5KCdzcWxfc2NoZW1hJywgc3FsU2NoZW1hQ29kZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgYmctc2xhdGUtMTAwIGhvdmVyOmJnLXNsYXRlLTIwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7Y29waWVkS2V5ID09PSAnc3FsX3NjaGVtYScgPyA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTYwMFwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntjb3BpZWRLZXkgPT09ICdzcWxfc2NoZW1hJyA/ICdDb3BpZWQgU1FMJyA6ICdDb3B5IFNRTCBTY2hlbWEnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS0yMDAgcm91bmRlZC1sZyBwLTQgZm9udC1tb25vIHRleHQteHMgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgPHByZT57c3FsU2NoZW1hQ29kZX08L3ByZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogU0VDVElPTiA0OiBDT1JFIENPREUgKi99XG4gICAgICAgIHthY3RpdmVTZWN0aW9uID09PSAnY29kZScgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS02XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQteGwgcC02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheVwiPlxuICAgICAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnID8gJzQuIFByb2R1Y3Rpb24gQ29kZSBFeGFtcGxlcyAoRnJvbnQtRW5kICYgSGFuZGxlciBMb2dpYyknIDogJzQuIENvcmUgUHJvZHVjdGlvbiBDb2RlIFNuaXBwZXRzJ31cbiAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIHtsYW5nID09PSAndXJkdSdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdUYWlsd2luZCBDU1Mgc2UgUHJvZHVjdCBDYXJkLCBFeHByZXNzIE9yZGVyIEhhbmRsZXIsIGF1ciBRdWljayBDaGVja291dCBNb2RhbCBrYSBjbGVhbiBjb2RlLidcbiAgICAgICAgICAgICAgICAgICAgICA6ICdDbGVhbiwgY29weS1wYXN0ZWFibGUgUmVhY3QgKyBUYWlsd2luZCBDU1MgY29kZSBmb3IgYnV5ZXIgb3JkZXIgY2hlY2tvdXQgYW5kIGJhY2tlbmQgc3VibWlzc2lvbi4nfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQ29weSgnZXhwcmVzc19oYW5kbGVyJywgZXhwcmVzc0hhbmRsZXJDb2RlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBiZy1zbGF0ZS0xMDAgaG92ZXI6Ymctc2xhdGUtMjAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtjb3BpZWRLZXkgPT09ICdleHByZXNzX2hhbmRsZXInID8gPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC02MDBcIiAvPiA6IDxDb3B5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz59XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y29waWVkS2V5ID09PSAnZXhwcmVzc19oYW5kbGVyJyA/ICdDb3BpZWQnIDogJ0NvcHkgQmFja2VuZCBBUEkgQ29kZSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLWxnIHAtNCBmb250LW1vbm8gdGV4dC14cyBvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICA8cHJlPntleHByZXNzSGFuZGxlckNvZGV9PC9wcmU+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFNFQ1RJT04gNTogREVQTE9ZTUVOVCAqL31cbiAgICAgICAge2FjdGl2ZVNlY3Rpb24gPT09ICdkZXBsb3ltZW50JyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgcm91bmRlZC14bCBwLTZcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGZvbnQtZGlzcGxheSBtYi0yXCI+XG4gICAgICAgICAgICAgICAge2xhbmcgPT09ICd1cmR1JyA/ICc1LiBEZXBsb3ltZW50IFN0cmF0ZWd5IChWZXJjZWwgJiBOZXRsaWZ5IEhvc3RpbmcgR3VpZGUpJyA6ICc1LiBQcm9kdWN0aW9uIERlcGxveW1lbnQgU3RyYXRlZ3knfVxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIG1iLTZcIj5cbiAgICAgICAgICAgICAgICB7bGFuZyA9PT0gJ3VyZHUnXG4gICAgICAgICAgICAgICAgICA/ICdTdGVwLWJ5LXN0ZXAgdGFyZWVxYSBWZXJjZWwgYXVyIE5ldGxpZnkgcGFyIGFwbmkgc2hvcCBzdG9yZSBsaXZlIGthcm5lIGtlIGxpeWUgKFplcm8gY29zdCBmcmVlLXRpZXIgc3VwcG9ydGVkKS4nXG4gICAgICAgICAgICAgICAgICA6ICdTdGVwLWJ5LXN0ZXAgaW5zdHJ1Y3Rpb25zIGZvciBob3N0aW5nIGZyb250ZW5kIGFuZCBiYWNrZW5kIG9uIFZlcmNlbCBhbmQgTmV0bGlmeSB3aXRoIGN1c3RvbSBkb21haW4gc3VwcG9ydC4nfVxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC02XCI+XG4gICAgICAgICAgICAgICAgey8qIFZlcmNlbCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtbGcgcC01IHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPkhvc3Rpbmcgb24gVmVyY2VsIChSZWNvbW1lbmRlZCk8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj52ZXJjZWwuanNvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBzcGFjZS15LTIgbGlzdC1kZWNpbWFsIGxpc3QtaW5zaWRlIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICA8bGk+PHN0cm9uZz5HaXRIdWIgUmVwb3NpdG9yeTo8L3N0cm9uZz4gQXBuYSBjb2RlIEdpdEh1YiByZXBvIG1laW4gcHVzaCBrYXJlaW4gKGBnaXQgcHVzaCBvcmlnaW4gbWFpbmApLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkNvbm5lY3QgVmVyY2VsOjwvc3Ryb25nPiA8YSBocmVmPVwiaHR0cHM6Ly92ZXJjZWwuY29tXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGZvbnQtc2VtaWJvbGQgdW5kZXJsaW5lXCI+dmVyY2VsLmNvbTwvYT4gcGFyIGxvZ2luIGthcmVpbiBhdXIgXCJJbXBvcnQgR2l0IFJlcG9zaXRvcnlcIiBzZWxlY3Qga2FyZWluLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkJ1aWxkIFNldHRpbmdzOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSBiZy1zbGF0ZS0xMDAgcC0yIHJvdW5kZWQgZm9udC1tb25vIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBCdWlsZCBDb21tYW5kOiBucG0gcnVuIGJ1aWxkPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBPdXRwdXQgRGlyZWN0b3J5OiBkaXN0PGJyIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICBJbnN0YWxsIENvbW1hbmQ6IG5wbSBpbnN0YWxsXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkVudmlyb25tZW50IFZhcmlhYmxlczo8L3N0cm9uZz4gQWdhciBiYWNrZW5kIEFQSSB5YSBEYXRhYmFzZSB1c2Uga2FyIHJhaGUgaGFpbiB0byBgREFUQUJBU0VfVVJMYCB5YSBgVklURV9BUElfVVJMYCBhZGQga2FyZWluLjwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkRlcGxveTo8L3N0cm9uZz4gXCJEZXBsb3lcIiBidXR0b24gY2xpY2sga2FyZWluLiA0NSBzZWNvbmRzIGtlIGFuZGFyIGFhcGtpIHNob3AgbGl2ZSBVUkwgKGBteXNob3AudmVyY2VsLmFwcGApIHBhciBhY3RpdmUgaG8gamF5ZWdpITwvbGk+XG4gICAgICAgICAgICAgICAgICA8L29sPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIE5ldGxpZnkgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCByb3VuZGVkLWxnIHAtNSBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5Ib3N0aW5nIG9uIE5ldGxpZnk8L2gzPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj5fcmVkaXJlY3RzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIHNwYWNlLXktMiBsaXN0LWRlY2ltYWwgbGlzdC1pbnNpZGUgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPk5ldGxpZnkgRGFzaGJvYXJkOjwvc3Ryb25nPiA8YSBocmVmPVwiaHR0cHM6Ly9uZXRsaWZ5LmNvbVwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LXNlbWlib2xkIHVuZGVybGluZVwiPm5ldGxpZnkuY29tPC9hPiBwYXIgXCJBZGQgbmV3IHNpdGVcIiAmZ3Q7IFwiSW1wb3J0IGFuIGV4aXN0aW5nIHByb2plY3RcIiBrYXJlaW4uPC9saT5cbiAgICAgICAgICAgICAgICAgICAgPGxpPjxzdHJvbmc+U1BBIFJlZGlyZWN0cyBSdWxlOjwvc3Ryb25nPiBSZWFjdCBzaW5nbGUtcGFnZSByb3V0aW5nIGtlIGxpeWUgYHB1YmxpYy9fcmVkaXJlY3RzYCBmaWxlIG1laW4geWVoIGxpbmUgbGlraGVpbjpcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgYmctc2xhdGUtMTAwIHAtMiByb3VuZGVkIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgLyogL2luZGV4Lmh0bWwgMjAwXG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDxsaT48c3Ryb25nPkN1c3RvbSBEb21haW4gJiBTU0w6PC9zdHJvbmc+IE5ldGxpZnkgU2V0dGluZ3MgbWVpbiBqYWthciBhcG5hIGN1c3RvbSBgLmNvbWAgeWEgYC5wa2AgZG9tYWluIGFkZCBrYXJlaW47IEZyZWUgTGV0J3MgRW5jcnlwdCBTU0wgYXV0b21hdGljYWxseSBhY3RpdmF0ZSBobyBqYXllZ2EuPC9saT5cbiAgICAgICAgICAgICAgICAgIDwvb2w+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG4vLyBEYXRhYmFzZSBTY2hlbWEgQ29kZSBCbG9ja1xuY29uc3Qgc3FsU2NoZW1hQ29kZSA9IGAtLSBQb3N0Z3JlU1FMIFByb2R1Y3Rpb24gRGF0YWJhc2UgU2NoZW1hIGZvciBTaW5nbGUvTXVsdGktVmVuZG9yIFN0b3JlXG5cbi0tIDEuIFByb2R1Y3RzIFRhYmxlXG5DUkVBVEUgVEFCTEUgcHJvZHVjdHMgKFxuICBpZCBVVUlEIFBSSU1BUlkgS0VZIERFRkFVTFQgZ2VuX3JhbmRvbV91dWlkKCksXG4gIHNrdSBWQVJDSEFSKDUwKSBVTklRVUUgTk9UIE5VTEwsXG4gIG5hbWUgVkFSQ0hBUigyNTUpIE5PVCBOVUxMLFxuICBkZXNjcmlwdGlvbiBURVhULFxuICBwcmljZSBERUNJTUFMKDEwLCAyKSBOT1QgTlVMTCBDSEVDSyAocHJpY2UgPj0gMCksXG4gIHN0b2NrX3N0YXR1cyBWQVJDSEFSKDIwKSBOT1QgTlVMTCBERUZBVUxUICdpbl9zdG9jaycgQ0hFQ0sgKHN0b2NrX3N0YXR1cyBJTiAoJ2luX3N0b2NrJywgJ2xvd19zdG9jaycsICdvdXRfb2Zfc3RvY2snKSksXG4gIHN0b2NrX2NvdW50IElOVCBOT1QgTlVMTCBERUZBVUxUIDAsXG4gIGNhdGVnb3J5IFZBUkNIQVIoMTAwKSBOT1QgTlVMTCxcbiAgaW1hZ2VfdXJsIFRFWFQgTk9UIE5VTEwsXG4gIHZlbmRvcl9pZCBVVUlELCAtLSBGb3IgbXVsdGktdmVuZG9yIHN1cHBvcnRcbiAgY3JlYXRlZF9hdCBUSU1FU1RBTVAgV0lUSCBUSU1FIFpPTkUgREVGQVVMVCBDVVJSRU5UX1RJTUVTVEFNUCxcbiAgdXBkYXRlZF9hdCBUSU1FU1RBTVAgV0lUSCBUSU1FIFpPTkUgREVGQVVMVCBDVVJSRU5UX1RJTUVTVEFNUFxuKTtcblxuLS0gMi4gT3JkZXJzIFRhYmxlXG5DUkVBVEUgVEFCTEUgb3JkZXJzIChcbiAgaWQgVVVJRCBQUklNQVJZIEtFWSBERUZBVUxUIGdlbl9yYW5kb21fdXVpZCgpLFxuICBvcmRlcl9udW1iZXIgVkFSQ0hBUig1MCkgVU5JUVVFIE5PVCBOVUxMLFxuICBjdXN0b21lcl9mdWxsX25hbWUgVkFSQ0hBUigxNTApIE5PVCBOVUxMLFxuICBjdXN0b21lcl9waG9uZSBWQVJDSEFSKDUwKSBOT1QgTlVMTCxcbiAgZGVsaXZlcnlfY2l0eSBWQVJDSEFSKDEwMCkgTk9UIE5VTEwsXG4gIGRlbGl2ZXJ5X2FkZHJlc3MgVEVYVCBOT1QgTlVMTCxcbiAgZGVsaXZlcnlfbm90ZSBURVhULFxuICB0b3RhbF9hbW91bnQgREVDSU1BTCgxMCwgMikgTk9UIE5VTEwsXG4gIHN0YXR1cyBWQVJDSEFSKDMwKSBOT1QgTlVMTCBERUZBVUxUICdwZW5kaW5nJyBDSEVDSyAoc3RhdHVzIElOICgncGVuZGluZycsICdjb25maXJtZWQnLCAnc2hpcHBlZCcsICdkZWxpdmVyZWQnLCAnY2FuY2VsbGVkJykpLFxuICBwYXltZW50X21ldGhvZCBWQVJDSEFSKDMwKSBOT1QgTlVMTCBERUZBVUxUICdjb2QnIENIRUNLIChwYXltZW50X21ldGhvZCBJTiAoJ2NvZCcsICdiYW5rX3RyYW5zZmVyJywgJ29ubGluZScpKSxcbiAgY3JlYXRlZF9hdCBUSU1FU1RBTVAgV0lUSCBUSU1FIFpPTkUgREVGQVVMVCBDVVJSRU5UX1RJTUVTVEFNUFxuKTtcblxuLS0gMy4gT3JkZXIgSXRlbXMgVGFibGUgKE1hbnktdG8tTWFueSByZWxhdGlvbnNoaXApXG5DUkVBVEUgVEFCTEUgb3JkZXJfaXRlbXMgKFxuICBpZCBVVUlEIFBSSU1BUlkgS0VZIERFRkFVTFQgZ2VuX3JhbmRvbV91dWlkKCksXG4gIG9yZGVyX2lkIFVVSUQgTk9UIE5VTEwgUkVGRVJFTkNFUyBvcmRlcnMoaWQpIE9OIERFTEVURSBDQVNDQURFLFxuICBwcm9kdWN0X2lkIFVVSUQgTk9UIE5VTEwgUkVGRVJFTkNFUyBwcm9kdWN0cyhpZCksXG4gIHByb2R1Y3RfbmFtZSBWQVJDSEFSKDI1NSkgTk9UIE5VTEwsXG4gIHVuaXRfcHJpY2UgREVDSU1BTCgxMCwgMikgTk9UIE5VTEwsXG4gIHF1YW50aXR5IElOVCBOT1QgTlVMTCBDSEVDSyAocXVhbnRpdHkgPiAwKSxcbiAgc3VidG90YWwgREVDSU1BTCgxMCwgMikgTk9UIE5VTExcbik7XG5cbi0tIEluZGV4ZXMgZm9yIGxpZ2h0bmluZyBmYXN0IHF1ZXJpZXNcbkNSRUFURSBJTkRFWCBpZHhfcHJvZHVjdHNfY2F0ZWdvcnkgT04gcHJvZHVjdHMoY2F0ZWdvcnkpO1xuQ1JFQVRFIElOREVYIGlkeF9vcmRlcnNfc3RhdHVzIE9OIG9yZGVycyhzdGF0dXMpO1xuQ1JFQVRFIElOREVYIGlkeF9vcmRlcnNfY3JlYXRlZF9hdCBPTiBvcmRlcnMoY3JlYXRlZF9hdCBERVNDKTtgO1xuXG4vLyBFeHByZXNzIEFQSSBDb2RlIEJsb2NrXG5jb25zdCBleHByZXNzSGFuZGxlckNvZGUgPSBgLy8gU2VydmVyLVNpZGUgTm9kZS5qcyAvIEV4cHJlc3MgT3JkZXIgUGxhY2VtZW50IEhhbmRsZXJcbi8vIFJvdXRlOiBQT1NUIC9hcGkvb3JkZXJzXG5cbmltcG9ydCBleHByZXNzIGZyb20gJ2V4cHJlc3MnO1xuY29uc3Qgcm91dGVyID0gZXhwcmVzcy5Sb3V0ZXIoKTtcblxucm91dGVyLnBvc3QoJy9vcmRlcnMnLCBhc3luYyAocmVxLCByZXMpID0+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCB7IGN1c3RvbWVyLCBpdGVtcywgcGF5bWVudE1ldGhvZCB9ID0gcmVxLmJvZHk7XG5cbiAgICAvLyAxLiBWYWxpZGF0ZSBtYW5kYXRvcnkgYnV5ZXIgaW5wdXRzXG4gICAgaWYgKCFjdXN0b21lcj8uZnVsbE5hbWUgfHwgIWN1c3RvbWVyPy5waG9uZSB8fCAhY3VzdG9tZXI/LmRlbGl2ZXJ5QWRkcmVzcykge1xuICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgZXJyb3I6ICdGdWxsIG5hbWUsIHBob25lLCBhbmQgZGVsaXZlcnkgYWRkcmVzcyBhcmUgcmVxdWlyZWQnIH0pO1xuICAgIH1cblxuICAgIGlmICghaXRlbXMgfHwgaXRlbXMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBlcnJvcjogJ09yZGVyIG11c3QgY29udGFpbiBhdCBsZWFzdCBvbmUgcHJvZHVjdCcgfSk7XG4gICAgfVxuXG4gICAgLy8gMi4gQ2FsY3VsYXRlIGdyYW5kIHRvdGFsIHNlY3VyZWx5IG9uIHNlcnZlciBzaWRlXG4gICAgY29uc3QgdG90YWxBbW91bnQgPSBpdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgKGl0ZW0ucHJpY2UgKiBpdGVtLnF1YW50aXR5KSwgMCk7XG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSAnQkYtJyArIE1hdGguZmxvb3IoMTAwMCArIE1hdGgucmFuZG9tKCkgKiA5MDAwKTtcblxuICAgIC8vIDMuIEluc2VydCBvcmRlciByZWNvcmQgaW5zaWRlIGRhdGFiYXNlIHRyYW5zYWN0aW9uXG4gICAgY29uc3QgbmV3T3JkZXIgPSB7XG4gICAgICBvcmRlck51bWJlcixcbiAgICAgIGN1c3RvbWVyLFxuICAgICAgaXRlbXMsXG4gICAgICB0b3RhbEFtb3VudCxcbiAgICAgIHN0YXR1czogJ3BlbmRpbmcnLFxuICAgICAgcGF5bWVudE1ldGhvZDogcGF5bWVudE1ldGhvZCB8fCAnY29kJyxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgfTtcblxuICAgIC8vIDQuIE5vdGlmeSBjb25uZWN0ZWQgc2VsbGVyIHNvY2tldHMgaW4gcmVhbC10aW1lXG4gICAgLy8gaW8uZW1pdCgnbmV3X29yZGVyJywgbmV3T3JkZXIpO1xuXG4gICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAxKS5qc29uKHtcbiAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICBtZXNzYWdlOiAnT3JkZXIgY3JlYXRlZCBzdWNjZXNzZnVsbHknLFxuICAgICAgb3JkZXI6IG5ld09yZGVyXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignT3JkZXIgY3JlYXRpb24gZmFpbGVkOicsIGVycm9yKTtcbiAgICByZXR1cm4gcmVzLnN0YXR1cyg1MDApLmpzb24oeyBlcnJvcjogJ0ludGVybmFsIHNlcnZlciBlcnJvciBwcm9jZXNzaW5nIG9yZGVyJyB9KTtcbiAgfVxufSk7XG5cbmV4cG9ydCBkZWZhdWx0IHJvdXRlcjtgO1xuIl19